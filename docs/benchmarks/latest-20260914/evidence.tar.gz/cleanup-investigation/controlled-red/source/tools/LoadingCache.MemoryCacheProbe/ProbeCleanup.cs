namespace LoadingCache.MemoryCacheProbe;

internal static class ProbeCleanup
{
    internal static int Drain<TKey, TValue>(ICache<TKey, TValue> cache, TimeSpan watchdog)
        where TKey : notnull
        where TValue : notnull
    {
        for (int pass = 1; pass <= 256; pass++)
        {
            cache.CleanUp();
            if (
                cache.Statistics.MaintenanceBacklog == 0
                && cache.Policy.Eviction!.WeightedSize <= cache.Policy.Eviction.Maximum
            )
                return pass;
        }
        throw new InvalidOperationException("LoadingCache cleanup did not converge");
    }
}
