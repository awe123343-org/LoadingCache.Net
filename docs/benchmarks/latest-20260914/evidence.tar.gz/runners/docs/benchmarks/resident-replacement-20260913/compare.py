"""Compare the resident-replacement candidate with the committed .NET and Java baselines.

The .NET reports measure a complete write-and-cleanup trace, while JMH reports one complete
batch.  This script converts both to nanoseconds and allocated bytes per logical write, then
writes one row for each of the 48 matching configurations.

The candidate report is intentionally a command-line input so this script can be rerun for each
uncommitted runtime snapshot.  The old .NET report and the Caffeine report default to the frozen
committed comparison files in ``docs/benchmarks/write-path-20260913``.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Any

Config = tuple[int, int, int, str, str]

REPOSITORY_ROOT = Path(__file__).resolve().parents[3]
REPORT_DIRECTORY = Path(__file__).resolve().parent
DEFAULT_CANDIDATE = REPORT_DIRECTORY / "candidate-caffeine-schema5.json"
DEFAULT_OLD_DOTNET = (
    REPOSITORY_ROOT
    / "docs/benchmarks/write-path-20260913/dotnet/count-caffeine-schema5-formal.json"
)
DEFAULT_JAVA = (
    REPOSITORY_ROOT / "docs/benchmarks/write-path-20260913/caffeine/results/jdk25-final.json"
)
DEFAULT_OUTPUT = REPORT_DIRECTORY / "cross-runtime.csv"


def expected_configurations() -> set[Config]:
    return {
        (capacity, workers, writes, statistics, value_mode)
        for capacity in (1024, 16384)
        for workers in (1, 4, 10)
        for writes in (512, 4096)
        for statistics in ("off", "on")
        for value_mode in ("same", "changed")
    }


def load_json(path: Path, role: str) -> Any:
    if not path.is_file():
        raise ValueError(f"{role} report does not exist: {path}")
    try:
        return json.loads(path.read_text())
    except json.JSONDecodeError as error:
        raise ValueError(f"{role} report is not valid JSON: {path}: {error}") from error


def integer(value: Any, name: str, *, minimum: int | None = None) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{name} must be an integer")
    if minimum is not None and value < minimum:
        raise ValueError(f"{name} must be at least {minimum}")
    return value


def finite_number(value: Any, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be numeric")
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"{name} must be finite")
    return result


def dotnet_config(sample: dict[str, Any]) -> Config:
    capacity = integer(sample.get("capacity"), "sample.capacity", minimum=1)
    workers = integer(sample.get("workers"), "sample.workers", minimum=1)
    writes = integer(sample.get("operationsPerWorker"), "sample.operationsPerWorker", minimum=1)
    statistics_value = sample.get("statistics")
    if not isinstance(statistics_value, bool):
        raise ValueError("sample.statistics must be a boolean")
    value_mode = sample.get("valueMode")
    if value_mode not in ("same", "changed"):
        raise ValueError("sample.valueMode must be same or changed")
    return (capacity, workers, writes, "on" if statistics_value else "off", value_mode)


def validate_dotnet_report(path: Path, role: str) -> dict[str, Any]:
    report = load_json(path, role)
    if not isinstance(report, dict) or report.get("schemaVersion") != 5:
        raise ValueError(f"{role} report must use schemaVersion 5: {path}")
    if report.get("suite") != "caffeine":
        raise ValueError(f"{role} report must be from the caffeine suite: {path}")

    runs = integer(report.get("runs"), f"{role}.runs", minimum=1)
    warmups = integer(report.get("warmups"), f"{role}.warmups", minimum=0)
    samples = report.get("samples")
    if not isinstance(samples, list):
        raise ValueError(f"{role}.samples must be an array")

    expected = expected_configurations()
    grouped: dict[Config, dict[str, dict[int, dict[str, Any]]]] = defaultdict(
        lambda: {"warmup": {}, "measured": {}}
    )
    for sample in samples:
        if not isinstance(sample, dict):
            raise ValueError(f"{role} contains a non-object sample")
        config = dotnet_config(sample)
        if config not in expected:
            raise ValueError(f"{role} contains an unexpected configuration: {config}")

        if sample.get("publicBoundsHold") is not True:
            raise ValueError(f"{role} sample failed publicBoundsHold: {config}")
        if sample.get("backlogAfterDrain") != 0:
            raise ValueError(f"{role} sample has non-zero backlogAfterDrain: {config}")

        index = integer(sample.get("sampleIndex"), f"{role}.sampleIndex", minimum=0)
        is_warmup = sample.get("warmup")
        if not isinstance(is_warmup, bool):
            raise ValueError(f"{role}.warmup must be a boolean: {config}")
        expected_warmup = index < warmups
        if is_warmup != expected_warmup or index >= runs + warmups:
            raise ValueError(f"{role} has an invalid sample index/warmup pair: {config}, {index}")

        batches = integer(sample.get("batches"), f"{role}.batches", minimum=1)
        expected_operations = batches * config[1] * config[2]
        if sample.get("totalOperations") != expected_operations:
            raise ValueError(
                f"{role} totalOperations does not match batches*workers*writes: {config}, "
                f"expected {expected_operations}, got {sample.get('totalOperations')}"
            )
        timed_seconds = finite_number(sample.get("timedSeconds"), f"{role}.timedSeconds")
        if timed_seconds <= 0:
            raise ValueError(f"{role}.timedSeconds must be positive: {config}")
        integer(
            sample.get("wholeProcessAllocatedBytes"),
            f"{role}.wholeProcessAllocatedBytes",
            minimum=0,
        )

        bucket = "warmup" if is_warmup else "measured"
        if index in grouped[config][bucket]:
            raise ValueError(f"Duplicate {role} sample: {config}, {index}")
        grouped[config][bucket][index] = sample

    if set(grouped) != expected:
        missing = sorted(expected - set(grouped))
        extra = sorted(set(grouped) - expected)
        raise ValueError(
            f"{role} must contain exactly 48 configurations; missing={missing}, extra={extra}"
        )

    for config, buckets in grouped.items():
        if len(buckets["warmup"]) != warmups or len(buckets["measured"]) != runs:
            raise ValueError(
                f"{role} has incomplete runs for {config}: "
                f"warmups={len(buckets['warmup'])}/{warmups}, "
                f"measured={len(buckets['measured'])}/{runs}"
            )
        for bucket_name, bucket, expected_count in (
            ("warmup", buckets["warmup"], warmups),
            ("measured", buckets["measured"], runs),
        ):
            first_index = 0 if bucket_name == "warmup" else warmups
            expected_indexes = set(range(first_index, first_index + expected_count))
            if set(bucket) != expected_indexes:
                raise ValueError(
                    f"{role} has non-contiguous {bucket_name} sample indexes for {config}: "
                    f"{sorted(bucket)}, expected={sorted(expected_indexes)}"
                )

    return {"report": report, "groups": grouped, "runs": runs, "warmups": warmups}


def java_config(result: dict[str, Any]) -> Config:
    parameters = result.get("params")
    if not isinstance(parameters, dict):
        raise ValueError("JMH result.params must be an object")
    capacity = integer(int(parameters.get("capacity")), "JMH params.capacity", minimum=1)
    workers = integer(int(parameters.get("workers")), "JMH params.workers", minimum=1)
    writes = integer(
        int(parameters.get("writesPerWorker")), "JMH params.writesPerWorker", minimum=1
    )
    statistics_value = parameters.get("statistics")
    if statistics_value not in ("on", "off"):
        raise ValueError("JMH params.statistics must be on or off")
    value_mode = parameters.get("valueMode")
    if value_mode not in ("same", "changed"):
        raise ValueError("JMH params.valueMode must be same or changed")
    return (capacity, workers, writes, statistics_value, value_mode)


def validate_java_report(path: Path) -> dict[Config, dict[str, Any]]:
    report = load_json(path, "Caffeine")
    if not isinstance(report, list) or len(report) != 48:
        raise ValueError(f"Caffeine JMH report must contain exactly 48 results: {path}")

    expected = expected_configurations()
    results: dict[Config, dict[str, Any]] = {}
    for result in report:
        if not isinstance(result, dict):
            raise ValueError("Caffeine JMH report contains a non-object result")
        config = java_config(result)
        if config not in expected or config in results:
            raise ValueError(f"Duplicate or unexpected Caffeine configuration: {config}")

        metric = result.get("primaryMetric")
        if not isinstance(metric, dict) or metric.get("scoreUnit") != "ns/op":
            raise ValueError(f"Caffeine result must report primaryMetric in ns/op: {config}")
        score = finite_number(metric.get("score"), f"Caffeine primaryMetric.score for {config}")
        if score <= 0:
            raise ValueError(f"Caffeine primaryMetric.score must be positive: {config}")

        allocations = result.get("secondaryMetrics", {}).get("gc.alloc.rate.norm")
        if not isinstance(allocations, dict) or allocations.get("scoreUnit") != "B/op":
            raise ValueError(f"Caffeine result must report allocation in B/op: {config}")
        allocated = finite_number(
            allocations.get("score"), f"Caffeine gc.alloc.rate.norm.score for {config}"
        )
        if allocated < 0:
            raise ValueError(f"Caffeine allocation score must not be negative: {config}")

        batch_writes = config[1] * config[2]
        if batch_writes <= 0:
            raise ValueError(f"Invalid JMH batch size for {config}")
        results[config] = {
            "ns_per_batch": score,
            "bytes_per_batch": allocated,
            "batch_writes": batch_writes,
        }

    if set(results) != expected:
        raise ValueError("Caffeine JMH report must contain the same 48 configurations")
    return results


def dotnet_metrics(report: dict[str, Any], config: Config) -> dict[str, float]:
    measured = report["groups"][config]["measured"].values()
    ns_per_write = [
        finite_number(sample["timedSeconds"], "timedSeconds") * 1e9 / sample["totalOperations"]
        for sample in measured
    ]
    bytes_per_write = [
        sample["wholeProcessAllocatedBytes"] / sample["totalOperations"]
        for sample in report["groups"][config]["measured"].values()
    ]
    return {
        "mean_ns_per_write": statistics.mean(ns_per_write),
        "median_ns_per_write": statistics.median(ns_per_write),
        "mean_bytes_per_write": statistics.mean(bytes_per_write),
    }


def ratio(numerator: float, denominator: float) -> float:
    if denominator <= 0:
        raise ValueError("Cannot calculate a ratio with a non-positive denominator")
    return numerator / denominator


def build_rows(
    old: dict[str, Any], new: dict[str, Any], java: dict[Config, dict[str, Any]]
) -> list[dict[str, Any]]:
    if (old["runs"], old["warmups"]) != (new["runs"], new["warmups"]):
        raise ValueError("Old and candidate .NET reports must use the same runs and warmups")

    rows = []
    for config in sorted(expected_configurations()):
        old_metrics = dotnet_metrics(old, config)
        new_metrics = dotnet_metrics(new, config)
        java_metrics = java[config]
        java_ns = java_metrics["ns_per_batch"] / java_metrics["batch_writes"]
        java_bytes = java_metrics["bytes_per_batch"] / java_metrics["batch_writes"]
        old_ns = old_metrics["mean_ns_per_write"]
        new_ns = new_metrics["mean_ns_per_write"]
        old_bytes = old_metrics["mean_bytes_per_write"]
        new_bytes = new_metrics["mean_bytes_per_write"]
        rows.append(
            {
                "capacity": config[0],
                "workers": config[1],
                "writes_per_worker": config[2],
                "statistics": config[3],
                "value_mode": config[4],
                "old_dotnet_mean_ns_per_write": old_ns,
                "old_dotnet_median_ns_per_write": old_metrics["median_ns_per_write"],
                "new_dotnet_mean_ns_per_write": new_ns,
                "new_dotnet_median_ns_per_write": new_metrics["median_ns_per_write"],
                "caffeine_mean_ns_per_write": java_ns,
                "old_dotnet_over_caffeine_ns_ratio": ratio(old_ns, java_ns),
                "new_dotnet_over_caffeine_ns_ratio": ratio(new_ns, java_ns),
                "new_over_old_dotnet_ns_ratio": ratio(new_ns, old_ns),
                "old_dotnet_mean_bytes_per_write": old_bytes,
                "new_dotnet_mean_bytes_per_write": new_bytes,
                "caffeine_mean_bytes_per_write": java_bytes,
                "old_dotnet_over_caffeine_bytes_ratio": ratio(old_bytes, java_bytes),
                "new_dotnet_over_caffeine_bytes_ratio": ratio(new_bytes, java_bytes),
                "new_over_old_dotnet_bytes_ratio": ratio(new_bytes, old_bytes),
            }
        )
    return rows


def write_csv(rows: list[dict[str, Any]], output: Path) -> None:
    if not output.parent.is_dir():
        raise ValueError(f"Output directory does not exist: {output.parent}")
    with output.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path, default=DEFAULT_CANDIDATE)
    parser.add_argument("--java", type=Path, default=DEFAULT_JAVA)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    candidate_path = args.candidate.expanduser().resolve()
    java_path = args.java.expanduser().resolve()
    output_path = args.output.expanduser().resolve()

    old = validate_dotnet_report(DEFAULT_OLD_DOTNET, "old .NET")
    new = validate_dotnet_report(candidate_path, "candidate .NET")
    java = validate_java_report(java_path)
    rows = build_rows(old, new, java)
    if len(rows) != 48:
        raise ValueError(f"Expected 48 comparison rows, got {len(rows)}")
    write_csv(rows, output_path)

    ns_ratios = [row["new_over_old_dotnet_ns_ratio"] for row in rows]
    java_ratios = [row["new_dotnet_over_caffeine_ns_ratio"] for row in rows]
    print(f"Wrote {len(rows)} configurations to {output_path}")
    print(
        "New/old .NET time ratios: "
        f"range {min(ns_ratios):.3f}–{max(ns_ratios):.3f}; "
        f"median {statistics.median(ns_ratios):.3f}"
    )
    print(
        "New .NET/Caffeine time ratios: "
        f"range {min(java_ratios):.3f}–{max(java_ratios):.3f}; "
        f"median {statistics.median(java_ratios):.3f}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
