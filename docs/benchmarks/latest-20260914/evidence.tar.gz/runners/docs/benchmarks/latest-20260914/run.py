"""Repeat the existing comparison matrices serially against the current source."""

import argparse
import hashlib
import json
import os
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

REPO = Path(__file__).resolve().parents[3]
CAFFEINE = REPO / "docs/benchmarks/caffeine-comprehensive-20260913"
MEMORY = REPO / "docs/benchmarks/memorycache-20260914"
JAVA_HOME = Path("/Library/Java/JavaVirtualMachines/zulu-25.jdk/Contents/Home")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "stage", choices=("prepare", "smoke", "scenario", "read", "write", "policy", "memorycache")
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    record_path = output / f"{args.stage}-execution.json"
    if record_path.exists():
        parser.error(f"Existing evidence will not be overwritten: {record_path}")
    environment = {
        key: value
        for key, value in os.environ.items()
        if not key.startswith(("DOTNET_", "COMPlus_", "CORECLR_", "COR_"))
        and key not in ("JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "_JAVA_OPTIONS")
    }
    record = {
        "stage": args.stage,
        "startedUtc": datetime.now(UTC).isoformat(),
        "gitHead": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=REPO, text=True
        ).strip(),
        "runnerSha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "environmentPolicy": "Default runtime/JIT/GC; inherited runtime overrides removed",
        "commands": [],
    }

    def execute(name, command):
        argv = [str(value) for value in command]
        entry = {
            "name": name,
            "argv": argv,
            "cwd": str(REPO),
            "startedUtc": datetime.now(UTC).isoformat(),
        }
        record["commands"].append(entry)
        record_path.write_text(json.dumps(record, indent=2) + "\n")
        print(name, flush=True)
        with (output / f"{name}.log").open("w") as log:
            result = subprocess.run(
                argv, cwd=REPO, env=environment, stdout=log, stderr=subprocess.STDOUT
            )
        entry.update(exitCode=result.returncode, finishedUtc=datetime.now(UTC).isoformat())
        record_path.write_text(json.dumps(record, indent=2) + "\n")
        if result.returncode:
            raise RuntimeError(f"{name} failed; see {output / (name + '.log')}")

    shared = [
        "--manifest",
        output / "source/manifest.json",
        "--runtime8",
        REPO / "artifacts/runtime8/dotnet",
        "--runtime10",
        REPO / "artifacts/runtime10/dotnet",
        "--java",
        JAVA_HOME / "bin/java",
    ]
    if args.stage == "prepare":
        execute(
            "freeze",
            [
                sys.executable,
                CAFFEINE / "freeze.py",
                "--output",
                output / "source",
                "--caffeine-jar",
                Path.home()
                / ".m2/repository/com/github/ben-manes/caffeine/caffeine/3.2.4/caffeine-3.2.4.jar",
                "--java-home",
                JAVA_HOME,
            ],
        )
        for probe in ("HitProbe", "MemoryCacheProbe"):
            execute(
                f"build-{probe}",
                [
                    "dotnet",
                    "build",
                    f"tools/LoadingCache.{probe}/LoadingCache.{probe}.csproj",
                    "-c",
                    "Release",
                ],
            )
    elif args.stage == "smoke":
        frozen = json.loads((output / "source/manifest.json").read_text())
        root = Path(frozen["root"])
        for runtime in ("net8", "net10", "caffeine"):
            base = (
                [
                    JAVA_HOME / "bin/java",
                    "-cp",
                    f"{root}/java-classes:{root}/caffeine-3.2.4.jar",
                    "ScenarioProbe",
                ]
                if runtime == "caffeine"
                else [
                    REPO / f"artifacts/runtime{runtime[3:]}/dotnet",
                    root
                    / f"tools/LoadingCache.ScenarioProbe/bin/Release/{runtime}.0/LoadingCache.ScenarioProbe.dll",
                ]
            )
            for stats in ("off", "on"):
                name = f"smoke-{runtime}-{stats}"
                execute(
                    name,
                    base
                    + [
                        "--scenario",
                        "all",
                        "--cycles",
                        "256",
                        "--capacity",
                        "64",
                        "--warmups",
                        "0",
                        "--runs",
                        "1",
                        "--statistics",
                        stats,
                        "--output",
                        output / f"{name}.json",
                    ],
                )
                report = json.loads((output / f"{name}.json").read_text())
                assert len(report["samples"]) == 41 and all(
                    s["validated"] for s in report["samples"]
                )
    elif args.stage == "memorycache":
        execute(
            "memorycache", [sys.executable, MEMORY / "run.py", "--output", output / "memorycache"]
        )
        execute(
            "memorycache-analyze",
            [
                sys.executable,
                MEMORY / "analyze.py",
                output / "memorycache",
                "--output",
                output / "memorycache-analysis",
            ],
        )
    else:
        runner = {
            "scenario": "run.py",
            "read": "read-check.py",
            "write": "full-write.py",
            "policy": "trace.py",
        }[args.stage]
        execute(
            args.stage,
            [sys.executable, CAFFEINE / runner, *shared, "--output", output / args.stage],
        )
    record.update(status="passed", finishedUtc=datetime.now(UTC).isoformat())
    record_path.write_text(json.dumps(record, indent=2) + "\n")


if __name__ == "__main__":
    main()
