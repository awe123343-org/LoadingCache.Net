"""Reject malformed read reports while accepting both supported probe schemas."""

import argparse
import copy
import importlib.util
import json
from pathlib import Path


def load(path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    options = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    contract = load(root / "caffeine-read-20260913/run.py")
    reader = load(root / "caffeine-comprehensive-20260913/read-check.py")
    fixture = (
        root / "caffeine-comprehensive-20260913/resident-read/round1-1024-1-hot-1-off-net8.json"
    )
    report = json.loads(fixture.read_text())
    case = next(contract.cases())
    reader.validate_read_contract(contract, report, case, 3, 5)
    version2 = dict(
        report,
        schemaVersion=2,
        backend="loadingcache",
        keyMode="native",
        expiration="none",
        backendAssemblySha256=report["cacheAssemblySha256"],
    )
    try:
        contract.validate(version2, case, 3, 5)
    except AssertionError:
        pass
    else:
        raise AssertionError("The old validator no longer reproduces the schema mismatch")
    original = copy.deepcopy(version2)
    reader.validate_read_contract(contract, version2, case, 3, 5)
    assert version2 == original
    controls = []
    for field, value in (
        ("schemaVersion", 3),
        ("backend", "memorycache"),
        ("keyMode", "preboxed"),
        ("expiration", "write"),
        ("backendAssemblySha256", "invalid"),
    ):
        controls.append((field, dict(version2, **{field: value})))
    for field in ("checksum", "misses", "residentCount", "hitsDelta"):
        changed = copy.deepcopy(version2)
        changed["samples"][0][field] += 1
        controls.append((field, changed))
    for field, changed in controls:
        try:
            reader.validate_read_contract(contract, changed, case, 3, 5)
        except AssertionError:
            continue
        raise AssertionError(f"Accepted an invalid {field}")
    result = {
        "oldSchemaMismatchReproduced": True,
        "v1Accepted": True,
        "v2AcceptedWithoutMutation": True,
        "rejectedControls": [name for name, _ in controls],
    }
    options.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
