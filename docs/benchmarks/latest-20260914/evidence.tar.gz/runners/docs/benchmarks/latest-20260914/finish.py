"""Check completed matrices, summarize current results, and seal their raw evidence."""

import argparse
import gzip
import hashlib
import importlib.util
import json
import shutil
import statistics
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

REPO = Path(__file__).resolve().parents[3]


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def distribution(values):
    return {"min": min(values), "median": statistics.median(values), "max": max(values)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root, output = args.input.resolve(), args.output.resolve()
    if output == root or root in output.parents:
        parser.error("Report output must be outside the raw evidence directory")
    output.mkdir(parents=True, exist_ok=True)
    for stage in ("prepare", "smoke", "scenario", "read", "write", "policy", "memorycache"):
        record = read(root / f"{stage}-execution.json")
        assert record["status"] == "passed", stage
        assert all(c["exitCode"] == 0 for c in record["commands"]), stage
        coordinator = Path(__file__).with_name("run.py")
        if stage == "prepare" and sha(coordinator) != record["runnerSha256"]:
            coordinator = root / "runner-versions/prepare-run.py"
        assert sha(coordinator) == record["runnerSha256"], stage
    frozen = read(root / "source/manifest.json")
    frozen_root = Path(frozen["root"])
    for name, expected in {**frozen["sourceFiles"], **frozen["binaries"]}.items():
        assert sha(frozen_root / name) == expected, name
    core = {p: h for p, h in frozen["sourceFiles"].items() if p.startswith("src/LoadingCache/")}
    for name, expected in core.items():
        assert sha(REPO / name) == expected, name
    memory = root / "memorycache"
    memory_sources = read(memory / "source-manifest.json")
    assert {p: h for p, h in memory_sources.items() if p in core} == core
    for name, expected in memory_sources.items():
        assert sha(memory / "executed-source" / name) == expected, name
        assert sha(REPO / name) == expected, f"MemoryCache comparison source changed: {name}"
    memory_binaries = read(memory / "binary-manifest.json")
    for name, expected in memory_binaries.items():
        assert sha(memory / name) == expected, name
        parts = Path(name).parts
        probe = parts[2]
        original = REPO / f"tools/LoadingCache.{probe}/bin/Release/{parts[1]}.0" / Path(*parts[3:])
        assert sha(original) == expected, f"Prepared repo binary changed: {original}"
    for name, expected in read(memory / "runtime-manifest.json").items():
        assert sha(REPO / name) == expected, name
    cases = {c["id"]: c for c in read(memory / "cases.json")}
    for entry in read(memory / "results.json"):
        raw = read(memory / entry["id"] / "raw.json")
        case = cases[entry["case"]]
        if case["kind"] != "read":
            continue
        assert raw["schemaVersion"] == 2
        assert raw["backend"] == entry["backend"]
        for name, value in case["config"].items():
            field = {"key_mode": "keyMode"}.get(name, name)
            assert raw[field] == (value == "on" if name == "statistics" else value), field
        dll = (
            "LoadingCache.dll"
            if entry["backend"] == "loadingcache"
            else "Microsoft.Extensions.Caching.Memory.dll"
        )
        assert (
            raw["backendAssemblySha256"].lower()
            == memory_binaries[f"frozen/net{entry['runtime']}/HitProbe/{dll}"]
        )
    caffeine_dir = REPO / "docs/benchmarks/caffeine-comprehensive-20260913"
    contract = load(REPO / "docs/benchmarks/caffeine-read-20260913/run.py")
    reader = load(caffeine_dir / "read-check.py")
    observed = {}
    commands = read(root / "read/commands.json")
    assert commands["status"] == "passed" and len(commands["commands"]) == 156
    assert commands["sourceManifestSha256"] == sha(root / "source/manifest.json")
    assert sha(caffeine_dir / "read-check.py") == commands["runnerSha256"]
    for entry in commands["commands"]:
        path = root / "read" / entry["raw"]
        assert sha(path) == entry["rawSha256"] and entry["validated"]
        report = read(path)
        reader.validate_read_contract(contract, report, entry["case"], 3, 5)
        observed[entry["round"], contract.case_name(entry["case"]), entry["runtime"]] = report
    recalculated = reader.summarize(observed, list(contract.cases()), contract.case_name)
    reads = read(root / "read/summary.json")
    assert reads["timing"] == recalculated["timing"]
    assert reads["allocation"] == recalculated["allocation"]
    for stage in ("scenario", "write", "policy"):
        manifest = read(root / stage / "commands.json")
        assert manifest["status"] == "passed"
        assert manifest["sourceManifestSha256"] == sha(root / "source/manifest.json"), stage
        runner = {"scenario": "run.py", "write": "full-write.py", "policy": "trace.py"}[stage]
        if "runnerSha256" in manifest:
            assert sha(caffeine_dir / runner) == manifest["runnerSha256"], runner
        for name, expected in manifest.get("inputHashes", {}).items():
            assert sha(Path(name)) == expected, name
        for entry in manifest["commands"]:
            assert entry["exitCode"] == 0 and entry["validated"]
            expected = entry.get("rawSha256", entry.get("sha256"))
            assert sha(root / stage / entry["raw"]) == expected
    scenarios = read(root / "scenario/summary.json")
    writes = read(root / "write/summary.json")
    policies = read(root / "policy/summary.json")
    assert len(scenarios) == 82 and len(writes["timing"]) == 48 and len(policies) == 24
    writer = load(caffeine_dir / "full-write.py")
    write_contract = load(REPO / "docs/benchmarks/resident-replacement-20260913/compare.py")
    dotnet = {
        runtime: writer.validate_dotnet(
            root / f"write/{runtime}.json", runtime, write_contract, frozen
        )
        for runtime in ("net8", "net10")
    }
    write_commands = read(root / "write/commands.json")
    java, _ = writer.validate_java(
        root / "write/caffeine.json",
        Path(write_commands["executables"]["caffeine"]["path"]),
        write_contract,
    )
    recomputed_write = writer.summarize(dotnet, java, write_contract.expected_configurations())
    assert writes["timing"] == recomputed_write["timing"]
    assert writes["allocation"] == recomputed_write["allocation"]
    for row in scenarios:
        for runtime in ("net8", "net10", "caffeine"):
            values = []
            for round_index in (1, 2):
                report = read(
                    root
                    / f"scenario/round{round_index}-{row['scenario']}-{row['statistics']}-{runtime}.json"
                )
                costs = [
                    s["seconds"] * 1e9 / s["operations"]
                    for s in report["samples"]
                    if not s["warmup"] and s["operations"]
                ]
                assert (statistics.median(costs) if costs else None) == row[
                    f"{runtime}_round{round_index}_median_ns"
                ]
                values.extend(costs)
            assert (statistics.median(values) if values else None) == row[
                f"{runtime}_median_ns_per_operation"
            ]
        for runtime in ("net8", "net10"):
            expected = (
                row[f"{runtime}_median_ns_per_operation"] / row["caffeine_median_ns_per_operation"]
                if row["timing_comparable"]
                else None
            )
            assert row[f"{runtime}_over_caffeine"] == expected
    for row in policies:
        for runtime in ("net8", "net10", "caffeine"):
            report = read(root / f"policy/{row['trace']}-{row['capacity']}-{runtime}.json")
            hits = [s["hits"] for s in report["samples"]]
            assert all(s["hits"] + s["misses"] == row["requests"] for s in report["samples"])
            assert row[f"{runtime}_hits"] == statistics.median(hits)
            assert row[f"{runtime}_hit_ratio"] == statistics.median(hits) / row["requests"]
    summary = {
        "sourceCommit": frozen["gitHead"],
        "coreSourceFiles": len(core),
        "sameCoreSourceAcrossComparisons": True,
        "caffeine": {},
        "memorycache": read(root / "memorycache-analysis/verified-summary.json"),
    }
    assert summary["memorycache"]["sourceCommit"] == frozen["gitHead"]
    assert read(memory / "machine.json")["gitHead"] == frozen["gitHead"]
    if (root / "validation/summary.json").exists():
        validation = read(root / "validation/summary.json")
        namespace = {"t": "http://microsoft.com/schemas/VisualStudio/TeamTest/2010"}
        for row in validation["tests"]:
            counters = (
                ET.parse(root / "validation" / row["file"]).find(".//t:Counters", namespace).attrib
            )
            assert all(
                int(counters[k]) == row[k] for k in ("total", "passed", "failed", "notExecuted")
            )
            assert row["failed"] == row["notExecuted"] == 0
        assert sum(row["passed"] for row in validation["tests"]) == validation["passed"]
        summary["validation"] = validation
        shutil.copyfile(root / "validation/summary.json", output / "validation-summary.json")
    if (root / "first-attempt").exists():
        attempts = read(root / "first-attempt/memorycache/results.json")
        assert attempts[-1]["exitCode"] != 0
        summary["firstMemoryCacheAttempt"] = {
            "completedProcesses": sum(r["exitCode"] == 0 for r in attempts),
            "failure": attempts[-1],
            "includedInPerformanceSummary": False,
        }
        for group, failed in (("controlled-red", 2), ("controlled-green-final", 0)):
            folder = root / "cleanup-investigation" / group
            for name, expected in read(folder / "manifest.json").items():
                if not name.startswith("bin/"):
                    assert sha(folder / "source" / name) == expected, name
            for path in folder.glob("*.trx"):
                counters = (
                    ET.parse(path)
                    .find(".//{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}Counters")
                    .attrib
                )
                assert int(counters["failed"]) == failed and int(counters["passed"]) == 4 - failed
    for runtime in ("net8", "net10"):
        summary["caffeine"][runtime] = {
            "readCostRatio": distribution(
                [r[f"{runtime}_over_caffeine_pooled"] for r in reads["timing"]]
            ),
            "readLowerCostCases": sum(
                r[f"{runtime}_over_caffeine_pooled"] < 1 for r in reads["timing"]
            ),
            "readRoundDirectionDisagreements": sum(
                (r[f"{runtime}_over_caffeine_round1"] < 1)
                != (r[f"{runtime}_over_caffeine_round2"] < 1)
                for r in reads["timing"]
            ),
            "writeCostRatio": distribution(
                [r[f"{runtime}_over_caffeine_total_mean_ratio"] for r in writes["timing"]]
            ),
            "writeLowerCostCases": sum(
                r[f"{runtime}_over_caffeine_total_mean_ratio"] < 1 for r in writes["timing"]
            ),
            "policyHitRateDifferencePp": distribution(
                [100 * (r[f"{runtime}_hit_ratio"] - r["caffeine_hit_ratio"]) for r in policies]
            ),
        }
    (output / "verified-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    for stage in ("scenario", "read", "write", "policy", "memorycache-analysis"):
        destination = output / stage
        destination.mkdir(exist_ok=True)
        for path in (root / stage).iterdir():
            if (
                path.name
                in ("summary.json", "comparison.csv", "comparison.json", "verified-summary.json")
                or path.suffix == ".csv"
            ):
                if path.suffix == ".csv":
                    (destination / path.name).write_text(path.read_text())
                else:
                    shutil.copyfile(path, destination / path.name)
    # Runtimes and compiled dependencies stay local; exact identities remain in manifests.
    files = {
        str(p.relative_to(root)): p
        for p in root.rglob("*")
        if p.is_file() and "frozen" not in p.relative_to(root).parts
    }
    for folder in (
        caffeine_dir,
        REPO / "docs/benchmarks/memorycache-20260914",
        Path(__file__).parent,
    ):
        for path in folder.glob("*.py"):
            files["runners/" + str(path.relative_to(REPO))] = path
    dependency = REPO / "docs/benchmarks/caffeine-read-20260913/run.py"
    files["runners/" + str(dependency.relative_to(REPO))] = dependency
    write_commands = read(root / "write/commands.json")
    for name, expected in {
        **write_commands["dependencyHashes"],
        **write_commands["javaInputHashes"],
    }.items():
        path = REPO / name
        assert sha(path) == expected, name
        if path.suffix != ".jar":
            files["runners/" + name] = path
    assert not any(
        p.suffix in (".dll", ".exe", ".so", ".dylib", ".jar", ".class", ".nupkg", ".pdb")
        for p in files.values()
    )
    hashes = {name: sha(path) for name, path in sorted(files.items())}
    archive_path = output / "evidence.tar.gz"
    with archive_path.open("wb") as stream:
        with gzip.GzipFile(fileobj=stream, mode="wb", mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w") as archive:
                for name, path in sorted(files.items()):
                    info = archive.gettarinfo(str(path), name)
                    info.uid = info.gid = info.mtime = 0
                    info.uname = info.gname = ""
                    with path.open("rb") as source:
                        archive.addfile(info, source)
    with tarfile.open(archive_path) as archive:
        assert len(archive.getmembers()) == len(hashes)
        for name, expected in hashes.items():
            assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected
    (output / "evidence-manifest.json").write_text(
        json.dumps({"archiveSha256": sha(archive_path), "files": hashes}, indent=2) + "\n"
    )
    print(json.dumps(summary, indent=2))
    print(f"Verified {len(hashes)} archive members, {archive_path.stat().st_size} bytes")


if __name__ == "__main__":
    main()
