"""Compare policy hit rates on byte-identical traces; timings are not benchmark claims."""

import argparse
import bisect
import csv
import hashlib
import json
import pathlib
import random
import statistics
import subprocess
from collections import OrderedDict


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().lower()


def traces(count):
    rng = random.Random(20260913)
    cdf = []
    total = 0.0
    for rank in range(1, 2049):
        total += rank**-1.1
        cdf.append(total)
    return {
        "scan": list(range(count)),
        "cycle": [i % 512 for i in range(count)],
        "uniform": [rng.randrange(2048) for _ in range(count)],
        "zipf": [bisect.bisect_left(cdf, rng.random() * total) for _ in range(count)],
        "hotset-scan": [10_000 + i if i % 10 == 0 else rng.randrange(128) for i in range(count)],
        "phase-changing": [
            10_000 + i if i % 10 == 0 else (i * 4 // count) * 256 + rng.randrange(128)
            for i in range(count)
        ],
    }


def lru_hits(trace, maximum):
    cache = OrderedDict()
    hits = 0
    for key in trace:
        if key in cache:
            hits += 1
            cache.move_to_end(key)
        else:
            cache[key] = None
            if len(cache) > maximum:
                cache.popitem(last=False)
    return hits


def main():
    if not __debug__:
        raise RuntimeError("Validation requires Python assertions to be enabled")
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=pathlib.Path, required=True)
    parser.add_argument("--output", type=pathlib.Path, required=True)
    parser.add_argument("--runtime8", required=True)
    parser.add_argument("--runtime10", required=True)
    parser.add_argument("--java", required=True)
    parser.add_argument("--requests", type=int, default=100_000)
    parser.add_argument("--runs", type=int, default=3)
    parser.add_argument("--capacities", nargs="+", type=int, default=[64, 128, 512, 1024])
    options = parser.parse_args()
    if (
        not 2 <= options.requests <= 1_000_000
        or options.runs < 1
        or any(capacity < 64 for capacity in options.capacities)
    ):
        parser.error("Use 2..1,000,000 requests, positive runs, and capacities >= 64")
    frozen = json.loads(options.manifest.read_text())
    root = pathlib.Path(frozen["root"])
    tracked = {
        root / path: expected.lower()
        for path, expected in {**frozen["sourceFiles"], **frozen["binaries"]}.items()
    }
    tracked.update(
        {
            options.manifest.resolve(): sha(options.manifest),
            pathlib.Path(__file__).resolve(): sha(pathlib.Path(__file__)),
        }
    )
    for executable in (options.runtime8, options.runtime10, options.java):
        path = pathlib.Path(executable).resolve()
        tracked[path] = sha(path)

    def verify_inputs():
        for path, expected in tracked.items():
            assert sha(path) == expected, path

    verify_inputs()
    output = options.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    bases = {
        "net8": [
            options.runtime8,
            str(
                root
                / "tools/LoadingCache.ScenarioProbe/bin/Release/net8.0/LoadingCache.ScenarioProbe.dll"
            ),
        ],
        "net10": [
            options.runtime10,
            str(
                root
                / "tools/LoadingCache.ScenarioProbe/bin/Release/net10.0/LoadingCache.ScenarioProbe.dll"
            ),
        ],
        "caffeine": [
            options.java,
            "-cp",
            str(root / "java-classes") + ":" + str(root / "caffeine-3.2.4.jar"),
            "ScenarioProbe",
        ],
    }
    manifest = {
        "status": "running",
        "sourceManifest": str(options.manifest.resolve()),
        "sourceManifestSha256": sha(options.manifest),
        "inputHashes": {str(path): digest for path, digest in tracked.items()},
        "commands": [],
        "seed": 20260913,
        "scope": "serial policy simulation; clean up after each request; not throughput or latency",
    }

    def save():
        (output / "commands.json").write_text(json.dumps(manifest, indent=2) + "\n")

    save()
    rows = []
    for name, trace in traces(options.requests).items():
        trace_path = output / f"trace-{name}.json"
        trace_path.write_text(json.dumps(trace, separators=(",", ":")) + "\n")
        for capacity in options.capacities:
            row = {
                "trace": name,
                "trace_sha256": sha(trace_path),
                "capacity": capacity,
                "requests": len(trace),
                "lru_hits": lru_hits(trace, capacity),
            }
            for label, base in bases.items():
                path = output / f"{name}-{capacity}-{label}.json"
                assert sha(trace_path) == row["trace_sha256"]
                argv = base + [
                    "--scenario",
                    "trace-policy",
                    "--trace-file",
                    str(trace_path),
                    "--cycles",
                    str(len(trace)),
                    "--capacity",
                    str(capacity),
                    "--warmups",
                    "0",
                    "--runs",
                    str(options.runs),
                    "--statistics",
                    "on",
                    "--output",
                    str(path),
                ]
                with path.with_suffix(".log").open("w") as stream:
                    result = subprocess.run(
                        argv, stdout=stream, stderr=subprocess.STDOUT, timeout=180
                    )
                manifest["commands"].append(
                    {"argv": argv, "exitCode": result.returncode, "raw": path.name}
                )
                save()
                assert result.returncode == 0, path
                report = json.loads(path.read_text())
                expected_runtime = {
                    "net8": ".NET 8.0.31",
                    "net10": ".NET 10.0.12",
                    "caffeine": "25.0.4",
                }[label]
                assert (
                    report["runtime"].startswith(expected_runtime)
                    if label == "caffeine"
                    else report["runtime"] == expected_runtime
                )
                if label == "caffeine":
                    classes = {
                        pathlib.Path(name).name: digest.lower()
                        for name, digest in frozen["binaries"].items()
                        if name.startswith("java-classes/ScenarioProbe") and name.endswith(".class")
                    }
                    assert report["harnessClassHashes"] == classes
                    harness_hash = hashlib.sha256(
                        json.dumps(classes, sort_keys=True, separators=(",", ":")).encode()
                    ).hexdigest()
                    cache_hash = frozen["binaries"]["caffeine-3.2.4.jar"]
                else:
                    base_path = f"tools/LoadingCache.ScenarioProbe/bin/Release/{'net8.0' if label == 'net8' else 'net10.0'}"
                    harness_hash = frozen["binaries"][base_path + "/LoadingCache.ScenarioProbe.dll"]
                    cache_hash = frozen["binaries"][base_path + "/LoadingCache.dll"]
                assert report["harnessSha256"].lower() == harness_hash.lower()
                assert report["cacheSha256"].lower() == cache_hash.lower()
                expected_options = {
                    "scenario": "trace-policy",
                    "cycles": len(trace),
                    "capacity": capacity,
                    "warmups": 0,
                    "runs": options.runs,
                    "statistics": True,
                    "seed": 419,
                    "fanIn": 16,
                }
                assert all(
                    report["options"][key] == value for key, value in expected_options.items()
                )
                assert report["schemaVersion"] == 1
                assert report["traceSha256"].lower() == row["trace_sha256"] == sha(trace_path)
                assert len(report["samples"]) == options.runs
                for index, sample in enumerate(report["samples"]):
                    assert (
                        sample["name"] == "trace-policy"
                        and sample["index"] == index
                        and not sample["warmup"]
                    )
                    assert sample["validated"] and sample["hits"] + sample["misses"] == len(trace)
                    assert (
                        0 <= sample["finalCount"] <= capacity
                        and 0 <= sample["finalWeight"] <= capacity
                    )
                    assert (
                        sample["operations"] == len(trace) + sample["misses"]
                        and sample["maximum"] == capacity
                    )
                    assert sample["backendCalls"] == 0 and sample["bulkCalls"] == 0
                    assert sample["maintenanceBacklog"] in (None, 0)
                manifest["commands"][-1].update(
                    validated=True,
                    rawSha256=sha(path),
                    logSha256=sha(path.with_suffix(".log")),
                    actualRuntime=report["runtime"],
                )
                save()
                hits = [sample["hits"] for sample in report["samples"]]
                row[f"{label}_hits"] = statistics.median(hits)
                row[f"{label}_min_hits"] = min(hits)
                row[f"{label}_max_hits"] = max(hits)
                row[f"{label}_hit_ratio"] = statistics.median(hits) / len(trace)
            rows.append(row)
            print(name, capacity, {k: v for k, v in row.items() if k.endswith("_hits")}, flush=True)
    (output / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")
    with (output / "comparison.csv").open("w") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    verify_inputs()
    for row in rows:
        assert sha(output / f"trace-{row['trace']}.json") == row["trace_sha256"]
    manifest["inputsUnchanged"] = True
    manifest["status"] = "passed"
    save()


if __name__ == "__main__":
    main()
