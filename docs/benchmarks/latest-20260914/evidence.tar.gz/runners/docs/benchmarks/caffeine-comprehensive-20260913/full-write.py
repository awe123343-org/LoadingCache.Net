"""Run one serial 48-case write-and-drain matrix with explicitly different .NET/JMH protocols."""

import argparse
import csv
import datetime
import hashlib
import json
import math
import os
import pathlib
import platform
import statistics
import subprocess
import time
import types
import zipfile

JAVA_BASE = "benchmarks/LoadingCache.Benchmarks/caffeine-write/"
JAVA_INPUTS = {
    JAVA_BASE
    + "target/caffeine-write-jmh-1.0-SNAPSHOT.jar": "fbde2b0d93ce20970420d7ced8b2c8d0d9f99a1ec8db35b105160da01bb6995c",
    JAVA_BASE
    + "src/main/java/baseline/CaffeineWriteDrainBenchmark.java": "55cf8e039a96b0ba7e6d0219757b0458c2c1b5c7566d273b24a86d0c74a28000",
    JAVA_BASE + "pom.xml": "b6cdcb3b9e6fa987d559a9412094448be30aa0108ffe580484277edbbd581ae9",
}
DEPENDENCIES = {
    "docs/benchmarks/resident-replacement-20260913/compare.py": "4841d4cfb6ee11ac4ee899ee15ea3f5593c4fe63d081b055b5167865fb77bda4",
    "docs/benchmarks/resident-replacement-20260913/java-fresh-source.json": "919ea745d2289a21d4b50e3ec4feae1cdc2afc2018d3c2b2f459fae2b54c9266",
    "docs/benchmarks/write-path-20260913/caffeine/final-source.json": "17c3849dc87812808d11b93bef188457d006d21fa5ee0f89659948878cd16fd3",
}
BENCHMARK = "baseline.CaffeineWriteDrainBenchmark.putBatchAndQuiesce"
TARGET_OPERATIONS, WARMUPS, RUNS = 1_048_576, 3, 5
EXPECTED_RUNTIMES = {"net8": ".NET 8.0.31", "net10": ".NET 10.0.12", "caffeine": "25.0.4.1"}
EXPECTED_JAVA_VM = "25.0.4.1+1-LTS"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def check_java_provenance(repository, frozen_root):
    records = [
        json.loads((repository / name).read_text())
        for name in DEPENDENCIES
        if name.endswith(".json")
    ]
    for record in records:
        assert record["inputs"] == JAVA_INPUTS, "Historical Java source/jar identities disagree"
        assert record["caffeineRevision"] == "836b65c0a83e5d1641ded9c6de578654bc04b2e9"
    jar = repository / (JAVA_BASE + "target/caffeine-write-jmh-1.0-SNAPSHOT.jar")
    with (
        zipfile.ZipFile(jar) as shaded,
        zipfile.ZipFile(frozen_root / "caffeine-3.2.4.jar") as caffeine,
    ):
        assert (
            shaded.read("META-INF/maven/local.benchmark/caffeine-write-jmh/pom.xml")
            == (repository / (JAVA_BASE + "pom.xml")).read_bytes()
        )
        assert b"version=1.37" in shaded.read(
            "META-INF/maven/org.openjdk.jmh/jmh-core/pom.properties"
        )
        assert b"baseline.CaffeineWriteDrainBenchmark" in shaded.read("META-INF/BenchmarkList")
        classes = [
            name
            for name in caffeine.namelist()
            if name.startswith("com/github/benmanes/caffeine/") and name.endswith(".class")
        ]
        assert classes, "Frozen Caffeine jar contains no cache classes"
        for name in classes:
            assert shaded.read(name) == caffeine.read(name), (
                f"Shaded Caffeine class differs: {name}"
            )
    return {
        "basis": "Exact jar/source/pom identities match both pinned historical source records; embedded pom matches source pom; all Caffeine package classes match the final frozen Caffeine 3.2.4 jar. This reuses the recorded build, without claiming a new reproducible rebuild.",
        "inputs": JAVA_INPUTS,
        "sourceRecords": {
            name: digest for name, digest in DEPENDENCIES.items() if name.endswith(".json")
        },
        "matchedCaffeineClasses": len(classes),
        "caffeineRevision": records[0]["caffeineRevision"],
        "jmhVersion": "1.37",
    }


def validate_dotnet(path, label, contract, frozen):
    validated = contract.validate_dotnet_report(path, label)
    report = validated["report"]
    assert report["runtime"] == EXPECTED_RUNTIMES[label], report["runtime"]
    assert report["warmups"] == WARMUPS and report["runs"] == RUNS
    assert report["targetOperationsPerSample"] == TARGET_OPERATIONS
    assert all(value is None for value in report["runtimeEnvironment"].values())
    tfm = "net8.0" if label == "net8" else "net10.0"
    base = f"tools/LoadingCache.WriteProbe/bin/Release/{tfm}/"
    for field, name in (
        ("cacheAssemblySha256", "LoadingCache.dll"),
        ("harnessAssemblySha256", "LoadingCache.WriteProbe.dll"),
    ):
        assert report[field].lower() == frozen["binaries"][base + name].lower(), field
    for config, groups in validated["groups"].items():
        capacity, workers, writes, stats, mode = config
        batch_writes = workers * writes
        cycles = max(1, (TARGET_OPERATIONS + batch_writes * 8 - 1) // (batch_writes * 8))
        sweep_length = batch_writes * 4
        checksum = (
            sweep_length * ((2 * sweep_length if mode == "changed" else sweep_length) - 1) * cycles
        )
        for sample in [*groups["warmup"].values(), *groups["measured"].values()]:
            assert sample["kind"] == "caffeine" and sample["keyMode"] == "caffeine"
            assert sample["prefilledCount"] == 0 and sample["batches"] == cycles * 8
            assert sample["checksum"] == checksum, (config, sample["sampleIndex"], "checksum")
            assert 0 <= sample["finalEstimatedCount"] <= capacity
            assert (
                sample["finalWeightedSize"] is not None
                and 0 <= sample["finalWeightedSize"] <= capacity
            )
            assert sample["finalStatistics"]["maintenanceBacklog"] == 0
            assert sample["finalStatistics"]["writeBufferBacklog"] in (None, 0)
            for field in ("writeSeconds", "workerWriteSeconds", "drainSeconds", "setupSeconds"):
                assert contract.finite_number(sample[field], field) >= 0
            assert math.isclose(
                sample["timedSeconds"],
                sample["writeSeconds"] + sample["drainSeconds"],
                rel_tol=1e-12,
                abs_tol=1e-12,
            )
            for field in ("workerAllocatedBytes", "drainAllocatedBytes"):
                contract.integer(sample[field], field, minimum=0)
    return validated


def validate_java(path, java, contract):
    metrics = contract.validate_java_report(path)
    results = contract.load_json(path, "Caffeine")
    for result in results:
        assert result["benchmark"] == BENCHMARK and result["mode"] == "avgt"
        assert result["threads"] == 1 and result["forks"] == 1
        assert (
            result["jmhVersion"] == "1.37" and result["jdkVersion"] == EXPECTED_RUNTIMES["caffeine"]
        )
        assert result["vmVersion"] == EXPECTED_JAVA_VM, result["vmVersion"]
        assert pathlib.Path(result["jvm"]).resolve() == java
        assert result["jvmArgs"] == [], result["jvmArgs"]
        assert result["warmupIterations"] == 3 and result["warmupTime"] == "1 s"
        assert result["measurementIterations"] == 3 and result["measurementTime"] == "1 s"
        raw = result["primaryMetric"]["rawData"]
        assert len(raw) == 1 and len(raw[0]) == 3
        assert all(contract.finite_number(value, "JMH iteration ns/batch") > 0 for value in raw[0])
        allocation_raw = result["secondaryMetrics"]["gc.alloc.rate.norm"]["rawData"]
        assert len(allocation_raw) == 1 and len(allocation_raw[0]) == 3
        assert all(
            contract.finite_number(value, "JMH iteration B/batch") >= 0
            for value in allocation_raw[0]
        )
        metrics[contract.java_config(result)]["iteration_ns_per_batch"] = raw[0]
    return metrics, results


def summarize(dotnet, java, configurations):
    timing, allocations = [], []
    for config in sorted(configurations):
        capacity, workers, writes, stats, mode = config
        row = {
            "capacity": capacity,
            "workers": workers,
            "writes_per_worker": writes,
            "statistics": stats,
            "value_mode": mode,
        }
        allocation = dict(row)
        for label, validated in dotnet.items():
            samples = list(validated["groups"][config]["measured"].values())
            for phase, field in (
                ("total", "timedSeconds"),
                ("write_with_coordination", "writeSeconds"),
                ("worker", "workerWriteSeconds"),
                ("drain", "drainSeconds"),
            ):
                values = [sample[field] * 1e9 / sample["totalOperations"] for sample in samples]
                row[f"{label}_{phase}_mean_ns_per_write"] = statistics.mean(values)
                row[f"{label}_{phase}_median_ns_per_write"] = statistics.median(values)
            for scope, field in (
                ("whole_process", "wholeProcessAllocatedBytes"),
                ("workers", "workerAllocatedBytes"),
                ("drain_process", "drainAllocatedBytes"),
            ):
                allocation[f"{label}_{scope}_mean_bytes_per_write"] = statistics.mean(
                    sample[field] / sample["totalOperations"] for sample in samples
                )
        java_case = java[config]
        row["caffeine_total_mean_ns_per_write"] = (
            java_case["ns_per_batch"] / java_case["batch_writes"]
        )
        row["caffeine_total_median_ns_per_write"] = (
            statistics.median(java_case["iteration_ns_per_batch"]) / java_case["batch_writes"]
        )
        row["caffeine_worker_mean_ns_per_write"] = None
        row["caffeine_drain_mean_ns_per_write"] = None
        allocation["caffeine_jmh_gc_mean_bytes_per_write"] = (
            java_case["bytes_per_batch"] / java_case["batch_writes"]
        )
        for label in dotnet:
            row[f"{label}_over_caffeine_total_mean_ratio"] = (
                row[f"{label}_total_mean_ns_per_write"] / row["caffeine_total_mean_ns_per_write"]
            )
        timing.append(row)
        allocations.append(allocation)
    return {
        "timingScope": "Complete logical write batches including coordination and cleanup to bounded stable state. .NET worker time sums the slowest worker duration per batch; it is not an additive component beside the write-with-coordination time. The Java harness exposes total batch time only; unavailable worker/drain splits are null.",
        "comparisonLimit": "One matrix per runtime, without paired reverse rounds. Different .NET and JMH harnesses/protocols; ratios are descriptive cross-runtime evidence, not an identical-harness causal experiment or per-request latency.",
        "normalization": ".NET seconds*1e9/totalOperations; Java JMH ns/batch divided by workers*writesPerWorker. .NET arithmetic mean of five measured samples compared with the JMH average-time score; medians retained separately. No latency percentiles are inferred.",
        "timing": timing,
        "allocation": {
            "comparableAcrossRuntimes": False,
            "scopes": {
                "dotnet_whole_process": "GC.GetTotalAllocatedBytes(false) delta covering all timed batches and drains; excludes initial trace/cache/worker setup.",
                "dotnet_workers": "Sum of current-thread allocation deltas around each worker put loop.",
                "dotnet_drain_process": "Sum of process allocation deltas during each drain; overlaps the whole-process measurement.",
                "caffeine_jmh_gc": "JMH 1.37 gc.alloc.rate.norm (GC profiler), normalized from B per complete benchmark batch. Profiler and live-thread coverage differ from the .NET counters; no cross-runtime allocation ratio is reported.",
            },
            "measurements": allocations,
        },
    }


def main():
    if not __debug__:
        raise RuntimeError("Run without Python optimization so evidence checks remain enabled.")
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("manifest", "output", "runtime8", "runtime10", "java"):
        parser.add_argument("--" + name, type=pathlib.Path, required=True)
    options = parser.parse_args()
    runner = pathlib.Path(__file__).resolve()
    repository = runner.parents[3]
    manifest_path = options.manifest.resolve()
    manifest_bytes = manifest_path.read_bytes()
    frozen = json.loads(manifest_bytes)
    root = pathlib.Path(frozen["root"]).resolve()
    executables = {
        "net8": options.runtime8.resolve(),
        "net10": options.runtime10.resolve(),
        "caffeine": options.java.resolve(),
    }
    tracked = {runner: sha(runner), manifest_path: hashlib.sha256(manifest_bytes).hexdigest()}
    tracked[manifest_path.parent / "source.tar.gz"] = frozen["sourceArchiveSha256"].lower()
    for group in ("sourceFiles", "binaries"):
        assert frozen[group], f"Empty {group}"
        for name, digest in frozen[group].items():
            path = (root / name).resolve()
            assert path.is_relative_to(root), name
            tracked[path] = digest.lower()
    for name, digest in {**JAVA_INPUTS, **DEPENDENCIES}.items():
        tracked[repository / name] = digest
    for executable in executables.values():
        tracked[executable] = sha(executable)
    environment = os.environ.copy()
    removed = {
        key: environment.pop(key)
        for key in list(environment)
        if key.startswith(("DOTNET_", "COMPlus_", "CORECLR_", "COR_"))
        or key in ("JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "_JAVA_OPTIONS")
    }
    output = options.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    state = {
        "schemaVersion": 1,
        "status": "running",
        "startedUtc": now(),
        "runnerSha256": tracked[runner],
        "sourceManifest": str(manifest_path),
        "sourceManifestSha256": tracked[manifest_path],
        "frozenGitHead": frozen["gitHead"],
        "frozenRoot": str(root),
        "host": {
            "platform": platform.platform(),
            "machine": platform.machine(),
            "logicalProcessors": os.cpu_count(),
        },
        "executables": {
            label: {"path": str(path), "sha256": tracked[path]}
            for label, path in executables.items()
        },
        "expectedRuntimes": EXPECTED_RUNTIMES,
        "expectedJavaVmVersion": EXPECTED_JAVA_VM,
        "runtimeEnvironment": {},
        "removedRuntimeEnvironment": removed,
        "dependencyHashes": DEPENDENCIES,
        "javaInputHashes": JAVA_INPUTS,
        "protocol": {
            "identicalHarness": False,
            "rounds": 1,
            "runtimeOrder": ["net8", "net10", "caffeine"],
            "casesPerRuntime": 48,
            "dotnet": {
                "warmups": WARMUPS,
                "runs": RUNS,
                "targetOperationsPerSample": TARGET_OPERATIONS,
                "processesPerRuntime": 1,
                "gc": "Harness forces a full collection before each measured sample; fresh cache and worker setup excluded from timing.",
            },
            "java": {
                "harness": "JMH 1.37",
                "forksPerCase": 1,
                "warmupIterations": 3,
                "measurementIterations": 3,
                "iterationSeconds": 1,
                "profiler": "gc",
                "jmhThreads": 1,
                "workerThreads": "workers parameter",
                "gc": "Default JMH behavior; no forced-GC flag. Workers persist for the trial, cache resets each iteration.",
            },
        },
        "commands": [],
        "metadataCommands": [],
        "inputVerification": {},
    }

    def save():
        (output / "commands.json").write_text(json.dumps(state, indent=2, allow_nan=False) + "\n")

    def verify(phase):
        mismatches = [
            str(path)
            for path, digest in tracked.items()
            if not path.is_file() or sha(path) != digest
        ]
        state["inputVerification"][phase] = {
            "checkedUtc": now(),
            "fileCount": len(tracked),
            "mismatches": mismatches,
        }
        assert not mismatches, f"Frozen input or Java provenance mismatch: {mismatches}"

    def execute(label, argv):
        path, log_path = output / f"{label}.json", output / f"{label}.log"
        entry = {
            "runtime": label,
            "argv": argv,
            "cwd": str(root),
            "raw": path.name,
            "log": log_path.name,
            "startedUtc": now(),
        }
        state["commands"].append(entry)
        save()
        print(f"Running complete 48-case {label} matrix", flush=True)
        started = time.monotonic()
        try:
            with log_path.open("w") as stream:
                result = subprocess.run(
                    argv,
                    cwd=root,
                    env=environment,
                    stdout=stream,
                    stderr=subprocess.STDOUT,
                    timeout=3600,
                    check=False,
                )
            entry["exitCode"] = result.returncode
            assert result.returncode == 0, f"Failed matrix: {log_path}"
            return path, entry
        except BaseException as error:
            entry["error"] = repr(error)
            raise
        finally:
            entry["finishedUtc"] = now()
            entry["elapsedSeconds"] = time.monotonic() - started
            for name, artifact in (("raw", path), ("log", log_path)):
                if artifact.is_file():
                    entry[name + "Sha256"] = sha(artifact)
            save()

    save()
    try:
        assert frozen["status"] == "built"
        verify("start")
        state["javaProvenance"] = check_java_provenance(repository, root)
        dependency_path = repository / "docs/benchmarks/resident-replacement-20260913/compare.py"
        dependency_bytes = dependency_path.read_bytes()
        assert hashlib.sha256(dependency_bytes).hexdigest() == tracked[dependency_path]
        contract = types.ModuleType("frozen_write_contract")
        contract.__file__ = str(dependency_path)
        exec(compile(dependency_bytes, str(dependency_path), "exec"), contract.__dict__)
        configurations = contract.expected_configurations()
        assert len(configurations) == 48
        for argv in (["git", "rev-parse", "HEAD"], ["git", "status", "--short"]):
            result = subprocess.run(
                argv, cwd=repository, text=True, capture_output=True, check=False
            )
            state["metadataCommands"].append(
                {
                    "argv": argv,
                    "cwd": str(repository),
                    "exitCode": result.returncode,
                    "stdout": result.stdout,
                    "stderr": result.stderr,
                }
            )
            assert result.returncode == 0
        (output / "frozen-manifest.json").write_text(json.dumps(frozen, indent=2) + "\n")
        save()
        dotnet = {}
        for label, tfm in (("net8", "net8.0"), ("net10", "net10.0")):
            base = f"tools/LoadingCache.WriteProbe/bin/Release/{tfm}/"
            argv = [
                str(executables[label]),
                str(root / (base + "LoadingCache.WriteProbe.dll")),
                "--suite",
                "caffeine",
                "--target-operations",
                str(TARGET_OPERATIONS),
                "--warmups",
                str(WARMUPS),
                "--runs",
                str(RUNS),
                "--label",
                label,
                "--no-progress",
                "--output",
                str(output / f"{label}.json"),
            ]
            path, entry = execute(label, argv)
            dotnet[label] = validate_dotnet(path, label, contract, frozen)
            report = dotnet[label]["report"]
            entry.update(
                validated=True,
                actualRuntime=report["runtime"],
                cacheAssemblySha256=report["cacheAssemblySha256"].lower(),
                harnessAssemblySha256=report["harnessAssemblySha256"].lower(),
                validatedCases=48,
                validatedSamples=len(report["samples"]),
            )
            save()
        jar = repository / (JAVA_BASE + "target/caffeine-write-jmh-1.0-SNAPSHOT.jar")
        argv = [
            str(executables["caffeine"]),
            "-jar",
            str(jar),
            BENCHMARK,
            "-f",
            "1",
            "-wi",
            "3",
            "-i",
            "3",
            "-w",
            "1s",
            "-r",
            "1s",
            "-prof",
            "gc",
            "-rf",
            "json",
            "-rff",
            str(output / "caffeine.json"),
            "-foe",
            "true",
        ]
        for parameter in (
            "capacity=1024,16384",
            "workers=1,4,10",
            "writesPerWorker=512,4096",
            "statistics=off,on",
            "valueMode=same,changed",
        ):
            argv.extend(["-p", parameter])
        path, entry = execute("caffeine", argv)
        java_metrics, java_results = validate_java(path, executables["caffeine"], contract)
        entry.update(
            validated=True,
            actualRuntime=java_results[0]["jdkVersion"],
            vmVersion=java_results[0]["vmVersion"],
            jvmArgs=java_results[0]["jvmArgs"],
            jarSha256=tracked[jar],
            validatedCases=len(java_metrics),
        )
        save()
        verify("end")
        summary = summarize(dotnet, java_metrics, configurations)
        summary.update(
            protocol=state["protocol"],
            sourceManifestSha256=tracked[manifest_path],
            runnerSha256=tracked[runner],
            javaProvenance=state["javaProvenance"],
            actualRuntimes={label: result["report"]["runtime"] for label, result in dotnet.items()}
            | {"caffeine": java_results[0]["vmVersion"]},
        )
        (output / "summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
        for name, rows in (
            ("comparison.csv", summary["timing"]),
            ("allocation.csv", summary["allocation"]["measurements"]),
        ):
            with (output / name).open("w", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
                writer.writeheader()
                writer.writerows(rows)
        state["status"] = "passed"
    except BaseException as error:
        state["status"] = "failed" if state["commands"] else "blocked"
        state["error"] = repr(error)
        try:
            verify("end")
        except BaseException as verification_error:
            state["endVerificationError"] = repr(verification_error)
        raise
    finally:
        state["finishedUtc"] = now()
        save()
    print(f"Validated 48 cases on all three runtimes: {output / 'summary.json'}", flush=True)


if __name__ == "__main__":
    main()
