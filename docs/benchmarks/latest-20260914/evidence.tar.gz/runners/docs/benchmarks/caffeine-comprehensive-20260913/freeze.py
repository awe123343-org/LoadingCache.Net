"""Freeze source and build probes before serial measurements; never edit production."""

import argparse
import hashlib
import json
import pathlib
import shutil
import subprocess
import tarfile
import tempfile


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=pathlib.Path, required=True)
    parser.add_argument("--caffeine-jar", type=pathlib.Path, required=True)
    parser.add_argument("--java-home", type=pathlib.Path, required=True)
    options = parser.parse_args()
    repo = pathlib.Path(__file__).resolve().parents[3]
    output = options.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    root = pathlib.Path(tempfile.mkdtemp(prefix="loadingcache-comprehensive-"))
    projects = ["HitProbe", "WriteProbe", "ScenarioProbe", "Simulator"]
    paths = ["src/LoadingCache"] + [f"tools/LoadingCache.{p}" for p in projects]
    paths += ["tools/LoadingCache.HitProbe.Java", "tools/LoadingCache.ScenarioProbe.Java"]
    sources = {
        name
        for name in subprocess.check_output(
            ["fd", "-t", "f", "--exclude", "bin", "--exclude", "obj", ".", *paths],
            cwd=repo,
            text=True,
        ).splitlines()
        if pathlib.Path(name).suffix in {".cs", ".csproj", ".java", ".md"}
    }
    sources.update(
        ["global.json", "Directory.Build.props", "Directory.Packages.props", "src/Package.props"]
    )
    source_hashes = {name: digest(repo / name) for name in sorted(sources)}
    for name in source_hashes:
        target = root / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(repo / name, target)
    assert source_hashes == {name: digest(root / name) for name in source_hashes}
    assert source_hashes == {name: digest(repo / name) for name in source_hashes}
    manifest = {
        "root": str(root),
        "gitHead": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=repo, text=True
        ).strip(),
        "sourceFiles": source_hashes,
        "commands": [],
        "binaries": {},
    }
    destination = output / "manifest.json"

    def save():
        destination.write_text(json.dumps(manifest, indent=2) + "\n")

    def execute(name, argv):
        log = output / f"{name}.log"
        with log.open("w") as stream:
            result = subprocess.run(argv, cwd=root, stdout=stream, stderr=subprocess.STDOUT)
        manifest["commands"].append(
            {"argv": argv, "cwd": str(root), "exitCode": result.returncode, "log": str(log)}
        )
        save()
        if result.returncode:
            raise RuntimeError(f"Build failed: {log}")

    save()
    for project in projects:
        execute(
            project,
            [
                "dotnet",
                "build",
                f"tools/LoadingCache.{project}/LoadingCache.{project}.csproj",
                "-c",
                "Release",
            ],
        )
    jar = root / "caffeine-3.2.4.jar"
    shutil.copyfile(options.caffeine_jar, jar)
    assert digest(jar) == "9d9d2cfd681fd9272ded3d27c9930db12f89f732345975aa113ebc223bbf1224"
    java_sources = [str(root / name) for name in source_hashes if name.endswith(".java")]
    classes = root / "java-classes"
    classes.mkdir()
    execute(
        "javac",
        [
            str(options.java_home / "bin/javac"),
            "--release",
            "25",
            "-cp",
            str(jar),
            "-d",
            str(classes),
            *java_sources,
        ],
    )
    for base in [root / "tools", classes]:
        for path in base.rglob("*"):
            if path.is_file() and ("bin" in path.parts or path.suffix == ".class"):
                manifest["binaries"][str(path.relative_to(root))] = digest(path)
    manifest["binaries"][jar.name] = digest(jar)
    assert source_hashes == {name: digest(root / name) for name in source_hashes}
    with tarfile.open(output / "source.tar.gz", "w:gz") as archive:
        for name in source_hashes:
            archive.add(root / name, arcname=name)
    manifest["sourceArchiveSha256"] = digest(output / "source.tar.gz")
    manifest["status"] = "built"
    save()
    print(destination)


if __name__ == "__main__":
    main()
