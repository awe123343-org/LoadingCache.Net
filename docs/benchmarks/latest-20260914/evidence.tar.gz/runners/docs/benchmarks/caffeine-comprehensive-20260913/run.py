"""Run frozen, matched scenario probes serially, preserving commands and failures."""

import argparse
import csv
import datetime
import hashlib
import json
import math
import pathlib
import re
import statistics
import subprocess


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().lower()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=pathlib.Path, required=True)
    parser.add_argument("--output", type=pathlib.Path, required=True)
    parser.add_argument("--runtime8", required=True)
    parser.add_argument("--runtime10", required=True)
    parser.add_argument("--java", required=True)
    parser.add_argument("--capacity", type=int, default=1024)
    parser.add_argument("--scenarios", nargs="*")
    parser.add_argument("--cycles", type=int, help="Fixed cycles; omit for measured calibration")
    parser.add_argument("--warmups", type=int, default=3)
    parser.add_argument("--runs", type=int, default=5)
    options = parser.parse_args()
    frozen = json.loads(options.manifest.read_text())
    root = pathlib.Path(frozen["root"])
    for name, expected in {**frozen["sourceFiles"], **frozen["binaries"]}.items():
        assert sha(root / name) == expected.lower(), f"Input changed: {name}"
    output = options.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    source = (root / "tools/LoadingCache.ScenarioProbe/Program.cs").read_text()
    names = re.findall(r'"([a-z-]+)"', source.split("Names =", 1)[1].split("];", 1)[0])
    names = options.scenarios or [name for name in names if name != "trace-policy"]
    bases = {
        "net8": [
            options.runtime8,
            str(
                root
                / "tools/LoadingCache.ScenarioProbe/bin/Release/net8.0/LoadingCache.ScenarioProbe.dll"
            ),
        ],
        "net10": [
            options.runtime10,
            str(
                root
                / "tools/LoadingCache.ScenarioProbe/bin/Release/net10.0/LoadingCache.ScenarioProbe.dll"
            ),
        ],
        "caffeine": [
            options.java,
            "-cp",
            str(root / "java-classes") + ":" + str(root / "caffeine-3.2.4.jar"),
            "ScenarioProbe",
        ],
    }
    runtimes = {"net8": ".NET 8.0.31", "net10": ".NET 10.0.12", "caffeine": "25.0.4"}
    manifest = {
        "status": "running",
        "runnerSha256": sha(pathlib.Path(__file__)),
        "sourceManifest": str(options.manifest.resolve()),
        "sourceManifestSha256": sha(options.manifest),
        "commands": [],
        "cycles": {},
    }
    destination = output / "commands.json"

    def save():
        destination.write_text(json.dumps(manifest, indent=2) + "\n")

    def execute(label, name, stats, cycles, phase, warmups, runs):
        stem = f"{phase}-{name}-{stats}-{label}"
        path = output / f"{stem}.json"
        argv = bases[label] + [
            "--scenario",
            name,
            "--cycles",
            str(cycles),
            "--capacity",
            str(options.capacity),
            "--statistics",
            stats,
            "--fan-in",
            "16",
            "--seed",
            "419",
            "--warmups",
            str(warmups),
            "--runs",
            str(runs),
            "--output",
            str(path),
        ]
        entry = {
            "phase": phase,
            "runtime": label,
            "scenario": name,
            "statistics": stats,
            "argv": argv,
            "startedUtc": datetime.datetime.now(datetime.UTC).isoformat(),
            "raw": path.name,
        }
        manifest["commands"].append(entry)
        save()
        print(stem, flush=True)
        with path.with_suffix(".log").open("w") as stream:
            result = subprocess.run(argv, stdout=stream, stderr=subprocess.STDOUT, timeout=180)
        entry["exitCode"] = result.returncode
        entry["finishedUtc"] = datetime.datetime.now(datetime.UTC).isoformat()
        save()
        assert result.returncode == 0, f"Probe failed: {path.with_suffix('.log')}"
        report = json.loads(path.read_text())
        assert report["runtime"].startswith(runtimes[label]), report["runtime"]
        cache_path = root / (
            "caffeine-3.2.4.jar"
            if label == "caffeine"
            else f"tools/LoadingCache.ScenarioProbe/bin/Release/{'net8.0' if label == 'net8' else 'net10.0'}/LoadingCache.dll"
        )
        cache_relative = str(cache_path.relative_to(root))
        harness_relative = (
            "java-classes/ScenarioProbe.class"
            if label == "caffeine"
            else str(pathlib.Path(cache_relative).with_name("LoadingCache.ScenarioProbe.dll"))
        )
        assert report["cacheSha256"].lower() == frozen["binaries"][cache_relative].lower()
        if label == "caffeine":
            classes = {
                pathlib.Path(path).name: value.lower()
                for path, value in frozen["binaries"].items()
                if path.startswith("java-classes/ScenarioProbe") and path.endswith(".class")
            }
            assert report["harnessClassHashes"] == classes
            expected_harness = hashlib.sha256(
                json.dumps(classes, sort_keys=True, separators=(",", ":")).encode()
            ).hexdigest()
        else:
            expected_harness = frozen["binaries"][harness_relative].lower()
        assert report["harnessSha256"].lower() == expected_harness
        expected_options = {
            "scenario": name,
            "cycles": cycles,
            "capacity": options.capacity,
            "fanIn": 16,
            "seed": 419,
            "statistics": stats == "on",
            "warmups": warmups,
            "runs": runs,
        }
        for key, expected in expected_options.items():
            assert report["options"][key] == expected, (key, report["options"], expected_options)
        assert report["schemaVersion"] == 1 and len(report["samples"]) == warmups + runs
        for index, sample in enumerate(report["samples"]):
            assert sample["validated"] and sample["name"] == name
            assert sample["index"] == index and sample["warmup"] == (index < warmups)
            assert sample["finalCount"] >= 0 and sample["finalWeight"] <= sample["maximum"]
            assert sample["maintenanceBacklog"] in (None, 0)
            assert math.isfinite(sample["seconds"]) and sample["seconds"] > 0
            assert sample["operations"] >= 0 and sample["backendCalls"] >= 0
        entry["validated"] = True
        entry["sha256"] = sha(path)
        save()
        return report

    for name in names:
        if (name.endswith("-cleanup") and name.startswith("weak-")) or name.endswith("-contract"):
            cycles = 32
        elif options.cycles:
            cycles = options.cycles
        else:
            calibrations = [
                execute(label, name, "off", 4096, "calibration", 1, 1)
                for label in ("net10", "caffeine")
            ]
            seconds = min(report["samples"][-1]["seconds"] for report in calibrations)
            # Same work for every runtime; calibration is excluded from reported timing.
            cycles = max(4096, min(1_000_000, math.ceil(0.25 / seconds * 4096)))
        manifest["cycles"][name] = cycles
        save()
    observed = {}
    for round_index in (1, 2):
        ordered = names if round_index == 1 else list(reversed(names))
        labels = list(bases) if round_index == 1 else list(reversed(bases))
        for name in ordered:
            for stats in ("off", "on"):
                for label in labels:
                    observed[round_index, name, stats, label] = execute(
                        label,
                        name,
                        stats,
                        manifest["cycles"][name],
                        f"round{round_index}",
                        options.warmups,
                        options.runs,
                    )
    policy_sensitive = {"size-churn", "weight-churn", "eviction-listener", "runtime-maximum"}
    for name in names:
        baseline = observed[1, name, "off", "net8"]["samples"]
        for r in (1, 2):
            for stats in ("off", "on"):
                for label in bases:
                    for expected, actual in zip(
                        baseline, observed[r, name, stats, label]["samples"], strict=True
                    ):
                        fields = ["operations", "backendCalls", "bulkCalls"]
                        if name not in policy_sensitive:
                            fields += ["checksum", "hits", "misses"]
                        for field in fields:
                            assert actual[field] == expected[field], (
                                r,
                                name,
                                stats,
                                label,
                                field,
                                expected[field],
                                actual[field],
                            )
    rows = []
    for name in names:
        for stats in ("off", "on"):
            row = {
                "scenario": name,
                "statistics": stats,
                "capacity": options.capacity,
                "cycles": manifest["cycles"][name],
            }
            comparable = not (
                name
                in (
                    "weak-key-cleanup",
                    "weak-value-cleanup",
                    "removal-listener",
                    "refresh-auto",
                    "runtime-refresh",
                )
                or name.startswith("trace-")
                or name.endswith("-contract")
            )
            row["timing_comparable"] = comparable
            for label in bases:
                samples = [
                    sample
                    for r in (1, 2)
                    for sample in observed[r, name, stats, label]["samples"]
                    if not sample["warmup"]
                ]
                costs = [
                    sample["seconds"] * 1e9 / sample["operations"]
                    for sample in samples
                    if sample["operations"]
                ]
                row[f"{label}_median_ns_per_operation"] = (
                    statistics.median(costs) if costs else None
                )
                row[f"{label}_minimum_sample_seconds"] = min(s["seconds"] for s in samples)
                row[f"{label}_backend_calls_per_sample"] = sorted(
                    set(s["backendCalls"] for s in samples)
                )
                for r in (1, 2):
                    values = [
                        s["seconds"] * 1e9 / s["operations"]
                        for s in observed[r, name, stats, label]["samples"]
                        if not s["warmup"] and s["operations"]
                    ]
                    row[f"{label}_round{r}_median_ns"] = (
                        statistics.median(values) if values else None
                    )
            for label in ("net8", "net10"):
                row[f"{label}_over_caffeine"] = (
                    row[f"{label}_median_ns_per_operation"]
                    / row["caffeine_median_ns_per_operation"]
                    if comparable
                    else None
                )
            rows.append(row)
    (output / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")
    with (output / "comparison.csv").open("w") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    for name, expected in {**frozen["sourceFiles"], **frozen["binaries"]}.items():
        assert sha(root / name) == expected.lower(), f"Input changed during run: {name}"
    assert sha(pathlib.Path(__file__)) == manifest["runnerSha256"]
    manifest["status"] = "passed"
    save()


if __name__ == "__main__":
    main()
