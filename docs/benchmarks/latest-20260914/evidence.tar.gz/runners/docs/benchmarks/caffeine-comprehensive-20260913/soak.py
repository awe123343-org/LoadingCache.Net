"""Run both prebuilt stability fixtures concurrently, preserving failure evidence.

This intentionally contends two runtimes and four parallel test cases. A concurrent
whole-core correctness loop may add load. Elapsed time is a duration/watchdog check;
neither operation rates nor process-wide allocation samples are performance claims.
No build, restore, fixture warmup, or test parallelism override is performed.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import pathlib
import shutil
import subprocess
import sys
import time
import types
import xml.etree.ElementTree as ET

# Refresh deliberately after formatting or reviewing the dependency, before a run.
DEPENDENCY_SHA256 = "e9dcc100cc640a3ee108cfdbcafe72b9ef7987187ec4041356067b71fdfe0738"
TEST_FILTER = "FullyQualifiedName~LoadingCache.StressTests.LongRunningStabilityTests"
TEST_NAMES = {
    "ContinuousMixedLifecycleMaintainsBounds(False)",
    "ContinuousMixedLifecycleMaintainsBounds(True)",
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def integer(value, minimum=0):
    return type(value) is int and value >= minimum


def finite(value, minimum=0):
    return type(value) in (int, float) and math.isfinite(value) and value >= minimum


def source_manifest(contract, root, runner):
    result = contract.source_manifest(root)
    names = (
        subprocess.check_output(
            [
                "git",
                "ls-files",
                "--cached",
                "--others",
                "--exclude-standard",
                "-z",
                "--",
                "tests/LoadingCache.StressTests",
            ],
            cwd=root,
        )
        .decode()
        .split("\0")
    )
    for name in names:
        if name and (root / name).is_file():
            result[name] = contract.sha(root / name)
    result[str(runner.relative_to(root))] = contract.sha(runner)
    return dict(sorted(result.items()))


def inspect_trx(path):
    document = ET.parse(path).getroot()
    counters = document.find(".//{*}ResultSummary/{*}Counters")
    require(counters is not None, "Missing TRX counters")
    expected = {"total": 2, "executed": 2, "passed": 2, "failed": 0, "notExecuted": 0}
    counts = {key: int(counters.get(key, "0")) for key in expected}
    require(counts == expected, f"Expected two passing soak cases: {counts}")
    results = document.findall(".//{*}Results/{*}UnitTestResult")
    names = [result.get("testName", "").rsplit(".", 1)[-1] for result in results]
    require(len(results) == 2 and set(names) == TEST_NAMES, f"Unexpected soak cases: {names}")
    require(
        all(result.get("outcome") == "Passed" for result in results), "A soak case did not pass"
    )
    return {
        "accepted": True,
        "counts": counts,
        "tests": [dict(result.attrib) for result in results],
    }


def read_records(path):
    records = []
    error = None
    with path.open(encoding="utf-8") as stream:
        for number, line in enumerate(stream, 1):
            try:
                record = json.loads(line)
                require(isinstance(record, dict), "JSONL record must be an object")
                records.append(record)
            except (ValueError, TypeError) as failure:
                error = f"Line {number}: {failure}"
                break
    return records, error


def inspect_jsonl(path, framework, seconds, contract):
    records, error = read_records(path)
    require(error is None, f"Invalid JSONL {path}: {error}")
    require(len(records) >= 4, f"Incomplete JSONL: {path}")
    start, terminal = records[0], records[-1]
    require(
        start.get("Event") == "start" and terminal.get("Event") == "passed",
        f"Missing terminal passed: {path}",
    )
    require(
        start.get("Runtime") == ".NET " + contract.EXPECTED_RUNTIME_VERSIONS[framework],
        "JSONL runtime mismatch",
    )
    require(
        type(start.get("statistics")) is bool and start.get("seconds") == seconds,
        "JSONL fixture options mismatch",
    )
    require(
        (
            start.get("Seed"),
            start.get("Workers"),
            start.get("OperationsPerBatch"),
            start.get("LoadLimit"),
        )
        == (20260913, 8, 64, 4),
        "Fixture workload contract changed",
    )
    require(
        bool(start.get("CoreModule")) and bool(start.get("TestModule")), "Missing module identities"
    )
    previous_elapsed = 0
    previous_batch = 0
    cycle = 0
    complete = None
    progress_count = 0
    for index, record in enumerate(records[1:], 1):
        event = record.get("Event")
        require(
            event in ("progress", "recreated", "workload-complete", "passed"),
            f"Unexpected or failing event: {event}",
        )
        require(
            finite(record.get("ElapsedSeconds"), previous_elapsed),
            "Elapsed duration moved backwards or is invalid",
        )
        require(
            integer(record.get("batch"), max(1, previous_batch)),
            "Batch count moved backwards or is invalid",
        )
        if event == "recreated":
            cycle += 1
        require(record.get("cycle") == cycle, "Cache generation or recreation sequence mismatch")
        if event == "passed":
            require(
                index == len(records) - 1 and complete is not None,
                "Passed must follow workload-complete and disposal",
            )
            require(
                record["batch"] == complete["batch"] and record["cycle"] == complete["cycle"],
                "Terminal workload totals changed",
            )
        else:
            require(complete is None, "Work continued after workload-complete")
            require(
                record.get("Operations") == record["batch"] * 8 * 64,
                "Operation count does not match completed batches",
            )
            outcomes = record.get("outcomes", [])
            require(
                len(outcomes) == 3 and all(integer(value) for value in outcomes),
                "Invalid outcome counters",
            )
            require(
                sum(outcomes) == record["Operations"],
                "Outcomes do not cover all completed operations",
            )
            caches = record.get("Caches", [])
            require(
                len(caches) == 3 and {cache.get("Mode") for cache in caches} == {0, 1, 2},
                "Missing cache lifecycle modes",
            )
            for cache in caches:
                mode = cache["Mode"]
                require(
                    cache.get("Instance") == cycle * 3 + mode, "Stale cache generation in progress"
                )
                require(
                    integer(cache.get("Peak")) and cache["Peak"] <= 4,
                    "Execution permit bound exceeded",
                )
                require(
                    integer(cache.get("Residents")) and cache["Residents"] <= 64,
                    "Resident bound exceeded",
                )
                require(
                    integer(cache.get("Weight")) and cache["Weight"] <= (64 if mode == 0 else 384),
                    "Weight exceeds workload bounds",
                )
                if mode == 0:
                    require(
                        cache["Weight"] == cache["Residents"], "Unweighted count and weight differ"
                    )
                require(
                    integer(cache.get("Loads")) and integer(cache.get("ClockTicks")),
                    "Invalid load or clock counter",
                )
                stats = cache.get("Statistics", {})
                require(
                    all(
                        stats.get(key) == 0
                        for key in ("InFlightLoads", "MaintenanceBacklog", "WriteBufferBacklog")
                    ),
                    "Snapshot is not quiescent",
                )
                if not start["statistics"]:
                    require(
                        stats.get("Hits") == 0 and stats.get("LoadsStarted") == 0,
                        "Disabled statistics were incremented",
                    )
            require(record.get("forcedGc") is (event == "recreated"), "GC sample event mismatch")
            require(
                all(
                    integer(record.get(key))
                    for key in (
                        "ManagedBytes",
                        "HeapSizeBytes",
                        "FragmentedBytes",
                        "WorkingSetBytes",
                    )
                ),
                "Invalid memory observation",
            )
            gc_counts = record.get("GcCollections", [])
            require(
                len(gc_counts) == 3 and all(integer(value) for value in gc_counts),
                "Invalid GC collection observation",
            )
            require(
                integer(record.get("RetiredSampleCount")) and record["RetiredSampleCount"] <= 128,
                "Invalid retired sample count",
            )
            require(
                integer(record.get("RetiredTargetsAlive"))
                and record["RetiredTargetsAlive"] <= record["RetiredSampleCount"],
                "Invalid retired target observation",
            )
            if event == "workload-complete":
                complete = record
                require(
                    record["ElapsedSeconds"] >= seconds, "Workload ended before requested duration"
                )
            if event == "progress":
                progress_count += 1
        previous_elapsed, previous_batch = record["ElapsedSeconds"], record["batch"]
    require(progress_count > 0 and cycle > 0, "No sustained workload or cache recreation evidence")
    require(terminal["ElapsedSeconds"] >= seconds, "Terminal duration is too short")
    return {
        "path": path.name,
        "accepted": True,
        "statistics": start["statistics"],
        "runtime": start["Runtime"],
        "coreModule": start["CoreModule"],
        "testModule": start["TestModule"],
        "records": len(records),
        "progressRecords": progress_count,
        "batches": terminal["batch"],
        "cycles": cycle,
        "operations": complete["Operations"],
        "outcomes": complete["outcomes"],
        "elapsedSeconds": terminal["ElapsedSeconds"],
        "terminalEvent": "passed",
    }


def preserve_partial_jsonl(directory):
    evidence = []
    for path in sorted(directory.glob("*.jsonl")):
        records, error = read_records(path)
        progress = [
            record
            for record in records
            if record.get("Event") in ("progress", "recreated", "workload-complete")
        ]
        failures = [record for record in records if record.get("Event") == "failed"]
        evidence.append(
            {
                "path": path.name,
                "recordCount": len(records),
                "parseError": error,
                "terminalEvent": records[-1].get("Event") if records else None,
                "lastProgress": progress[-1] if progress else None,
                "failure": failures[-1].get("Error") if failures else None,
                "traceEvidence": "The original JSONL retains the fixture's final 128 operations per worker on failure.",
            }
        )
    return evidence


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=pathlib.Path, required=True)
    parser.add_argument("--seconds", type=int, default=1800)
    parser.add_argument("--runtime8", type=pathlib.Path, required=True)
    parser.add_argument("--runtime10", type=pathlib.Path, required=True)
    options = parser.parse_args()
    if not 1 <= options.seconds <= 86_400:
        parser.error("--seconds must be between 1 and 86400")
    runner = pathlib.Path(__file__).resolve()
    root = runner.parents[3]
    dependency = runner.with_name("repeat-correctness.py")
    dependency_bytes = dependency.read_bytes()
    require(
        hashlib.sha256(dependency_bytes).hexdigest() == DEPENDENCY_SHA256,
        "Repeat validator changed; review and repin its hash before running",
    )
    contract = types.ModuleType("frozen_repeat_contract")
    contract.__file__ = str(dependency)
    exec(compile(dependency_bytes, str(dependency), "exec"), contract.__dict__)
    output = options.output.resolve()
    if output.exists():
        parser.error("Use a fresh --output directory to preserve earlier evidence")
    hosts = {"net8.0": options.runtime8.resolve(), "net10.0": options.runtime10.resolve()}
    directories = {
        framework: root / "tests/LoadingCache.StressTests/bin/Release" / framework
        for framework in hosts
    }
    sdk = shutil.which("dotnet")
    if sdk is None:
        parser.error("The existing dotnet SDK host must be on PATH")
    sdk_host = pathlib.Path(sdk).resolve()
    for framework, host in hosts.items():
        require(
            host.is_file() and os.access(host, os.X_OK), f"Missing executable runtime host: {host}"
        )
        for filename in (
            "LoadingCache.StressTests.dll",
            "LoadingCache.dll",
            "LoadingCache.StressTests.runtimeconfig.json",
        ):
            require(
                (directories[framework] / filename).is_file(),
                f"Missing prebuilt {framework}/{filename}; build separately",
            )
        version = contract.EXPECTED_RUNTIME_VERSIONS[framework]
        require(
            (
                host.parent
                / "shared/Microsoft.NETCore.App"
                / version
                / "System.Private.CoreLib.dll"
            ).is_file(),
            f"Missing runtime {version}",
        )
        require(
            any((host.parent / "host/fxr" / version).glob("*hostfxr*")),
            f"Missing hostfxr {version}",
        )
    output.mkdir(parents=True)
    sources = source_manifest(contract, root, runner)
    binaries = contract.binary_manifest(directories, hosts, sdk_host)
    contract.write_json(output / "source-before.json", sources)
    contract.write_json(output / "binaries-before.json", binaries)
    state = {
        "schemaVersion": 1,
        "status": "running",
        "startedUtc": contract.utc_now(),
        "secondsPerCase": options.seconds,
        "expectedRuntimes": contract.EXPECTED_RUNTIME_VERSIONS,
        "expectedCasesPerRuntime": 2,
        "expectedTotalCases": 4,
        "testFilter": TEST_FILTER,
        "parallelismOverride": None,
        "runtimeProcessesParallel": True,
        "loadContext": "Intentional cross-runtime stability contention; a separate 20-run whole-core correctness suite may execute concurrently.",
        "measurementScope": "Duration, operation totals, GC and retained-memory observations only. No time/op, throughput, latency, or cross-process allocation comparison; retention samples are not a proof.",
        "invariantCoverage": "The frozen fixture calls AssertInvariants and checks actual dynamic maximum after each completed batch. JSONL independently checks recorded count/weight, generation, load-peak and quiescent backlog bounds; it does not contain the current dynamic maximum.",
        "runner": str(runner),
        "runnerSha256": contract.sha(runner),
        "dependency": str(dependency),
        "dependencySha256": DEPENDENCY_SHA256,
        "sourceManifestSha256": contract.sha(output / "source-before.json"),
        "binaryManifestSha256": contract.sha(output / "binaries-before.json"),
        "sourceUnchanged": None,
        "binariesUnchanged": None,
        "runtimeEnvironment": [],
        "runs": [],
    }
    processes, streams, starts = {}, {}, {}
    exit_code = 0

    def save():
        contract.write_json(output / "summary.json", state)

    save()
    try:
        for framework, host in hosts.items():
            log_path = output / f"runtime-{framework}.log"
            argv = [str(host), "--info"]
            code = contract.execute(argv, root, log_path, timeout=30)
            inspection = {
                "framework": framework,
                "argv": argv,
                "exitCode": code,
                "log": log_path.name,
                "logSha256": contract.sha(log_path),
            }
            state["runtimeEnvironment"].append(inspection)
            require(code == 0, f"Runtime inspection failed: {log_path}")
            inspection.update(contract.inspect_runtime_info(log_path, framework, host))
        require(
            source_manifest(contract, root, runner) == sources
            and contract.binary_manifest(directories, hosts, sdk_host) == binaries,
            "Inputs changed before launch",
        )
        for framework, host in hosts.items():
            run_directory = output / framework
            jsonl_directory = run_directory / "jsonl"
            jsonl_directory.mkdir(parents=True)
            argv = [
                str(sdk_host),
                "vstest",
                str(directories[framework] / "LoadingCache.StressTests.dll"),
                f"--TestCaseFilter:{TEST_FILTER}",
                "--Logger:trx;LogFileName=results.trx",
                f"--ResultsDirectory:{run_directory}",
                f"--Diag:{run_directory / 'vstest.log'}",
                "--",
                f"RunConfiguration.DotNetHostPath={host}",
            ]
            environment = os.environ.copy()
            overrides = {
                "LOADINGCACHE_SOAK_SECONDS": str(options.seconds),
                "LOADINGCACHE_SOAK_OUTPUT": str(jsonl_directory),
            }
            environment.update(overrides)
            recorded_environment = {
                key: value
                for key, value in environment.items()
                if key.startswith(
                    (
                        "DOTNET_",
                        "COMPlus_",
                        "CORECLR_",
                        "COR_",
                        "VSTEST_",
                        "NUNIT_",
                        "LOADINGCACHE_",
                    )
                )
            }
            entry = {
                "framework": framework,
                "status": "running",
                "argv": argv,
                "cwd": str(root),
                "environmentOverrides": overrides,
                "relevantInheritedEnvironment": recorded_environment,
                "startedUtc": contract.utc_now(),
                "watchdogSeconds": options.seconds + 180,
            }
            state["runs"].append(entry)
            save()
            streams[framework] = (run_directory / "test.log").open("w", encoding="utf-8")
            starts[framework] = time.monotonic()
            processes[framework] = subprocess.Popen(
                argv,
                cwd=root,
                env=environment,
                stdout=streams[framework],
                stderr=subprocess.STDOUT,
                start_new_session=os.name == "posix",
            )
            entry["runnerOwnedProcessId"] = processes[framework].pid
            save()
            print(
                f"Started {framework}: two parallel soak cases, {options.seconds}s each", flush=True
            )
        pending = set(processes)
        while pending:
            for framework in tuple(pending):
                entry = next(run for run in state["runs"] if run["framework"] == framework)
                code = processes[framework].poll()
                if code is None:
                    if time.monotonic() - starts[framework] > options.seconds + 180:
                        raise TimeoutError(
                            f"{framework} exceeded its {options.seconds + 180}s process watchdog"
                        )
                    continue
                pending.remove(framework)
                streams[framework].close()
                entry.update(
                    exitCode=code,
                    finishedUtc=contract.utc_now(),
                    elapsedSeconds=time.monotonic() - starts[framework],
                )
                run_directory = output / framework
                require(code == 0, f"{framework} test process failed: {code}")
                entry["trx"] = inspect_trx(run_directory / "results.trx")
                runtime_directory = (
                    hosts[framework].parent
                    / "shared/Microsoft.NETCore.App"
                    / contract.EXPECTED_RUNTIME_VERSIONS[framework]
                ).resolve()
                entry["testhost"] = contract.inspect_testhost(
                    run_directory / "vstest.log", hosts[framework], runtime_directory
                )
                jsonl_files = sorted((run_directory / "jsonl").glob("*.jsonl"))
                require(
                    len(jsonl_files) == 2,
                    f"Expected two JSONL files for {framework}, got {len(jsonl_files)}",
                )
                entry["cases"] = [
                    inspect_jsonl(path, framework, options.seconds, contract)
                    for path in jsonl_files
                ]
                require(
                    {case["statistics"] for case in entry["cases"]} == {False, True},
                    "Missing stats on/off soak evidence",
                )
                require(
                    len({(case["coreModule"], case["testModule"]) for case in entry["cases"]}) == 1,
                    "Cases loaded different module identities",
                )
                entry["status"] = "passed"
                save()
                print(f"{framework}: both soak cases validated", flush=True)
            if pending:
                time.sleep(0.25)
    except KeyboardInterrupt:
        exit_code = 130
        state["error"] = "Interrupted; partial evidence is not a passing soak"
    except Exception as error:
        exit_code = 1
        state["error"] = f"{type(error).__name__}: {error}"
    finally:
        for framework, process in processes.items():
            try:
                # Each Popen created its own session; descendants may outlive its launcher.
                contract.terminate_group(process)
            except Exception as error:
                state.setdefault("cleanupErrors", []).append(
                    f"{framework}: {type(error).__name__}: {error}"
                )
                exit_code = exit_code or 1
        for stream in streams.values():
            stream.close()
        for entry in state["runs"]:
            framework = entry["framework"]
            if entry["status"] != "passed":
                entry["status"] = "failed"
            if framework in processes:
                entry["exitCode"] = processes[framework].returncode
                entry.setdefault("finishedUtc", contract.utc_now())
                entry.setdefault("elapsedSeconds", time.monotonic() - starts[framework])
            run_directory = output / framework
            try:
                entry["partialJsonlEvidence"] = preserve_partial_jsonl(run_directory / "jsonl")
                entry["evidenceSha256"] = {
                    str(path.relative_to(run_directory)): contract.sha(path)
                    for path in sorted(run_directory.rglob("*"))
                    if path.is_file()
                }
            except Exception as error:
                entry["evidenceInspectionError"] = f"{type(error).__name__}: {error}"
                exit_code = exit_code or 1
        try:
            after_sources = source_manifest(contract, root, runner)
            after_binaries = contract.binary_manifest(directories, hosts, sdk_host)
            contract.write_json(output / "source-after.json", after_sources)
            contract.write_json(output / "binaries-after.json", after_binaries)
            state["sourceUnchanged"] = sources == after_sources
            state["binariesUnchanged"] = binaries == after_binaries
        except Exception as error:
            state["finalInputInspectionError"] = f"{type(error).__name__}: {error}"
        if not state["sourceUnchanged"] or not state["binariesUnchanged"]:
            exit_code = exit_code or 2
        if len(state["runs"]) != 2 or any(run["status"] != "passed" for run in state["runs"]):
            exit_code = exit_code or 1
        state["status"] = "passed" if exit_code == 0 else "failed"
        state["finishedUtc"] = contract.utc_now()
        save()
    print(f"{state['status']}: {output / 'summary.json'}", flush=True)
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
