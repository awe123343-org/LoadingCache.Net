"""Recheck the two historical write regressions with longer, matched ABBA samples."""

import argparse
import csv
import hashlib
import json
import math
import os
import pathlib
import statistics
import subprocess
import time


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().lower()


def main():
    if not __debug__:
        raise RuntimeError("Validation requires Python assertions to be enabled")
    parser = argparse.ArgumentParser()
    parser.add_argument("--before", type=pathlib.Path, required=True)
    parser.add_argument("--after", type=pathlib.Path, required=True)
    parser.add_argument("--runtime8", required=True)
    parser.add_argument("--runtime10", required=True)
    parser.add_argument("--output", type=pathlib.Path, required=True)
    args = parser.parse_args()
    environment = os.environ.copy()
    removed_environment = {
        key: environment.pop(key)
        for key in list(environment)
        if key.startswith(("DOTNET_", "COMPlus_", "CORECLR_", "COR_"))
    }
    frozen = {
        name: json.loads(path.read_text())
        for name, path in [("before", args.before), ("after", args.after)]
    }
    for snapshot in frozen.values():
        root = pathlib.Path(snapshot["root"])
        for name, expected in {
            **snapshot.get("sourceFiles", snapshot.get("files", {})),
            **snapshot["binaries"],
        }.items():
            assert sha(root / name) == expected.lower(), name
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    input_hashes = {
        str(path.resolve()): sha(path)
        for path in (
            args.before,
            args.after,
            pathlib.Path(args.runtime8),
            pathlib.Path(args.runtime10),
        )
    }
    manifest = {
        "status": "running",
        "inputs": {"before": str(args.before.resolve()), "after": str(args.after.resolve())},
        "inputHashes": input_hashes,
        "removedRuntimeEnvironment": removed_environment,
        "commands": [],
        "runnerSha256": sha(pathlib.Path(__file__)),
    }
    observed = {}

    def save():
        (output / "commands.json").write_text(json.dumps(manifest, indent=2) + "\n")

    save()
    for round_index, order in enumerate([["before", "after"], ["after", "before"]], start=1):
        for tfm, host in [("net8.0", args.runtime8), ("net10.0", args.runtime10)]:
            for workers, mode in [(1, "same"), (4, "changed")]:
                for label in order:
                    snapshot = frozen[label]
                    root = pathlib.Path(snapshot["root"])
                    base = f"tools/LoadingCache.WriteProbe/bin/Release/{tfm}"
                    path = output / f"round{round_index}-{tfm}-{workers}-{mode}-{label}.json"
                    argv = [
                        host,
                        str(root / base / "LoadingCache.WriteProbe.dll"),
                        "--suite",
                        "caffeine",
                        "--capacity",
                        "1024",
                        "--workers",
                        str(workers),
                        "--writes-per-worker",
                        "512",
                        "--statistics",
                        "off",
                        "--value-mode",
                        mode,
                        "--target-operations",
                        "1048576",
                        "--warmups",
                        "4",
                        "--runs",
                        "5",
                        "--label",
                        label,
                        "--no-progress",
                        "--output",
                        str(path),
                    ]
                    entry = {"argv": argv, "startedUnix": time.time(), "raw": path.name}
                    manifest["commands"].append(entry)
                    save()
                    print(path.stem, flush=True)
                    with path.with_suffix(".log").open("w") as stream:
                        result = subprocess.run(
                            argv,
                            env=environment,
                            stdout=stream,
                            stderr=subprocess.STDOUT,
                            timeout=180,
                        )
                    entry.update(exitCode=result.returncode, endedUnix=time.time())
                    save()
                    assert result.returncode == 0, path
                    report = json.loads(path.read_text())
                    assert report["schemaVersion"] == 5 and report["suite"] == "caffeine"
                    assert report["targetOperationsPerSample"] == 1048576 and report["seed"] == 419
                    assert all(value is None for value in report["runtimeEnvironment"].values())
                    assert report["runtime"] == (
                        ".NET 8.0.31" if tfm == "net8.0" else ".NET 10.0.12"
                    )
                    for field, binary in [
                        ("cacheAssemblySha256", "LoadingCache.dll"),
                        ("harnessAssemblySha256", "LoadingCache.WriteProbe.dll"),
                    ]:
                        assert (
                            report[field].lower()
                            == snapshot["binaries"][base + "/" + binary].lower()
                        )
                    assert (
                        report["runs"] == 5
                        and report["warmups"] == 4
                        and len(report["samples"]) == 9
                    )
                    for index, sample in enumerate(report["samples"]):
                        assert (
                            sample["capacity"],
                            sample["workers"],
                            sample["operationsPerWorker"],
                            sample["statistics"],
                            sample["valueMode"],
                        ) == (1024, workers, 512, False, mode)
                        assert sample["sampleIndex"] == index and sample["warmup"] == (index < 4)
                        assert sample["kind"] == "caffeine" and sample["keyMode"] == "caffeine"
                        assert (
                            sample["totalOperations"]
                            == sample["batches"] * workers * 512
                            == 1048576
                        )
                        assert (
                            sample["checksum"]
                            == 1048576 * ((4 if mode == "same" else 8) * workers * 512 - 1) // 2
                        )
                        assert sample["publicBoundsHold"] and sample["backlogAfterDrain"] == 0
                        assert (
                            0 <= sample["finalEstimatedCount"] <= 1024
                            and 0 <= sample["finalWeightedSize"] <= 1024
                        )
                        assert (
                            sample["timedSeconds"] > 0 and sample["wholeProcessAllocatedBytes"] >= 0
                        )
                        assert all(
                            math.isfinite(sample[field]) and sample[field] >= 0
                            for field in (
                                "timedSeconds",
                                "writeSeconds",
                                "workerWriteSeconds",
                                "drainSeconds",
                            )
                        )
                        assert math.isclose(
                            sample["timedSeconds"],
                            sample["writeSeconds"] + sample["drainSeconds"],
                            rel_tol=1e-10,
                            abs_tol=1e-9,
                        )
                        assert sample["workerWriteSeconds"] <= sample["writeSeconds"] + 1e-6
                    observed[round_index, tfm, workers, mode, label] = report["samples"][4:]
                    entry["validated"] = True
                    save()
    rows = []
    for tfm in ("net8.0", "net10.0"):
        for workers, mode in [(1, "same"), (4, "changed")]:
            row = {
                "tfm": tfm,
                "capacity": 1024,
                "workers": workers,
                "writes_per_worker": 512,
                "value_mode": mode,
                "statistics": False,
            }
            for label in ("before", "after"):
                samples = [s for r in (1, 2) for s in observed[r, tfm, workers, mode, label]]
                row[f"{label}_median_ns_per_write"] = statistics.median(
                    s["timedSeconds"] * 1e9 / s["totalOperations"] for s in samples
                )
                row[f"{label}_median_worker_ns_per_write"] = statistics.median(
                    s["workerWriteSeconds"] * 1e9 / s["totalOperations"] for s in samples
                )
                row[f"{label}_median_drain_ns_per_write"] = statistics.median(
                    s["drainSeconds"] * 1e9 / s["totalOperations"] for s in samples
                )
                row[f"{label}_median_bytes_per_write"] = statistics.median(
                    s["wholeProcessAllocatedBytes"] / s["totalOperations"] for s in samples
                )
            row["after_over_before"] = (
                row["after_median_ns_per_write"] / row["before_median_ns_per_write"]
            )
            for r in (1, 2):
                old = observed[r, tfm, workers, mode, "before"]
                new = observed[r, tfm, workers, mode, "after"]
                assert [s["checksum"] for s in old] == [s["checksum"] for s in new]
                row[f"round{r}_after_over_before"] = statistics.median(
                    s["timedSeconds"] for s in new
                ) / statistics.median(s["timedSeconds"] for s in old)
            rows.append(row)
    (output / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")
    with (output / "comparison.csv").open("w") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    for snapshot in frozen.values():
        root = pathlib.Path(snapshot["root"])
        for name, expected in {
            **snapshot.get("sourceFiles", snapshot.get("files", {})),
            **snapshot["binaries"],
        }.items():
            assert sha(root / name) == expected.lower(), name
    assert sha(pathlib.Path(__file__)) == manifest["runnerSha256"]
    assert all(sha(pathlib.Path(path)) == digest for path, digest in input_hashes.items())
    manifest["status"] = "passed"
    save()


if __name__ == "__main__":
    main()
