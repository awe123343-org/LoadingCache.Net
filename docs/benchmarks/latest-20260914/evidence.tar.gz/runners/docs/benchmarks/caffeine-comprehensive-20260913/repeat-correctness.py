"""Repeat the complete prebuilt core suite in fresh testhosts without changing test settings.

Each iteration executes all 515 tests on each specified runtime. No build, restore,
warmup, filtering, allocation-threshold changes, or parallelism overrides are used.
Run only after performance measurements have finished; this is correctness stress.
"""

from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import os
import pathlib
import platform
import re
import shutil
import signal
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

EXPECTED_TESTS = 515
REQUIRED_ALLOCATION_TESTS = (
    "WeakKeyObjectComparerDoesNotAllocateDuringRawLookupComparison",
    "WeakKeyResidentHitDoesNotAllocateLookupProbe",
)
EXPECTED_RUNTIME_VERSIONS = {"net8.0": "8.0.31", "net10.0": "10.0.12"}
WATCHDOG_SECONDS = 600


def utc_now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def source_manifest(root):
    names = (
        subprocess.check_output(
            ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"],
            cwd=root,
        )
        .decode()
        .split("\0")
    )
    build_inputs = {
        "global.json",
        "Directory.Build.props",
        "Directory.Build.targets",
        "Directory.Packages.props",
        "src/Package.props",
        ".editorconfig",
        "NuGet.Config",
        "nuget.config",
    }
    selected = {
        name
        for name in names
        if name
        and (root / name).is_file()
        and (
            name in build_inputs
            or name.startswith(("src/LoadingCache/", "tests/LoadingCache.Tests/"))
        )
    }
    selected.add(str(pathlib.Path(__file__).resolve().relative_to(root)))
    return {name: sha(root / name) for name in sorted(selected)}


def binary_manifest(directories, hosts, sdk_host):
    files = {
        f"{framework}/{path.relative_to(directory)}": sha(path)
        for framework, directory in directories.items()
        for path in sorted(directory.rglob("*"))
        if path.is_file()
    }
    files.update({f"runtime-host/{framework}": sha(host) for framework, host in hosts.items()})
    for framework, host in hosts.items():
        for relative in ("host/fxr", "shared/Microsoft.NETCore.App"):
            directory = host.parent / relative
            for path in sorted(directory.rglob("*")):
                if path.is_file():
                    files[f"runtime/{framework}/{path.relative_to(host.parent)}"] = sha(path)
    files["sdk-host/dotnet"] = sha(sdk_host)
    return files


def terminate_group(process):
    """Stop our start_new_session group, even when its launcher has already exited."""
    if os.name == "posix":
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    elif process.poll() is None:
        process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
    finally:
        if os.name == "posix":
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        process.wait(timeout=5)


def execute(argv, root, log_path, timeout):
    with log_path.open("w", encoding="utf-8") as log:
        process = subprocess.Popen(
            argv,
            cwd=root,
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=os.name == "posix",
        )
        exit_code = None
        try:
            try:
                exit_code = process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                exit_code = 124
                log.write("\nRunner watchdog expired; this run is not passing.\n")
                log.flush()
            return exit_code
        finally:
            try:
                # A reaped launcher does not prove that its testhost descendants exited.
                terminate_group(process)
            except Exception as error:
                log.write(f"\nProcess-group cleanup failed: {type(error).__name__}: {error}\n")
                log.flush()
                # Cleanup must not hide a timeout, nonzero exit, or active interruption.
                if exit_code == 0:
                    raise


def inspect_trx(path):
    report = ET.parse(path).getroot()
    counters = report.find(".//{*}ResultSummary/{*}Counters")
    if counters is None:
        raise ValueError("Missing TRX counters")
    counts = {
        name: int(counters.get(name, "0"))
        for name in ("total", "executed", "passed", "failed", "notExecuted")
    }
    results = report.findall(".//{*}Results/{*}UnitTestResult")
    test_ids = [result.get("testId", "") for result in results]
    names = sorted(result.get("testName", "") for result in results)
    failures = [
        {"name": result.get("testName"), "outcome": result.get("outcome")}
        for result in results
        if result.get("outcome") != "Passed"
    ]
    required_tests = {}
    for name in REQUIRED_ALLOCATION_TESTS:
        matches = [
            result for result in results if result.get("testName", "").rsplit(".", 1)[-1] == name
        ]
        required_tests[name] = {
            "count": len(matches),
            "outcomes": [result.get("outcome") for result in matches],
            "passed": len(matches) == 1 and matches[0].get("outcome") == "Passed",
        }
    accepted = (
        counts
        == {
            "total": EXPECTED_TESTS,
            "executed": EXPECTED_TESTS,
            "passed": EXPECTED_TESTS,
            "failed": 0,
            "notExecuted": 0,
        }
        and len(results) == EXPECTED_TESTS
        and all(test_ids)
        and len(set(test_ids)) == EXPECTED_TESTS
        and all(names)
        and not failures
        and all(result["passed"] for result in required_tests.values())
    )
    return {
        "counts": counts,
        "nonPassingTests": failures,
        "requiredAllocationTests": required_tests,
        "accepted": accepted,
    }, names


def inspect_runtime_info(path, framework, host):
    contents = path.read_text(encoding="utf-8")
    version = EXPECTED_RUNTIME_VERSIONS[framework]
    host_version = re.search(r"(?m)^Host:\s*\n[ \t]+Version:\s+(\S+)", contents)
    installed = re.findall(r"(?m)^\s*Microsoft\.NETCore\.App (\S+) \[([^\r\n]+)\]", contents)
    expected_parent = (host.parent / "shared/Microsoft.NETCore.App").resolve()
    if host_version is None or host_version.group(1) != version:
        raise ValueError(f"Expected host version {version}: {path}")
    if not any(
        actual == version and pathlib.Path(parent).resolve() == expected_parent
        for actual, parent in installed
    ):
        raise ValueError(f"Expected Microsoft.NETCore.App {version} at {expected_parent}")
    return {
        "hostVersion": version,
        "runtimeVersion": version,
        "runtimeDirectory": str(expected_parent / version),
    }


def inspect_testhost(diag_path, host, runtime_directory):
    console = diag_path.read_text(encoding="utf-8")
    executables = {
        str(pathlib.Path(value.strip()).resolve())
        for value in re.findall(r"(?m)Full path of host exe is ([^\r\n]+)$", console)
    }
    if executables != {str(host)}:
        raise ValueError(
            f"VSTest launched unexpected testhost executable(s): {sorted(executables)}"
        )
    host_logs = sorted(diag_path.parent.glob(f"{diag_path.stem}.host.*{diag_path.suffix}"))
    if len(host_logs) != 1:
        raise ValueError(f"Expected one fresh testhost diagnostic log, found {len(host_logs)}")
    locations = set()
    diagnostics = {diag_path.name: sha(diag_path)}
    for path in host_logs:
        contents = path.read_text(encoding="utf-8")
        locations.update(
            str(pathlib.Path(value.strip()).resolve())
            for value in re.findall(r"(?m)testhost\.dll, Runtime location: ([^\r\n]+)$", contents)
        )
        diagnostics[path.name] = sha(path)
    if locations != {str(runtime_directory)}:
        raise ValueError(f"Testhost loaded unexpected runtime location(s): {sorted(locations)}")
    return {
        "accepted": True,
        "executable": str(host),
        "runtimeDirectory": str(runtime_directory),
        "diagnosticSha256": diagnostics,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=pathlib.Path, required=True)
    parser.add_argument("--iterations", type=int, default=20)
    parser.add_argument("--runtime8", type=pathlib.Path, required=True)
    parser.add_argument("--runtime10", type=pathlib.Path, required=True)
    options = parser.parse_args()
    if options.iterations < 1:
        parser.error("--iterations must be positive")
    root = pathlib.Path(__file__).resolve().parents[3]
    output = options.output.resolve()
    if output.exists():
        parser.error("Use a fresh --output directory to preserve earlier evidence")
    hosts = {"net8.0": options.runtime8.resolve(), "net10.0": options.runtime10.resolve()}
    directories = {
        framework: root / "tests/LoadingCache.Tests/bin/Release" / framework for framework in hosts
    }
    sdk = shutil.which("dotnet")
    if sdk is None:
        parser.error("The existing dotnet SDK host must be available on PATH")
    sdk_host = pathlib.Path(sdk).resolve()
    for framework, host in hosts.items():
        if not host.is_file() or not os.access(host, os.X_OK):
            parser.error(f"Expected an existing executable runtime host: {host}")
        for filename in (
            "LoadingCache.Tests.dll",
            "LoadingCache.dll",
            "LoadingCache.Tests.runtimeconfig.json",
        ):
            if not (directories[framework] / filename).is_file():
                parser.error(
                    f"Missing prebuilt {framework} input: {filename}; build separately first"
                )
        version = EXPECTED_RUNTIME_VERSIONS[framework]
        runtime_directory = host.parent / "shared/Microsoft.NETCore.App" / version
        if not (runtime_directory / "System.Private.CoreLib.dll").is_file():
            parser.error(f"Missing expected runtime {version}: {runtime_directory}")
        if not any((host.parent / "host/fxr" / version).glob("*hostfxr*")):
            parser.error(f"Missing expected hostfxr {version} beside {host}")
    output.mkdir(parents=True)
    sources = source_manifest(root)
    binaries = binary_manifest(directories, hosts, sdk_host)
    write_json(output / "source-before.json", sources)
    write_json(output / "binaries-before.json", binaries)
    planned = [
        (iteration, framework)
        for iteration in range(1, options.iterations + 1)
        for framework in hosts
    ]
    summary = {
        "schemaVersion": 1,
        "status": "running",
        "startedUtc": utc_now(),
        "gitHead": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=root, text=True
        ).strip(),
        "platform": platform.platform(),
        "architecture": platform.machine(),
        "iterationsPerRuntime": options.iterations,
        "expectedTestsPerRun": EXPECTED_TESTS,
        "expectedTestExecutions": len(planned) * EXPECTED_TESTS,
        "warmupRuns": 0,
        "testFilter": None,
        "parallelismOverride": None,
        "settings": "Original test assembly settings and inherited process environment; no allocation threshold changes.",
        "runtimeHosts": {framework: str(host) for framework, host in hosts.items()},
        "expectedRuntimeVersions": EXPECTED_RUNTIME_VERSIONS,
        "requiredAllocationTests": REQUIRED_ALLOCATION_TESTS,
        "runtimeVerification": "VSTest host executable and testhost-reported runtime location from per-run diagnostics; runtime hostfxr and Microsoft.NETCore.App files hashed before and after.",
        "sourceManifestSha256": sha(output / "source-before.json"),
        "binaryManifestSha256": sha(output / "binaries-before.json"),
        "runtimeEnvironment": [],
        "runs": [],
        "sourceUnchanged": None,
        "binariesUnchanged": None,
    }
    baseline_names = {}
    exit_code = 0
    try:
        for framework, host in hosts.items():
            log_path = output / f"runtime-{framework}.log"
            argv = [str(host), "--info"]
            code = execute(argv, root, log_path, timeout=30)
            environment = {
                "framework": framework,
                "argv": argv,
                "exitCode": code,
                "log": log_path.name,
                "logSha256": sha(log_path),
            }
            summary["runtimeEnvironment"].append(environment)
            if code:
                raise RuntimeError(f"Runtime inspection failed: {log_path}")
            environment.update(inspect_runtime_info(log_path, framework, host))
        for iteration, framework in planned:
            if (
                source_manifest(root) != sources
                or binary_manifest(directories, hosts, sdk_host) != binaries
            ):
                raise RuntimeError(
                    "Source or binary input changed; stopping before the next testhost"
                )
            name = f"{framework}-run-{iteration:02d}"
            run_directory = output / name
            run_directory.mkdir()
            trx = run_directory / "results.trx"
            log_path = run_directory / "test.log"
            diag_path = run_directory / "vstest.log"
            argv = [
                str(sdk_host),
                "vstest",
                str(directories[framework] / "LoadingCache.Tests.dll"),
                "--Logger:trx;LogFileName=results.trx",
                f"--ResultsDirectory:{run_directory}",
                f"--Diag:{diag_path}",
                "--",
                f"RunConfiguration.DotNetHostPath={hosts[framework]}",
            ]
            entry = {
                "name": name,
                "iteration": iteration,
                "framework": framework,
                "status": "running",
                "argv": argv,
                "startedUtc": utc_now(),
                "log": str(log_path.relative_to(output)),
                "trx": str(trx.relative_to(output)),
                "diagnostic": str(diag_path.relative_to(output)),
            }
            summary["runs"].append(entry)
            write_json(output / "summary.json", summary)
            print(f"Running {name}: all {EXPECTED_TESTS} tests", flush=True)
            started = time.monotonic()
            entry["exitCode"] = execute(argv, root, log_path, WATCHDOG_SECONDS)
            entry["elapsedSeconds"] = time.monotonic() - started
            entry["finishedUtc"] = utc_now()
            entry["logSha256"] = sha(log_path)
            try:
                entry["results"], names = inspect_trx(trx)
                entry["trxSha256"] = sha(trx)
                if framework not in baseline_names and entry["results"]["accepted"]:
                    baseline_names[framework] = names
                    write_json(output / f"test-names-{framework}.json", names)
                entry["testNamesUnchanged"] = names == baseline_names.get(framework)
            except (OSError, ValueError, ET.ParseError) as error:
                entry["trxError"] = str(error)
                entry["testNamesUnchanged"] = False
            try:
                runtime_directory = (
                    hosts[framework].parent
                    / "shared/Microsoft.NETCore.App"
                    / EXPECTED_RUNTIME_VERSIONS[framework]
                ).resolve()
                entry["testhost"] = inspect_testhost(diag_path, hosts[framework], runtime_directory)
            except (OSError, ValueError) as error:
                entry["testhostError"] = str(error)
            if (
                entry["exitCode"]
                or not entry.get("results", {}).get("accepted")
                or not entry["testNamesUnchanged"]
                or not entry.get("testhost", {}).get("accepted")
            ):
                entry["status"] = "failed"
                raise RuntimeError(f"Test gate failed; inspect {run_directory}")
            entry["status"] = "passed"
            write_json(output / "summary.json", summary)
            print(f"{name}: {EXPECTED_TESTS} passed, 0 skipped", flush=True)
    except KeyboardInterrupt:
        exit_code = 130
        summary["error"] = "Interrupted; incomplete runs are not passing evidence"
        if summary["runs"] and summary["runs"][-1]["status"] == "running":
            summary["runs"][-1]["status"] = "interrupted"
    except Exception as error:
        exit_code = 1
        summary["error"] = f"{type(error).__name__}: {error}"
        if summary["runs"] and summary["runs"][-1]["status"] == "running":
            summary["runs"][-1]["status"] = "failed"
    finally:
        try:
            after_sources = source_manifest(root)
            after_binaries = binary_manifest(directories, hosts, sdk_host)
            write_json(output / "source-after.json", after_sources)
            write_json(output / "binaries-after.json", after_binaries)
            summary["sourceUnchanged"] = sources == after_sources
            summary["binariesUnchanged"] = binaries == after_binaries
        except Exception as error:
            summary["finalInputInspectionError"] = f"{type(error).__name__}: {error}"
            summary["sourceUnchanged"] = False
            summary["binariesUnchanged"] = False
        if not summary["sourceUnchanged"] or not summary["binariesUnchanged"]:
            exit_code = exit_code or 2
        summary["unrun"] = [
            {"iteration": iteration, "framework": framework}
            for iteration, framework in planned[len(summary["runs"]) :]
        ]
        summary["completedPassingRuns"] = sum(run["status"] == "passed" for run in summary["runs"])
        summary["actualPassingTestExecutions"] = sum(
            run.get("results", {}).get("counts", {}).get("passed", 0) for run in summary["runs"]
        )
        if summary["completedPassingRuns"] != len(planned):
            exit_code = exit_code or 1
        summary["status"] = "passed" if exit_code == 0 else "failed"
        summary["finishedUtc"] = utc_now()
        write_json(output / "summary.json", summary)
    print(f"{summary['status']}: {output / 'summary.json'}", flush=True)
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
