"""Run the frozen 26-case read matrix serially on three runtimes, in reverse rounds."""

import argparse
import csv
import datetime
import hashlib
import json
import math
import os
import pathlib
import statistics
import subprocess
import time
import types

DEPENDENCY_SHA256 = "4312dd7b65f345cd5c3fb85c56f7468116e6f2d9c1cbad6d2ce85d6e0569e35b"
RUNTIMES = ("net8", "net10", "caffeine")
EXPECTED_RUNTIMES = {"net8": ".NET 8.0.31", "net10": ".NET 10.0.12", "caffeine": "25.0.4"}
WARMUPS, RUNS, DURATION_MS, ROUNDS = 3, 5, 500, 2


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def validate_read_contract(contract, report, case, warmups, runs):
    """Keep the pinned v1 checks; explicitly validate the v2 backend extension."""
    common = report
    if report["schemaVersion"] == 2:
        assert report["backend"] == "loadingcache"
        assert report["keyMode"] == "native" and report["expiration"] == "none"
        assert report["backendAssemblySha256"].lower() == report["cacheAssemblySha256"].lower()
        # Only project the schema marker for the unchanged common-field validator.
        # The original report, timings, and archived JSON remain schema 2.
        common = dict(report, schemaVersion=1)
    contract.validate(common, case, warmups, runs)


def summarize(observed, cases, case_name):
    timing_rows, allocation_rows = [], []
    for case in cases:
        name = case_name(case)
        row = {"case": name, **case}
        for runtime in RUNTIMES:
            rounds = {
                index: observed[index, name, runtime]["samples"][WARMUPS:]
                for index in range(1, ROUNDS + 1)
            }
            pooled = [sample for samples in rounds.values() for sample in samples]
            for scope, samples in [
                ("pooled", pooled),
                *[(f"round{i}", s) for i, s in rounds.items()],
            ]:
                row[f"{runtime}_{scope}_median_ns_per_operation"] = statistics.median(
                    sample["wallSeconds"] * 1e9 / sample["operations"] for sample in samples
                )
            report = observed[1, name, runtime]
            field = "workerAllocatedBytes" if runtime == "caffeine" else "managedAllocatedBytes"
            scope_field = "allocationScope" if runtime == "caffeine" else "managedAllocationScope"
            assert all(
                observed[index, name, runtime][scope_field] == report[scope_field]
                for index in rounds
            )
            allocation = {
                "case": name,
                **case,
                "runtime": runtime,
                "scope": report[scope_field],
                "coverage": report.get("allocationCoverage", report[scope_field]),
                "sampleField": field,
            }
            for scope, samples in [
                ("pooled", pooled),
                *[(f"round{i}", s) for i, s in rounds.items()],
            ]:
                measured = all(sample[field] >= 0 for sample in samples)
                allocation[f"{scope}_median_bytes_per_operation"] = (
                    statistics.median(sample[field] / sample["operations"] for sample in samples)
                    if measured
                    else None
                )
            allocation_rows.append(allocation)
        for runtime in ("net8", "net10"):
            for scope in ("pooled", "round1", "round2"):
                row[f"{runtime}_over_caffeine_{scope}"] = (
                    row[f"{runtime}_{scope}_median_ns_per_operation"]
                    / row[f"caffeine_{scope}_median_ns_per_operation"]
                )
        timing_rows.append(row)
    return {
        "timingScope": "Elapsed read-only wall time / total operations; cleanup excluded. This is aggregate throughput cost, not request latency.",
        "aggregation": "Median of five measured samples per round; pooled median of all ten measured samples. Ratios divide matching medians; above one means .NET costs more than Caffeine.",
        "timing": timing_rows,
        "allocation": {
            "comparableAcrossRuntimes": False,
            "note": ".NET measures process managed allocations; Java measures live dedicated reader threads and excludes maintenance threads. Unsupported measurements remain null. No cross-runtime allocation ratios are reported.",
            "measurements": allocation_rows,
        },
    }


def main():
    if not __debug__:
        raise RuntimeError(
            "Run without Python optimization: the pinned sample validator uses assertions."
        )
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=pathlib.Path, required=True)
    parser.add_argument("--output", type=pathlib.Path, required=True)
    parser.add_argument("--runtime8", type=pathlib.Path, required=True)
    parser.add_argument("--runtime10", type=pathlib.Path, required=True)
    parser.add_argument("--java", type=pathlib.Path, required=True)
    options = parser.parse_args()
    runner = pathlib.Path(__file__).resolve()
    dependency = runner.parent.parent / "caffeine-read-20260913/run.py"
    dependency_bytes = dependency.read_bytes()
    assert hashlib.sha256(dependency_bytes).hexdigest() == DEPENDENCY_SHA256, (
        "Read validator changed"
    )
    contract = types.ModuleType("frozen_read_contract")
    exec(compile(dependency_bytes, str(dependency), "exec"), contract.__dict__)
    matrix = list(contract.cases())
    assert len(matrix) == 26 and len({contract.case_name(case) for case in matrix}) == 26
    source_manifest = options.manifest.resolve()
    manifest_bytes = source_manifest.read_bytes()
    frozen = json.loads(manifest_bytes)
    assert frozen["status"] == "built"
    root = pathlib.Path(frozen["root"]).resolve()
    executables = {
        "net8": options.runtime8.resolve(),
        "net10": options.runtime10.resolve(),
        "caffeine": options.java.resolve(),
    }
    tracked = {
        source_manifest: hashlib.sha256(manifest_bytes).hexdigest(),
        runner: sha(runner),
        dependency: DEPENDENCY_SHA256,
    }
    tracked[source_manifest.parent / "source.tar.gz"] = frozen["sourceArchiveSha256"].lower()
    for group in ("sourceFiles", "binaries"):
        assert frozen[group], f"Empty frozen {group}"
        for name, expected in frozen[group].items():
            path = (root / name).resolve()
            assert path.is_relative_to(root), f"Frozen path escapes root: {name}"
            if path in tracked:
                assert tracked[path] == expected.lower(), f"Conflicting frozen hashes: {name}"
            tracked[path] = expected.lower()
    for executable in executables.values():
        tracked[executable] = sha(executable)
    binaries = frozen["binaries"]
    bases, expected_artifacts = {}, {}
    for runtime, tfm in (("net8", "net8.0"), ("net10", "net10.0")):
        base = f"tools/LoadingCache.HitProbe/bin/Release/{tfm}"
        harness = base + "/LoadingCache.HitProbe.dll"
        bases[runtime] = [str(executables[runtime]), str(root / harness)]
        expected_artifacts[runtime] = {
            "cacheAssemblySha256": binaries[base + "/LoadingCache.dll"].lower(),
            "harnessAssemblySha256": binaries[harness].lower(),
        }
    jar = "caffeine-3.2.4.jar"
    java_classes = {
        name: digest.lower()
        for name, digest in binaries.items()
        if name.startswith("java-classes/baseline/CaffeineHitProbe") and name.endswith(".class")
    }
    assert "java-classes/baseline/CaffeineHitProbe.class" in java_classes
    bases["caffeine"] = [
        str(executables["caffeine"]),
        "-cp",
        str(root / "java-classes") + os.pathsep + str(root / jar),
        "baseline.CaffeineHitProbe",
    ]
    expected_artifacts["caffeine"] = {"caffeineJarSha256": binaries[jar].lower()}
    # Explicit hosts need no inherited runtime overrides. Preserve their removal as evidence.
    environment = os.environ.copy()
    removed_environment = {
        key: environment.pop(key)
        for key in list(environment)
        if key.startswith(("DOTNET_", "COMPlus_", "CORECLR_", "COR_"))
        or key in ("JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "_JAVA_OPTIONS")
    }
    output = options.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    state = {
        "schemaVersion": 1,
        "status": "running",
        "startedUtc": now(),
        "sourceManifest": str(source_manifest),
        "sourceManifestSha256": tracked[source_manifest],
        "runner": str(runner),
        "runnerSha256": tracked[runner],
        "dependency": str(dependency),
        "dependencySha256": DEPENDENCY_SHA256,
        "frozenRoot": str(root),
        "expectedRuntimeVersions": EXPECTED_RUNTIMES,
        "executables": {
            label: {"path": str(path), "sha256": tracked[path]}
            for label, path in executables.items()
        },
        "expectedArtifactHashes": expected_artifacts,
        "javaClassHashes": java_classes,
        "runtimeEnvironment": {},
        "removedRuntimeEnvironment": removed_environment,
        "warmups": WARMUPS,
        "runs": RUNS,
        "durationMilliseconds": DURATION_MS,
        "rounds": ROUNDS,
        "cases": matrix,
        "expectedProcessCount": len(matrix) * len(RUNTIMES) * ROUNDS,
        "commands": [],
        "inputVerification": {},
    }

    def save():
        (output / "commands.json").write_text(json.dumps(state, indent=2, allow_nan=False) + "\n")

    def verify_inputs(phase):
        mismatches = [
            str(path)
            for path, expected in tracked.items()
            if not path.is_file() or sha(path) != expected
        ]
        state["inputVerification"][phase] = {
            "checkedUtc": now(),
            "fileCount": len(tracked),
            "mismatches": mismatches,
        }
        assert not mismatches, f"Inputs changed: {mismatches}"

    observed, actual_runtimes = {}, {}
    save()
    try:
        verify_inputs("start")
        (output / "frozen-manifest.json").write_text(json.dumps(frozen, indent=2) + "\n")
        for round_index in range(1, ROUNDS + 1):
            order = RUNTIMES if round_index == 1 else tuple(reversed(RUNTIMES))
            case_order = matrix if round_index == 1 else list(reversed(matrix))
            for case in case_order:
                for runtime in order:
                    name = contract.case_name(case)
                    stem = f"round{round_index}-{name}-{runtime}"
                    raw_path, log_path = output / f"{stem}.json", output / f"{stem}.log"
                    argv = list(bases[runtime])
                    for key, value in case.items():
                        argv.extend(["--" + key, str(value)])
                    argv.extend(
                        [
                            "--warmups",
                            str(WARMUPS),
                            "--runs",
                            str(RUNS),
                            "--duration-ms",
                            str(DURATION_MS),
                            "--output",
                            str(raw_path),
                        ]
                    )
                    entry = {
                        "name": stem,
                        "case": case,
                        "runtime": runtime,
                        "round": round_index,
                        "argv": argv,
                        "cwd": str(root),
                        "raw": raw_path.name,
                        "log": log_path.name,
                        "startedUtc": now(),
                    }
                    state["commands"].append(entry)
                    save()
                    print(
                        f"[{len(state['commands'])}/{state['expectedProcessCount']}] {stem}",
                        flush=True,
                    )
                    started = time.monotonic()
                    try:
                        with log_path.open("w") as log:
                            result = subprocess.run(
                                argv,
                                cwd=root,
                                env=environment,
                                stdout=log,
                                stderr=subprocess.STDOUT,
                                timeout=120,
                                check=False,
                            )
                        entry["exitCode"] = result.returncode
                        assert result.returncode == 0, f"Probe failed: {log_path}"
                        report = json.loads(raw_path.read_text())
                        entry["actualRuntime"] = report["runtime"]
                        if runtime == "caffeine":
                            assert report["runtime"].startswith(EXPECTED_RUNTIMES[runtime]), report[
                                "runtime"
                            ]
                            assert (
                                report["caffeineVersion"] == "3.2.4" and report["failure"] is None
                            )
                            assert pathlib.Path(report["caffeineJarPath"]).resolve() == root / jar
                        else:
                            assert report["runtime"] == EXPECTED_RUNTIMES[runtime], report[
                                "runtime"
                            ]
                            assert all(
                                value is None for value in report["runtimeEnvironment"].values()
                            )
                        assert report["runtime"] == actual_runtimes.setdefault(
                            runtime, report["runtime"]
                        )
                        entry["artifactHashes"] = {
                            field: report[field].lower() for field in expected_artifacts[runtime]
                        }
                        assert entry["artifactHashes"] == expected_artifacts[runtime]
                        assert report["warmups"] == WARMUPS and report["runs"] == RUNS
                        assert (
                            report.get("durationMilliseconds", report.get("durationMillis"))
                            == DURATION_MS
                        )
                        validate_read_contract(contract, report, case, WARMUPS, RUNS)
                        allocation_field = (
                            "workerAllocatedBytes"
                            if runtime == "caffeine"
                            else "managedAllocatedBytes"
                        )
                        for sample in report["samples"]:
                            assert math.isfinite(sample["wallSeconds"]) and math.isfinite(
                                sample["cleanupSeconds"]
                            )
                            assert sample[allocation_field] >= (-1 if runtime == "caffeine" else 0)
                        observed[round_index, name, runtime] = report
                        entry["validated"] = True
                    except BaseException as error:
                        entry["error"] = repr(error)
                        raise
                    finally:
                        entry["finishedUtc"] = now()
                        entry["elapsedSeconds"] = time.monotonic() - started
                        for kind, path in (("raw", raw_path), ("log", log_path)):
                            if path.is_file():
                                entry[kind + "Sha256"] = sha(path)
                        save()
        assert len(observed) == state["expectedProcessCount"]
        verify_inputs("end")
        summary = summarize(observed, matrix, contract.case_name)
        summary.update(
            actualRuntimes=actual_runtimes,
            validatedProcesses=len(observed),
            validatedSamples=len(observed) * (WARMUPS + RUNS),
            measuredSamples=len(observed) * RUNS,
            sourceManifestSha256=tracked[source_manifest],
            runnerSha256=tracked[runner],
            dependencySha256=DEPENDENCY_SHA256,
        )
        (output / "summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
        with (output / "comparison.csv").open("w", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(summary["timing"][0]))
            writer.writeheader()
            writer.writerows(summary["timing"])
        state["actualRuntimes"] = actual_runtimes
        state["status"] = "passed"
    except BaseException as error:
        state["status"] = "failed"
        state["error"] = repr(error)
        try:
            verify_inputs("end")
        except BaseException as verification_error:
            state["endVerificationError"] = repr(verification_error)
        raise
    finally:
        state["finishedUtc"] = now()
        save()
    print(f"All {len(observed)} probes validated: {output / 'summary.json'}", flush=True)


if __name__ == "__main__":
    main()
