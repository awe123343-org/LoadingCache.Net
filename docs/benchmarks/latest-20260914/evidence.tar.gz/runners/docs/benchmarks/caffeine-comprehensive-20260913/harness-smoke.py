#!/usr/bin/env python3
"""Bounded harness validation, not a performance runner."""
import hashlib
import json
import pathlib
import subprocess
import time

ROOT = pathlib.Path(__file__).resolve().parents[3]
OUT = ROOT / 'docs/benchmarks/caffeine-comprehensive-20260913/harness-smoke'
BUILD = pathlib.Path('/private/tmp/loadingcache-scenario-final-build')
JAVA = pathlib.Path('/Library/Java/JavaVirtualMachines/zulu-25.jdk/Contents/Home/bin')
JAR = pathlib.Path('/private/tmp/loadingcache-caffeine-read-20260913-ymvnln0g/caffeine-3.2.4.jar')
CLASSES = pathlib.Path('/private/tmp/loadingcache-scenario-final-java')
OWNED = [ROOT / 'tools/LoadingCache.ScenarioProbe/Program.cs', ROOT / 'tools/LoadingCache.ScenarioProbe/LoadingCache.ScenarioProbe.csproj', ROOT / 'tools/LoadingCache.ScenarioProbe.Java/ScenarioProbe.java']

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    before = {str(path.relative_to(ROOT)): sha(path) for path in OWNED}
    commands = []
    def run(name, argv, expected=0):
        start = time.time()
        result = subprocess.run([str(arg) for arg in argv], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180)
        (OUT / (name + '.log')).write_bytes(result.stdout)
        entry = {'name': name, 'argv': [str(arg) for arg in argv], 'startedUnix': start, 'endedUnix': time.time(), 'exitCode': result.returncode, 'expectedExitCode': expected}
        commands.append(entry)
        (OUT / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        if expected == 0 and result.returncode != 0 or expected != 0 and result.returncode == 0:
            raise RuntimeError(f'{name}: unexpected exit {result.returncode}; inspect log')
    for tfm in ['net8.0', 'net10.0']:
        run('build-' + tfm, ['dotnet', 'build', 'tools/LoadingCache.ScenarioProbe/LoadingCache.ScenarioProbe.csproj', '-c', 'Release', '-f', tfm, '--artifacts-path', BUILD, '-m:1'])
    run('javac', [JAVA / 'javac', '--release', '25', '-Xlint:all', '-Werror', '-cp', JAR, '-d', CLASSES, 'tools/LoadingCache.ScenarioProbe.Java/ScenarioProbe.java'])
    engines = {
        'net8': [ROOT / 'artifacts/runtime8/dotnet', BUILD / 'bin/LoadingCache.ScenarioProbe/release_net8.0/LoadingCache.ScenarioProbe.dll'],
        'net10': [ROOT / 'artifacts/runtime10/dotnet', BUILD / 'bin/LoadingCache.ScenarioProbe/release_net10.0/LoadingCache.ScenarioProbe.dll'],
        'java': [JAVA / 'java', '-cp', str(CLASSES) + ':' + str(JAR), 'ScenarioProbe'],
    }
    reports = {}
    for engine, command in engines.items():
        for stats in ['on', 'off']:
            name = engine + '-' + stats
            output = OUT / (name + '.json')
            run(name, command + ['--scenario', 'all', '--cycles', '256', '--capacity', '64', '--fan-in', '16', '--warmups', '0', '--runs', '1', '--statistics', stats, '--output', output])
            reports[name] = json.loads(output.read_text())
    scenarios = [sample['name'] for sample in reports['net8-on']['samples']]
    assert len(scenarios) == 41 and len(set(scenarios)) == 41, scenarios
    nonmatching = {'size-churn', 'weight-churn', 'eviction-listener', 'runtime-maximum'}
    for name, report in reports.items():
        assert [sample['name'] for sample in report['samples']] == scenarios, name
        for sample, baseline in zip(report['samples'], reports['net8-on']['samples']):
            assert sample['validated'] and sample['seconds'] > 0
            assert sample['finalWeight'] <= sample['maximum']
            assert sample['operations'] == baseline['operations']
            assert sample['backendCalls'] == baseline['backendCalls']
            assert sample['bulkCalls'] == baseline['bulkCalls']
            if sample['name'] not in nonmatching:
                assert sample['checksum'] == baseline['checksum'], (name, sample['name'])
    trace = [index % 16 for index in range(256)] + [index + 16 for index in range(256)]
    fixture = OUT / 'trace.json'
    fixture.write_text(json.dumps(trace) + '\n')
    for engine, command in engines.items():
        name = engine + '-trace'
        output = OUT / (name + '.json')
        run(name, command + ['--scenario', 'trace-policy', '--trace-file', fixture, '--cycles', str(len(trace)), '--capacity', '64', '--warmups', '0', '--runs', '1', '--statistics', 'on', '--output', output])
        report = json.loads(output.read_text())
        assert report['traceSha256'] == sha(fixture)
        sample = report['samples'][0]
        assert sample['validated'] and sample['hits'] + sample['misses'] == len(trace)
        assert sample['hits'] == 240 and sample['misses'] == 272
        run(engine + '-reject-trace-length', command + ['--scenario', 'trace-policy', '--trace-file', fixture, '--cycles', '513', '--warmups', '0', '--runs', '1'], expected=1)
    after = {str(path.relative_to(ROOT)): sha(path) for path in OWNED}
    assert before == after, 'harness changed during smoke'
    summary = {'status': 'passed', 'purpose': 'bounded correctness smoke; timings not benchmark evidence', 'scenarioCount': 41, 'scenarioSamples': 246, 'policySamples': 3, 'expectedRejections': 3, 'commands': len(commands), 'sourceUnchanged': before == after, 'sourceHashes': after, 'jarSha256': sha(JAR)}
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary))

if __name__ == '__main__':
    main()
