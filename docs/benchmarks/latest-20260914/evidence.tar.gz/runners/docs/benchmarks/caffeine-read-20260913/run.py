"""Run equivalent hit probes sequentially and preserve every command and sample."""

import argparse
import datetime
import json
import os
import pathlib
import subprocess
import time


def cases():
    for residents, pattern in ((1, "hot"), (1024, "hot"), (1024, "cycle")):
        for workers in (1, 4, 10, 20):
            for statistics in ("off", "on"):
                yield dict(
                    capacity=1024,
                    residents=residents,
                    pattern=pattern,
                    workers=workers,
                    statistics=statistics,
                )
    for workers in (1, 10):
        yield dict(
            capacity=16384, residents=16384, pattern="cycle", workers=workers, statistics="off"
        )


def case_name(case):
    return "-".join(
        str(case[key]) for key in ("capacity", "residents", "pattern", "workers", "statistics")
    )


def validate(report, case, warmups, runs):
    assert report["schemaVersion"] == 1
    for key in ("capacity", "residents", "pattern", "workers"):
        assert report[key] == case[key]
    recorded_statistics = report["statistics"]
    assert recorded_statistics == case["statistics"] or recorded_statistics is (
        case["statistics"] == "on"
    )
    samples = report["samples"]
    assert len(samples) == warmups + runs
    assert sum(not sample["warmup"] for sample in samples) == runs
    for index, sample in enumerate(samples):
        assert sample["sampleIndex"] == index
        assert sample["warmup"] == (index < warmups)
        assert sample["boundsPassed"] and sample["misses"] == 0
        assert sample["residentCount"] == case["residents"]
        assert sample["weightedSize"] == case["residents"]
        assert sample["operations"] > 0 and sample["wallSeconds"] > 0
        duration_ms = report.get("durationMilliseconds", report.get("durationMillis"))
        assert sample["wallSeconds"] >= duration_ms / 1000 - 0.00001
        assert sample["cleanupSeconds"] >= 0
        assert len(sample["workersOperations"]) == case["workers"]
        assert all(value > 0 for value in sample["workersOperations"])
        assert sum(sample["workersOperations"]) == sample["operations"]
        expected_checksum = 0
        for worker, operations in enumerate(sample["workersOperations"]):
            assert operations % 1024 == 0
            if case["pattern"] == "hot":
                expected_checksum += operations
            else:
                residents = case["residents"]
                cycles, remainder = divmod(operations, residents)
                expected_checksum += cycles * residents * (residents + 1) // 2
                expected_checksum += sum(
                    ((worker * 17 + index) & (residents - 1)) + 1 for index in range(remainder)
                )
        assert sample["checksum"] == expected_checksum
        assert sample["missesDelta"] == 0
        expected_hits = sample["operations"] if case["statistics"] == "on" else 0
        assert sample["hitsDelta"] == expected_hits


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dotnet-host", required=True)
    parser.add_argument("--dotnet-dll", required=True)
    parser.add_argument("--java", required=True)
    parser.add_argument("--java-classes", required=True)
    parser.add_argument("--java-jar", required=True)
    parser.add_argument("--java-main", default="baseline.CaffeineHitProbe")
    parser.add_argument("--output-directory", required=True)
    parser.add_argument("--rounds", type=int, default=2)
    parser.add_argument("--warmups", type=int, default=3)
    parser.add_argument("--runs", type=int, default=5)
    parser.add_argument("--duration-ms", type=int, default=500)
    options = parser.parse_args()
    if min(options.rounds, options.runs, options.duration_ms) <= 0 or options.warmups < 0:
        parser.error("rounds, runs and duration must be positive; warmups must be nonnegative")
    output = pathlib.Path(options.output_directory).resolve()
    output.mkdir(parents=True, exist_ok=False)
    commands = []
    report = {
        "startedUtc": datetime.datetime.now(datetime.UTC).isoformat(),
        "options": vars(options),
        "commands": commands,
        "runtimeEnvironment": {
            key: value
            for key, value in os.environ.items()
            if key.startswith(("DOTNET_", "COMPlus_"))
            or key in ("JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "_JAVA_OPTIONS")
        },
        "status": "running",
    }
    manifest = output / "commands.json"

    def save():
        manifest.write_text(json.dumps(report, indent=2) + "\n")

    save()
    matrix = list(cases())
    for round_index in range(options.rounds):
        runtime_order = ("dotnet", "java") if round_index % 2 == 0 else ("java", "dotnet")
        case_order = matrix if round_index % 2 == 0 else list(reversed(matrix))
        for case in case_order:
            for runtime in runtime_order:
                name = f"round{round_index + 1}-{case_name(case)}-{runtime}"
                raw_path = output / f"{name}.json"
                log_path = output / f"{name}.log"
                argv = (
                    [options.dotnet_host, options.dotnet_dll]
                    if runtime == "dotnet"
                    else [
                        options.java,
                        "-cp",
                        options.java_classes + os.pathsep + options.java_jar,
                        options.java_main,
                    ]
                )
                for key, value in case.items():
                    argv.extend(["--" + key, str(value)])
                argv.extend(
                    [
                        "--warmups",
                        str(options.warmups),
                        "--runs",
                        str(options.runs),
                        "--duration-ms",
                        str(options.duration_ms),
                        "--output",
                        str(raw_path),
                    ]
                )
                entry = {
                    "name": name,
                    "case": case,
                    "runtime": runtime,
                    "round": round_index + 1,
                    "argv": argv,
                    "cwd": os.getcwd(),
                    "log": str(log_path),
                    "raw": str(raw_path),
                    "startedUtc": datetime.datetime.now(datetime.UTC).isoformat(),
                }
                commands.append(entry)
                save()
                print(f"[{len(commands)}/{len(matrix) * options.rounds * 2}] {name}", flush=True)
                started = time.monotonic()
                try:
                    with log_path.open("w") as log:
                        result = subprocess.run(
                            argv, stdout=log, stderr=subprocess.STDOUT, timeout=120, check=False
                        )
                    entry["exitCode"] = result.returncode
                    entry["elapsedSeconds"] = time.monotonic() - started
                    assert result.returncode == 0, f"Failed probe: {log_path}"
                    validate(json.loads(raw_path.read_text()), case, options.warmups, options.runs)
                    entry["validated"] = True
                except BaseException as error:
                    entry["error"] = repr(error)
                    report["status"] = "failed"
                    save()
                    raise
                save()
    report["status"] = "passed"
    report["finishedUtc"] = datetime.datetime.now(datetime.UTC).isoformat()
    save()
    print(f"All {len(commands)} probes passed: {manifest}", flush=True)


if __name__ == "__main__":
    main()
