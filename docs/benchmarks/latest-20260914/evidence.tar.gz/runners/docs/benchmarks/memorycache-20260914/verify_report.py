"""Check report transcription and HTML data against a portable-archive recomputation."""

import argparse
import hashlib
import json
from html.parser import HTMLParser
from pathlib import Path


class ReportParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = []
        self.links = []
        self.script_id = None
        self.data = ""

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if "id" in attrs:
            self.ids.append(attrs["id"])
        if tag == "a":
            self.links.append(attrs["href"])
        if tag == "script":
            self.script_id = attrs.get("id")

    def handle_endtag(self, tag):
        if tag == "script":
            self.script_id = None

    def handle_data(self, data):
        if self.script_id == "data":
            self.data += data


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", type=Path)
    parser.add_argument("--recomputed", type=Path, required=True)
    args = parser.parse_args()
    root = args.directory.resolve()
    names = (
        "comparison.json",
        "samples.json",
        "verified-summary.json",
        "read.csv",
        "replacement.csv",
        "trace.csv",
        "fanin.csv",
    )
    hashes = {}
    for name in names:
        assert sha(root / name) == sha(args.recomputed / name), name
        hashes[name] = sha(root / name)
    rows = json.loads((root / "comparison.json").read_text())
    html = (root / "index.html").read_text()
    parsed = ReportParser()
    parsed.feed(html)
    assert json.loads(parsed.data) == rows
    assert len(parsed.ids) == len(set(parsed.ids))
    assert {"data", "rows", "caption", "runtime", "kind", "statistics", "native"} <= set(parsed.ids)
    assert "__COMMIT__" not in html and "__LOADINGCACHE_" not in html
    assert all((root / link).is_file() for link in parsed.links)
    text = (root / "README.md").read_text()
    examples = [line.split("|")[1:-1] for line in text.splitlines() if line.startswith("| ")]
    checked = 0
    for cells in examples:
        if len(cells) != 5 or not cells[1].strip().isdigit():
            continue
        title, workers, local, memory, ratio = (value.strip() for value in cells)
        if not (
            title.startswith("Hot hit")
            or title.startswith("Cycle hit")
            or title.startswith("Replace")
        ):
            continue
        candidates = [
            r
            for r in rows
            if r["runtime"] == "10" and r["workers"] == int(workers) and r["statistics"] == "off"
        ]
        if title.startswith("Replace"):
            mode = "same" if "同 reference" in title else "changed"
            candidates = [
                r for r in candidates if r["kind"] == "replacement" and r["value_mode"] == mode
            ]
        else:
            expiry = (
                "both"
                if "TTL＋TTI" in title
                else "write"
                if "TTL" in title
                else "access"
                if "TTI" in title
                else "none"
            )
            pattern = "hot" if title.startswith("Hot") else "cycle"
            candidates = [
                r
                for r in candidates
                if r["kind"] == "read"
                and r["key_mode"] == "preboxed"
                and r["capacity"] == r["residents"] == 1024
                and r["pattern"] == pattern
                and r["expiration"] == expiry
            ]
        assert len(candidates) == 1, title
        row = candidates[0]
        for given, actual in (
            (local, row["loadingcache"]["median"]),
            (memory, row["memorycache"]["median"]),
            (ratio, row["costRatio"]),
        ):
            assert abs(float(given.replace(",", "")) - actual) <= 0.000501, (title, given, actual)
        checked += 1
    assert checked == 14
    hashes.update(
        {name: sha(root / name) for name in ("index.html", "README.md", "verify_report.py")}
    )
    result = {
        "portableRecomputedFiles": len(names),
        "recomputedFilesExactlyMatch": True,
        "htmlEmbeddedRows": len(rows),
        "htmlDataMatches": True,
        "htmlLinksExist": True,
        "readmeNumericRowsVerified": checked,
        "visualInspection": "Not run: browser security policy blocks the local file URL; no workaround used",
        "hashes": hashes,
    }
    (root / "report-validation.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
