"""Independently verify sealed probe results and calculate paired comparisons."""

import argparse
import csv
import hashlib
import json
import statistics
from pathlib import Path


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def distribution(values):
    return {"median": statistics.median(values), "min": min(values), "max": max(values)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root, output = args.input.resolve(), args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    completed = read(root / "completed.json")
    assert completed == dict(completed, allValidated=True, frozenInputsUnchanged=True)
    cases = {case["id"]: case for case in read(root / "cases.json")}
    results, schedule = read(root / "results.json"), read(root / "schedule.json")
    assert len(results) == len(schedule) == completed["processes"] == 584
    source_manifest = read(root / "source-manifest.json")
    binary_manifest = read(root / "binary-manifest.json")
    runtime_manifest = read(root / "runtime-manifest.json")
    for path, expected in source_manifest.items():
        assert digest(root / "executed-source" / path) == expected, path
    for path, expected in binary_manifest.items():
        if (root / path).exists():
            assert digest(root / path) == expected, path
    groups, all_samples = {}, []
    for record, scheduled in zip(results, schedule, strict=True):
        assert record["exitCode"] == 0 and record["validated"]
        assert all(record[key] == scheduled[key] for key in ("case", "round", "runtime", "backend"))
        raw_path = root / record["id"] / "raw.json"
        assert digest(raw_path) == record["rawSha256"]
        raw = read(raw_path)
        case, version, backend = cases[record["case"]], record["runtime"], record["backend"]
        config, kind = case["config"], case["kind"]
        expected_runtime = ".NET " + {"8": "8.0.31", "10": "10.0.12"}[version]
        probe = "HitProbe" if kind == "read" else "MemoryCacheProbe"
        frozen = root / f"frozen/net{version}/{probe}"
        if kind == "read":
            assert raw["runtime"] == expected_runtime and raw["architecture"] == "Arm64"
            assert raw["backend"] == backend
            assert (
                raw["cacheAssemblySha256"].lower()
                == binary_manifest[str((frozen / "LoadingCache.dll").relative_to(root))]
            )
            assert (
                raw["harnessAssemblySha256"].lower()
                == binary_manifest[str((frozen / "LoadingCache.HitProbe.dll").relative_to(root))]
            )
            assert (
                raw["memoryCacheInformationalVersion"]
                == "10.0.12+95017c711e6afc1085133d440e42b4bd78155701"
            )
            assert not any(raw["runtimeEnvironment"].values()) and not raw["serverGc"]
        else:
            metadata = raw["metadata"]
            assert metadata["runtime"] == expected_runtime and metadata["architecture"] == "Arm64"
            assert raw["options"]["backend"] == backend and not metadata["serverGc"]
            for assembly in metadata["assemblies"]:
                filename = Path(assembly["path"]).name
                local = binary_manifest.get(f"frozen/net{version}/{probe}/{filename}")
                if local is None:
                    matches = [
                        value
                        for path, value in runtime_manifest.items()
                        if path.startswith(f"artifacts/runtime{version}/")
                        and Path(path).name == filename
                    ]
                    assert len(matches) == 1
                    local = matches[0]
                assert local == assembly["sha256"]
            for source in metadata["sourceManifest"]:
                assert source_manifest[source["path"]] == source["sha256"]
        measured = [sample for sample in raw["samples"] if not sample["warmup"]]
        assert len(measured) == 5 and sum(sample["warmup"] for sample in raw["samples"]) >= 3
        entries = []
        for sample in raw["samples"]:
            if kind == "read":
                operations, seconds = sample["operations"], sample["wallSeconds"]
                assert operations == sum(sample["workersOperations"]) > 0
                assert sample["misses"] == sample["missesDelta"] == 0
                assert sample["residentCount"] == config["residents"] and sample["boundsPassed"]
                assert sample["hitsDelta"] == (operations if config["statistics"] == "on" else 0)
                n = config["residents"]
                expected = 0
                for worker, count in enumerate(sample["workersOperations"]):
                    if config["pattern"] == "hot":
                        expected += count
                    else:
                        cycles, tail = divmod(count, n)
                        expected += cycles * n * (n + 1) // 2
                        expected += sum((worker * 17 + offset) % n + 1 for offset in range(tail))
                assert sample["checksum"] == expected
                allocated = sample["managedAllocatedBytes"]
                cleanup_seconds = sample["cleanupSeconds"]
            else:
                value = sample["result"]
                assert value["validated"]
                seconds = value["seconds"]
                allocated = value["deltas"]["processAllocatedBytes"]
                cleanup_seconds = value.get("loadingCacheCleanupSeconds", 0)
                if kind == "replacement":
                    operations = config["operations"] * config["batches"] * config["workers"]
                    resident = config["capacity"] // 2
                    assert value["operations"] == operations and value["finalCount"] == resident
                    versions = [0] * resident
                    for worker in range(config["workers"]):
                        partition = list(range(worker, resident, config["workers"]))
                        count = config["operations"] * config["batches"]
                        for offset, key in enumerate(partition):
                            last = offset + (count - 1 - offset) // len(partition) * len(partition)
                            versions[key] = int(
                                config["value_mode"] == "changed"
                                and (last // len(partition)) % 2 == 0
                            )
                    assert value["checksum"] == sum(
                        2 * key + version for key, version in enumerate(versions)
                    )
                elif kind == "trace":
                    operations = config["operations"]
                    assert value["requests"] == value["hits"] + value["misses"] == operations
                    assert value["backendCalls"] == value["misses"]
                    trace_file = root / f"{case['id']}.trace"
                    assert digest(trace_file) == value["canonicalTraceSha256"]
                    mapping, expected = {}, 0
                    for line in trace_file.read_text().splitlines():
                        key = int(line)
                        if key not in mapping:
                            mapping[key] = len(mapping)
                        expected += mapping[key]
                    assert expected == value["checksum"] and len(mapping) == value["distinctKeys"]
                    assert 0 <= value["finalCount"] <= config["capacity"]
                    assert value["countBeforeCleanup"] >= 0
                else:
                    operations = config["workers"]
                    assert (
                        value["callers"]
                        == value["successfulCallers"]
                        == value["pendingBeforeRelease"]
                        == operations
                    )
                    assert value["backendCalls"] == (1 if backend == "loadingcache" else operations)
            assert seconds > 0 and allocated >= 0
            if sample["warmup"]:
                continue
            entry = {
                "process": record["id"],
                "case": case["id"],
                "runtime": version,
                "backend": backend,
                "round": record["round"],
                "index": sample.get("sampleIndex", sample.get("index")),
                "operations": operations,
                "seconds": seconds,
                "nanosecondsPerOperation": seconds * 1e9 / operations,
                "operationsPerSecond": operations / seconds,
                "allocatedBytesPerOperation": allocated / operations,
                "cleanupInclusiveNanosecondsPerOperation": (seconds + cleanup_seconds)
                * 1e9
                / operations,
            }
            if kind == "trace":
                entry["hitRatio"] = value["hits"] / operations
                entry["countBeforeCleanup"] = value["countBeforeCleanup"]
                entry["finalCount"] = value["finalCount"]
                entry["endResidentFraction"] = value["countBeforeCleanup"] / config["capacity"]
            elif kind == "fanin":
                entry["backendCalls"] = value["backendCalls"]
            entries.append(entry)
            all_samples.append(entry)
        groups.setdefault((case["id"], version, backend), []).extend(entries)
    rows = []
    for case in cases.values():
        for version in ("8", "10"):
            first = groups[(case["id"], version, "loadingcache")]
            second = groups[(case["id"], version, "memorycache")]
            expected_count = 5 if case["kind"] == "fanin" else 10
            assert len(first) == len(second) == expected_count
            metric = {"trace": "hitRatio", "fanin": "backendCalls"}.get(
                case["kind"], "nanosecondsPerOperation"
            )
            local = distribution([value[metric] for value in first])
            memory = distribution([value[metric] for value in second])
            row = {
                "case": case["id"],
                "kind": case["kind"],
                "runtime": version,
                **case["config"],
                "metric": metric,
                "loadingcache": local,
                "memorycache": memory,
                "loadingcacheAllocationBytesPerOperation": statistics.median(
                    v["allocatedBytesPerOperation"] for v in first
                ),
                "memorycacheAllocationBytesPerOperation": statistics.median(
                    v["allocatedBytesPerOperation"] for v in second
                ),
            }
            if case["kind"] in ("read", "replacement"):
                row["costRatio"] = local["median"] / memory["median"]
                row["roundCostRatios"] = [
                    statistics.median(v[metric] for v in first if v["round"] == r)
                    / statistics.median(v[metric] for v in second if v["round"] == r)
                    for r in (0, 1)
                ]
                row["loadingcacheCleanupInclusiveNsPerOperation"] = statistics.median(
                    v["cleanupInclusiveNanosecondsPerOperation"] for v in first
                )
            elif case["kind"] == "trace":
                row["hitRateDifferencePercentagePoints"] = 100 * (
                    local["median"] - memory["median"]
                )
                for backend, samples in (("loadingcache", first), ("memorycache", second)):
                    for statistic, value in distribution(
                        [sample["endResidentFraction"] for sample in samples]
                    ).items():
                        row[backend + "EndResidentFraction" + statistic.title()] = value
            rows.append(row)
    save(output / "comparison.json", rows)
    save(output / "samples.json", all_samples)
    for kind in ("read", "replacement", "trace", "fanin"):
        selected = [row for row in rows if row["kind"] == kind]
        flat = []
        for row in selected:
            entry = {
                key: value for key, value in row.items() if not isinstance(value, (dict, list))
            }
            for backend in ("loadingcache", "memorycache"):
                entry.update({backend + "_" + key: value for key, value in row[backend].items()})
            if "roundCostRatios" in row:
                entry.update(
                    {f"round{r}CostRatio": v for r, v in enumerate(row["roundCostRatios"])}
                )
            flat.append(entry)
        with (output / f"{kind}.csv").open("w", newline="") as stream:
            writer = csv.DictWriter(
                stream,
                fieldnames=sorted(set().union(*(entry.keys() for entry in flat))),
                lineterminator="\n",
            )
            writer.writeheader()
            writer.writerows(flat)
    summary = {
        "processes": len(results),
        "pairedCases": len(rows),
        "measuredSamples": len(all_samples),
        "verified": True,
        "sourceCommit": read(root / "machine.json")["gitHead"],
        "traceEndResidency": {
            backend: distribution(
                [
                    sample["endResidentFraction"]
                    for sample in all_samples
                    if sample["backend"] == backend and "endResidentFraction" in sample
                ]
            )
            for backend in ("loadingcache", "memorycache")
        },
        "categories": {},
    }
    for version in ("8", "10"):
        summary["categories"][version] = {}
        for kind in ("read", "replacement"):
            selected = [
                row
                for row in rows
                if row["runtime"] == version
                and row["kind"] == kind
                and (kind != "read" or row["key_mode"] == "preboxed")
            ]
            ratios = [row["costRatio"] for row in selected]
            summary["categories"][version][kind] = {
                "cases": len(ratios),
                "costRatio": distribution(ratios),
                "loadingcacheLowerCostCases": sum(r < 1 for r in ratios),
                "roundDirectionDisagreements": sum(
                    (r["roundCostRatios"][0] < 1) != (r["roundCostRatios"][1] < 1) for r in selected
                ),
            }
    save(output / "verified-summary.json", summary)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
