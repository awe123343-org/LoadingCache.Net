"""Render verified comparisons as a self-contained, offline HTML report."""

import argparse
import html
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", type=Path)
    args = parser.parse_args()
    root = args.directory
    rows = json.loads((root / "comparison.json").read_text())
    summary = json.loads((root / "verified-summary.json").read_text())
    assert summary["verified"] and summary["processes"] == 584
    data = json.dumps(rows, ensure_ascii=False).replace("</", "<\\/")
    document = TEMPLATE.replace("__DATA__", data)
    document = document.replace("__COMMIT__", html.escape(summary["sourceCommit"][:7]))
    for backend in ("loadingcache", "memorycache"):
        for statistic in ("min", "max"):
            document = document.replace(
                "__" + backend.upper() + "_" + statistic.upper() + "__",
                f"{summary['traceEndResidency'][backend][statistic]:.3f}",
            )
    (root / "index.html").write_text(document)


TEMPLATE = r"""<!doctype html>
<html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>LoadingCache × MemoryCache — 實測比較</title>
<style>
:root{color-scheme:dark;--bg:#111619;--panel:#1b2328;--line:#344148;--text:#eaf0f2;--muted:#aab8c0;--green:#73ddbe;--amber:#ffc87a}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:16px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
main{max-width:1320px;margin:auto;padding:44px 30px 80px}a{color:var(--green)}h1{font-size:clamp(30px,5vw,52px);line-height:1.15;margin:12px 0 18px;letter-spacing:-1.5px}h2{font-size:23px;margin:0 0 12px}p{margin:10px 0}.kicker{font:12px/1.5 ui-monospace,monospace;letter-spacing:2px;color:var(--green)}.intro{max-width:850px;color:var(--muted);font-size:18px}.meta{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:28px 0}.meta div,.note,.controls{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:16px 20px}.meta strong{display:block;font-size:23px;font-weight:600}.meta small{color:var(--muted)}.note{margin:20px 0;padding:20px 24px}.note p{color:var(--muted)}.controls{display:flex;gap:18px;align-items:end;flex-wrap:wrap;margin:22px 0}label{display:flex;flex-direction:column;gap:5px;color:var(--muted);font-size:13px}select{font:inherit;font-size:15px;color:var(--text);border:1px solid var(--line);border-radius:7px;padding:10px 14px;background:var(--bg)}label.check{flex-direction:row;align-items:center;gap:8px;padding-bottom:12px}input{accent-color:var(--green)}.table-wrap{overflow-x:auto;border:1px solid var(--line);border-radius:12px}table{border-collapse:collapse;width:100%;min-width:780px;font-variant-numeric:tabular-nums}th,td{text-align:left;padding:16px 18px;border-bottom:1px solid var(--line);vertical-align:top}th{background:var(--panel);font-size:12px;text-transform:uppercase;letter-spacing:.7px;color:var(--muted);position:sticky;top:0}tbody tr:last-child td{border-bottom:0}td small{display:block;color:var(--muted);font-size:12px;margin-top:3px}td strong{font-size:19px;font-weight:550}td.num{min-width:155px;white-space:nowrap}.good{color:var(--green)}.mixed{color:var(--amber)}.caption{color:var(--muted);font-size:14px;margin:16px 0}.empty{text-align:center;color:var(--muted);padding:40px}.links{display:flex;flex-wrap:wrap;gap:20px;margin-top:24px;font-size:14px}.foot{color:var(--muted);font-size:13px;margin-top:35px;border-top:1px solid var(--line);padding-top:18px}@media(max-width:700px){main{padding:28px 18px 50px}.meta{grid-template-columns:repeat(2,1fr)}.controls{gap:12px}.note{padding:16px}}
</style></head><body><main>
<div class="kicker">MEASURED · macOS ARM64 · 2026-09-14</div>
<h1>LoadingCache × MemoryCache</h1>
<p class="intro">同一台 M1 Pro、相同 runtime 與 workload。把讀取、寫入、命中率與 backend 次數分開看；這些是本輪實測，並非所有 workload 的排名。</p>
<div class="meta"><div><strong>584</strong><small>validated processes</small></div><div><strong>.NET 8 / 10</strong><small>8.0.31 / 10.0.12</small></div><div><strong>2 rounds</strong><small>反轉 backend 執行順序</small></div><div><strong>__COMMIT__</strong><small>frozen source commit</small></div></div>
<div class="note"><h2>怎麼讀這張表</h2><p>Read／write 是 <strong>wall time ÷ 總操作數</strong>，越低越好。多 workers 時是整體吞吐的反數，<strong>不是單一 request latency 或 p99</strong>。表內顯示每個 backend 兩輪共 10 個 samples 的 median，下面保留範圍；兩輪輸贏不同會標註。Fan-in 是一輪、每 backend 5 個 samples。</p><p>主組使用預先建立的 object keys；native int 組另外包含 MemoryCache object-key API 的 boxing 成本。Fan-in 只比較同 key concurrent miss 的實際 loader 次數。</p></div>
<div class="note"><h2>命中率有容量差異，不能只看輸贏</h2><p>Trace 結束、cleanup 前的 resident count／設定容量：LoadingCache <strong>__LOADINGCACHE_MIN__–__LOADINGCACHE_MAX__×</strong>，MemoryCache <strong>__MEMORYCACHE_MIN__–__MEMORYCACHE_MAX__×</strong>。LoadingCache 使用 soft bound，cleanup 後全部收斂；MemoryCache 會拒絕超量寫入並進行 background compaction。</p><p>因此這是 native engine 的實際行為比較，<strong>並非相同即時 residency 的 policy oracle</strong>；hit-rate 優勢不能全歸功於 TinyLFU。表中列出末端 residency；peak／時間平均 residency 尚未量測。</p></div>
<div class="controls"><label>Runtime<select id="runtime"><option value="10">.NET 10.0.12</option><option value="8">.NET 8.0.31</option></select></label><label>Workload<select id="kind"><option value="read">Resident read</option><option value="replacement">Resident replacement</option><option value="trace">Capacity-pressure trace</option><option value="fanin">Same-key fan-in</option></select></label><label>Statistics<select id="statistics"><option value="off">Off</option><option value="on">On</option><option value="all">Off + On</option></select></label><label class="check"><input type="checkbox" id="native">包含 native int-key 組</label></div>
<p class="caption" id="caption"></p><div class="table-wrap"><table><thead><tr><th>配置</th><th>Workers / callers</th><th>LoadingCache</th><th>MemoryCache 10.0.12</th><th>差異</th></tr></thead><tbody id="rows"></tbody></table></div>
<div class="note"><h2>Correctness 與範圍</h2><p>每個 process 都驗 checksum、stats、capacity 或 loader count；source／DLL／runtime hashes 在執行前後核對。Read samples 必須零 miss。Warmups 與失敗 smoke 的 raw 都保留，不從平均值換算尾延遲。</p><p>Allocation regression 已另行定位為 background-GC counter accounting，原本門檻未放寬；.NET 8／10 各 30 次完整 suite，共 <strong>31,020 tests 通過</strong>。Bulk／weak references／listeners 四組 30 分鐘 stress，共 <strong>624,122,880 operations 通過</strong>。</p><p>仍有 release gates：完整平台矩陣、更多功能組合與 retained-heap 證據等。MemoryCache 的這輪結果<strong>不構成 1.0 production-readiness 認證</strong>。</p></div>
<div class="links"><a href="README.md">完整方法與解讀</a><a href="comparison.json">比較 JSON</a><a href="evidence.tar.gz">原始證據封存</a><a href="read.csv">Read CSV</a><a href="replacement.csv">Write CSV</a><a href="trace.csv">Trace CSV</a><a href="../../release-readiness.md">Release gates</a></div>
<p class="foot">Microsoft.Extensions.Caching.Memory；不是 System.Runtime.Caching.MemoryCache。原生 GetOrCreateAsync 未額外加 single-flight wrapper。沒有與本 task 的 build／tests／profiler 重疊計時。互動式工作站結果，未宣稱 dedicated performance lab 或 SLA。</p>
</main><script id="data" type="application/json">__DATA__</script><script>
const data=JSON.parse(document.getElementById('data').textContent);
const $=id=>document.getElementById(id);
const number=(n,d=2)=>n.toLocaleString('en-US',{maximumFractionDigits:d,minimumFractionDigits:d});
function cell(text,sub='',cls=''){const td=document.createElement('td');td.className=cls;const strong=document.createElement('strong');strong.textContent=text;td.append(strong);if(sub){const small=document.createElement('small');small.textContent=sub;td.append(small);}return td;}
function render(){const kind=$('kind').value;const rows=data.filter(r=>r.runtime===$('runtime').value&&r.kind===kind&&($('statistics').value==='all'||r.statistics===$('statistics').value)&&(kind!=='read'||$('native').checked||r.key_mode==='preboxed'));
$('rows').replaceChildren();$('native').disabled=kind!=='read';
$('caption').textContent=rows.length+' 組配置 · '+({read:'ns/op；數值下列為 sample min–max。B/op 是 process managed-allocation accounting，包含維護工作。',replacement:'容量 1,024、resident 512；disjoint worker keys。同 ref／換 ref 分開比較。',trace:'列出 hit ratio 與末端 residency／設定容量範圍；不是同即時 residency 的純 policy 比較。',fanin:'所有 caller 在 gate release 前都 pending。這是 backend 次數，不是延遲 benchmark。'}[kind]);
for(const r of rows){const tr=document.createElement('tr');let title,sub;
if(kind==='read'){title=r.pattern==='hot'?'One hot key':'Cycle resident keys';sub=`C=${r.capacity.toLocaleString()} / R=${r.residents.toLocaleString()} · ${r.expiration} expiry · ${r.key_mode} · stats ${r.statistics}`;}
else if(kind==='replacement'){title=r.value_mode==='same'?'同一個 value reference':'交替兩個 value references';sub=`${r.operations.toLocaleString()} × ${r.batches} writes / worker · stats ${r.statistics}`;}
else if(kind==='trace'){title=r.trace_kind;sub=`C=${r.capacity.toLocaleString()} · ${r.operations.toLocaleString()} requests · seed ${r.seed}`;}
else{title='同 key pending miss';sub=`原生 API · stats ${r.statistics}`;}
tr.append(cell(title,sub),cell(String(r.workers),'','num'));
for(const backend of ['loadingcache','memorycache']){const v=r[backend];const factor=kind==='trace'?100:1;const suffix=kind==='trace'?'%':kind==='fanin'?' calls':' ns/op';let detail=kind==='fanin'?'每組 5 samples':`${number(v.min*factor)}–${number(v.max*factor)}${kind==='trace'?'%':' ns/op'}`;
if(kind==='read'||kind==='replacement')detail+=` · ${number(r[backend+'AllocationBytesPerOperation'],3)} B/op`;
if(kind==='trace')detail+=` · end residency ${number(r[backend+'EndResidentFractionMin'],3)}–${number(r[backend+'EndResidentFractionMax'],3)}× C`;
tr.append(cell(number(v.median*factor,kind==='fanin'?0:2)+suffix,detail,'num'));}
let diff,detail='',cls='';if(kind==='trace'){diff=(r.hitRateDifferencePercentagePoints>=0?'+':'')+number(r.hitRateDifferencePercentagePoints)+' pp';cls=r.hitRateDifferencePercentagePoints>=0?'good':'mixed';}
else if(kind==='fanin'){diff=r.memorycache.median===r.loadingcache.median?'相同':`${number(r.memorycache.median/r.loadingcache.median,0)}× backend calls`;detail=r.memorycache.median===r.loadingcache.median?'':'MemoryCache / LoadingCache';cls='good';}
else{const ratio=r.costRatio;diff=ratio<1?`LC 低 ${number((1-ratio)*100,1)}% 成本`:`LC 高 ${number((ratio-1)*100,1)}% 成本`;cls=ratio<1?'good':'mixed';detail=`round ratios ${r.roundCostRatios.map(x=>number(x,2)).join(' / ')}`;if((r.roundCostRatios[0]<1)!==(r.roundCostRatios[1]<1)){detail+=' · 兩輪方向不同';cls='mixed';}}
tr.append(cell(diff,detail,cls));$('rows').append(tr);}
if(!rows.length){const tr=document.createElement('tr');const td=document.createElement('td');td.colSpan=5;td.className='empty';td.textContent='這個類別沒有此 stats 配置；可切換 Off 或 Off + On。';tr.append(td);$('rows').append(tr);}}
for(const id of ['runtime','kind','statistics','native'])$(id).addEventListener('change',render);render();
</script></body></html>"""


if __name__ == "__main__":
    main()
