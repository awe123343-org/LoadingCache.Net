"""Archive raw evidence without redistributing runtimes or package binaries."""

import argparse
import gzip
import hashlib
import json
import tarfile
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root, output = args.input.resolve(), args.output.resolve()
    repo = Path(__file__).resolve().parents[3]
    summary = json.loads((output / "verified-summary.json").read_text())
    assert summary["verified"] and summary["processes"] == 584
    files = [
        p for p in root.rglob("*") if p.is_file() and "frozen" not in p.relative_to(root).parts
    ]
    for name in ("smoke-01", "smoke-02", "smoke-03"):
        source = root.parent / name
        files += [
            p
            for p in source.rglob("*")
            if p.is_file() and "frozen" not in p.relative_to(source).parts
        ]
    files += [root.parent / "final-build.log", root.parent / "package-identity.json"]
    files += [
        output / name
        for name in (
            "run.py",
            "analyze.py",
            "render.py",
            "archive.py",
            "verify_report.py",
            "upstream-inputs.json",
        )
    ]
    files = sorted(set(files))
    manifest = {str(p.relative_to(repo)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    archive_path = output / "evidence.tar.gz"
    with archive_path.open("wb") as stream:
        with gzip.GzipFile(fileobj=stream, mode="wb", mtime=0) as gz:
            with tarfile.open(fileobj=gz, mode="w") as archive:
                for path in files:
                    info = archive.gettarinfo(str(path), str(path.relative_to(repo)))
                    info.uid = info.gid = info.mtime = 0
                    info.uname = info.gname = ""
                    with path.open("rb") as source:
                        archive.addfile(info, source)
    with tarfile.open(archive_path) as archive:
        assert len(archive.getmembers()) == len(manifest)
        for path, expected in manifest.items():
            actual = hashlib.sha256(archive.extractfile(path).read()).hexdigest()
            assert actual == expected, path
    (output / "evidence-manifest.json").write_text(
        json.dumps(
            {
                "archiveSha256": hashlib.sha256(archive_path.read_bytes()).hexdigest(),
                "files": manifest,
                "binaryPolicy": "frozen binary/runtime manifests included; executable binaries omitted; native source commit and exact commands retained",
            },
            indent=2,
        )
        + "\n"
    )
    print(f"Verified {len(files)} files; archive {archive_path.stat().st_size} bytes")


if __name__ == "__main__":
    main()
