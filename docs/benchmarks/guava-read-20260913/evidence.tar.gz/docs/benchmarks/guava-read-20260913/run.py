"""Run fresh Guava/Caffeine/.NET read probes serially; preserve raw evidence."""

import argparse
import collections
import csv
import datetime
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
sys.path.insert(0, str(HERE.parent / "caffeine-read-20260913"))
summarize = importlib.import_module("compare").summarize
baseline_runner = importlib.import_module("run")
case_name = baseline_runner.case_name
validate = baseline_runner.validate


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def matrix():
    for pattern in ("hot", "cycle"):
        for workers in (1, 4, 10, 20):
            for statistics in ("off", "on"):
                yield (
                    "default4",
                    dict(
                        capacity=1024,
                        residents=512,
                        pattern=pattern,
                        workers=workers,
                        statistics=statistics,
                    ),
                )
    for workers in (1, 10):
        yield (
            "default4",
            dict(capacity=1024, residents=1, pattern="hot", workers=workers, statistics="off"),
        )
        yield (
            "default4",
            dict(
                capacity=16384, residents=8192, pattern="cycle", workers=workers, statistics="off"
            ),
        )
    for residents, pattern, workers, statistics in (
        (1, "hot", 10, "off"),
        (1024, "hot", 1, "off"),
        (1024, "hot", 10, "off"),
        (1024, "cycle", 10, "off"),
        (1024, "hot", 10, "on"),
        (1024, "cycle", 10, "on"),
    ):
        yield (
            "single1",
            dict(
                capacity=1024,
                residents=residents,
                pattern=pattern,
                workers=workers,
                statistics=statistics,
            ),
        )


def selected_cases(smoke):
    cases = list(matrix())
    return [cases[0], cases[-1]] if smoke else cases


def snapshot_verifier():
    spec = importlib.util.spec_from_file_location(
        "snapshot_checks", HERE.parent / "read-optimization-20260913/verify.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def verify_and_summarize(directory):
    manifest = json.loads((directory / "commands.json").read_text())
    assert manifest["status"] in ("probes-passed", "passed")
    options = manifest["options"]
    checks = snapshot_verifier()
    snapshot, evidence = checks.verify_snapshot(Path(options["snapshot"]))
    for path, digest in manifest["inputHashes"].items():
        assert sha(path) == digest, f"Changed input: {path}"
    for name, digest in snapshot["files"].items():
        assert sha(REPO / name) == digest, f"Current source changed: {name}"
    cases = selected_cases(options["smoke"])
    expected = {
        (profile, case_name(case), runtime, round_index)
        for profile, case in cases
        for runtime in manifest["runtimes"]
        for round_index in (1, 2)
    }
    groups = collections.defaultdict(lambda: collections.defaultdict(list))
    rounds = collections.defaultdict(lambda: collections.defaultdict(dict))
    observed = collections.defaultdict(set)
    identities = set()
    for entry in manifest["commands"]:
        identity = (entry["profile"], case_name(entry["case"]), entry["runtime"], entry["round"])
        assert identity not in identities and identity in expected
        identities.add(identity)
        assert entry["exitCode"] == 0 and entry["validated"]
        raw = directory / Path(entry["raw"]).name
        assert sha(raw) == entry["rawSha256"]
        assert sha(directory / Path(entry["log"]).name) == entry["logSha256"]
        report = json.loads(raw.read_text())
        validate(report, entry["case"], options["warmups"], options["runs"])
        assert report["warmups"] == options["warmups"] and report["runs"] == options["runs"]
        assert (
            report.get("durationMillis", report.get("durationMilliseconds"))
            == options["duration_ms"]
        )
        runtime = entry["runtime"]
        if runtime.startswith("net"):
            checks.verify_dotnet_assemblies(
                report, entry["argv"], snapshot, "HitProbe", runtime + ".0"
            )
            assert report["runtime"] == {"net8": ".NET 8.0.31", "net10": ".NET 10.0.12"}[runtime]
        else:
            assert report["failure"] is None
            assert report["runtime"] == "25.0.4.1+1-LTS"
            prefix = runtime
            assert report[prefix + "JarSha256"] == sha(options[runtime + "_jar"])
            assert (
                report[prefix + "Version"] == {"guava": "33.7.1-jre", "caffeine": "3.2.4"}[runtime]
            )
            if runtime == "guava":
                assert report["concurrencyLevel"] == (4 if entry["profile"] == "default4" else 1)
        observed[runtime].add(report["runtime"])
        key = identity[:2]
        measured = [sample for sample in report["samples"] if not sample["warmup"]]
        groups[key][runtime].extend(measured)
        rounds[key][entry["round"]][runtime] = summarize(measured)
    assert identities == expected
    rows = []
    for profile, case in cases:
        key = profile, case_name(case)
        costs = {runtime: summarize(samples) for runtime, samples in groups[key].items()}
        row = {"profile": profile, **case}
        for runtime, cost in costs.items():
            row[runtime + "NsPerOp"] = cost["nsPerOp"]
            row[runtime + "IncludingCleanupNsPerOp"] = cost["includingCleanupNsPerOp"]
            row[runtime + "SampleMinNsPerOp"] = cost["sampleMinNsPerOp"]
            row[runtime + "SampleMaxNsPerOp"] = cost["sampleMaxNsPerOp"]
        for runtime in ("net8", "net10", "caffeine"):
            ratios = [
                data[runtime]["nsPerOp"] / data["guava"]["nsPerOp"] for data in rounds[key].values()
            ]
            row[runtime + "OverGuava"] = costs[runtime]["nsPerOp"] / costs["guava"]["nsPerOp"]
            row[runtime + "OverGuavaRoundMin"] = min(ratios)
            row[runtime + "OverGuavaRoundMax"] = max(ratios)
        rows.append(row)
    with (directory / "comparison.csv").open("w", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    result = {
        "status": "passed",
        "cases": len(rows),
        "processes": len(identities),
        "samplesIncludingWarmup": len(identities) * (options["warmups"] + options["runs"]),
        "observedRuntimes": {key: sorted(value) for key, value in observed.items()},
        "snapshotVerification": evidence,
        "rows": rows,
    }
    save(directory / "summary.json", result)
    manifest["status"] = "passed"
    save(directory / "commands.json", manifest)
    print(
        json.dumps(
            {
                key: value
                for key, value in result.items()
                if key not in ("rows", "snapshotVerification")
            }
        )
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument(
        "--snapshot",
        default=str(HERE.parent / "read-followthrough-20260913/thin-offer/source-manifest.json"),
    )
    parser.add_argument(
        "--java", default="/Library/Java/JavaVirtualMachines/zulu-25.jdk/Contents/Home/bin/java"
    )
    parser.add_argument(
        "--caffeine-classes",
        default="/private/tmp/loadingcache-caffeine-read-20260913-ymvnln0g/java-classes",
    )
    parser.add_argument(
        "--caffeine-jar",
        default="/private/tmp/loadingcache-caffeine-read-20260913-ymvnln0g/caffeine-3.2.4.jar",
    )
    parser.add_argument(
        "--guava-classes", default="/private/tmp/loadingcache-guava-read-20260913/java-classes"
    )
    parser.add_argument(
        "--guava-jar", default="/private/tmp/loadingcache-guava-read-20260913/guava-33.7.1-jre.jar"
    )
    parser.add_argument(
        "--failureaccess-jar",
        default="/private/tmp/loadingcache-guava-read-20260913/failureaccess-1.0.3.jar",
    )
    parser.add_argument("--warmups", type=int, default=3)
    parser.add_argument("--runs", type=int, default=5)
    parser.add_argument("--duration-ms", type=int, default=500)
    options = parser.parse_args()
    output = options.output.resolve()
    if options.verify_only:
        verify_and_summarize(output)
        return
    assert options.warmups >= 0 and options.runs > 0 and options.duration_ms > 0
    output.mkdir(parents=True, exist_ok=False)
    snapshot, _ = snapshot_verifier().verify_snapshot(Path(options.snapshot))
    for name, digest in snapshot["files"].items():
        assert sha(REPO / name) == digest, f"Current source changed: {name}"
    runtimes = {}
    for version in (8, 10):
        runtimes[f"net{version}"] = [
            str(REPO / f"artifacts/runtime{version}/dotnet"),
            str(
                Path(snapshot["root"])
                / f"tools/LoadingCache.HitProbe/bin/Release/net{version}.0/LoadingCache.HitProbe.dll"
            ),
        ]
    for name in ("caffeine", "guava"):
        classpath = [getattr(options, name + "_classes"), getattr(options, name + "_jar")]
        if name == "guava":
            classpath.append(options.failureaccess_jar)
        runtimes[name] = [
            options.java,
            "-cp",
            os.pathsep.join(classpath),
            f"baseline.{name.title()}HitProbe",
        ]
    inputs = [
        Path(__file__),
        Path(options.snapshot),
        Path(options.caffeine_jar),
        Path(options.guava_jar),
        Path(options.failureaccess_jar),
        Path(options.java),
    ]
    for name in ("caffeine", "guava"):
        inputs.extend(Path(getattr(options, name + "_classes")).rglob("*.class"))
    inputs.extend((REPO / "tools/LoadingCache.HitProbe.Java/src").rglob("*.java"))
    inputs.extend((REPO / "tools/LoadingCache.HitProbe.Guava/src").rglob("*.java"))
    inputs.extend(
        HERE.parent / "caffeine-read-20260913" / name for name in ("run.py", "compare.py")
    )
    inputs.extend(
        [
            HERE.parent / "read-optimization-20260913/verify.py",
            HERE / "downloads.json",
            HERE / "probe-validation-final/manifest.json",
        ]
    )
    inputs.extend(Path(argv[0]) for argv in runtimes.values())
    commands = []
    manifest = {
        "status": "running",
        "startedUtc": datetime.datetime.now(datetime.UTC).isoformat(),
        "options": {
            key: str(value) if isinstance(value, Path) else value
            for key, value in vars(options).items()
        },
        "head": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "inputHashes": {str(path.resolve()): sha(path) for path in inputs},
        "runtimes": runtimes,
        "runtimeEnvironment": {
            key: value
            for key, value in os.environ.items()
            if key.startswith(("DOTNET_", "COMPlus_"))
            or key in ("JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "_JAVA_OPTIONS")
        },
        "commands": commands,
    }
    path = output / "commands.json"
    save(path, manifest)
    cases = selected_cases(options.smoke)
    for round_index in (1, 2):
        order = list(runtimes) if round_index == 1 else list(reversed(runtimes))
        for profile, case in cases if round_index == 1 else reversed(cases):
            for runtime in order:
                name = f"round{round_index}-{profile}-{case_name(case)}-{runtime}"
                raw, log = output / (name + ".json"), output / (name + ".log")
                argv = runtimes[runtime].copy()
                for key, value in case.items():
                    argv.extend(["--" + key, str(value)])
                if runtime == "guava":
                    argv.extend(["--concurrency-level", "4" if profile == "default4" else "1"])
                argv.extend(
                    [
                        "--warmups",
                        str(options.warmups),
                        "--runs",
                        str(options.runs),
                        "--duration-ms",
                        str(options.duration_ms),
                        "--output",
                        str(raw),
                    ]
                )
                entry = {
                    "name": name,
                    "profile": profile,
                    "case": case,
                    "runtime": runtime,
                    "round": round_index,
                    "argv": argv,
                    "cwd": os.getcwd(),
                    "raw": str(raw),
                    "log": str(log),
                    "startedUtc": datetime.datetime.now(datetime.UTC).isoformat(),
                }
                commands.append(entry)
                save(path, manifest)
                print(f"[{len(commands)}/{len(cases) * 8}] {name}", flush=True)
                started = time.monotonic()
                try:
                    with log.open("w") as stream:
                        result = subprocess.run(
                            argv, stdout=stream, stderr=subprocess.STDOUT, timeout=120, check=False
                        )
                    entry.update(
                        exitCode=result.returncode,
                        elapsedSeconds=time.monotonic() - started,
                        logSha256=sha(log),
                    )
                    assert result.returncode == 0, str(log)
                    validate(json.loads(raw.read_text()), case, options.warmups, options.runs)
                    entry.update(validated=True, rawSha256=sha(raw))
                except BaseException as error:
                    entry["error"] = repr(error)
                    manifest["status"] = "failed"
                    save(path, manifest)
                    raise
                save(path, manifest)
    manifest.update(
        status="probes-passed", finishedUtc=datetime.datetime.now(datetime.UTC).isoformat()
    )
    save(path, manifest)
    try:
        verify_and_summarize(output)
    except BaseException as error:
        manifest.update(status="verification-failed", verificationError=repr(error))
        save(path, manifest)
        raise


if __name__ == "__main__":
    main()
