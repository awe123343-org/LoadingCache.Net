# Guava / Caffeine / LoadingCache.NET resident-read 對照

2026-09-13，本機 macOS ARM64。狀態：208 processes / 1,664 samples（其中 1,040 measured）全部通過驗證。

## 配置與比較範圍

本輪延續 resident-hit 測量，四方全部重新執行：Guava **33.7.1-jre**、Caffeine **3.2.4**、
LoadingCache.NET on **.NET 8.0.31 / 10.0.12**；兩個 Java cache 使用同一個 Zulu JDK
**25.0.4.1+1-LTS**。固定 .NET source 為上一輪 `thin-offer` snapshot，開始前核對全部
72 個輸入檔案與目前 worktree 相同，未因新增 baseline 修改 runtime。

Guava 版本來自[官方 release](https://github.com/google/guava/releases/tag/v33.7.1)，
固定 commit `c5b5a383a1f7f4a84c17de910f61181011c95908`。Guava cache 的
[builder](https://github.com/google/guava/blob/c5b5a383a1f7f4a84c17de910f61181011c95908/guava/src/com/google/common/cache/CacheBuilder.java)
預設 `concurrencyLevel=4`，其 size bound 按 segment 管理。實際 preflight 插入
1,024 個連續整數 keys 後只有 **1,010 residents**；失敗 JSON 保存在
[probe-validation](probe-validation/)。這是合法的提早 eviction，不能用這個配置測零 miss 的滿容量 hit。

因此預先固定兩組 matrix，並讓每一列的四個實作使用相同 capacity、resident keys、讀取模式與 stats 設定：

| 組別            | Guava 設定         | 容量 / residents                 | 案例                                                         |
| --------------- | ------------------ | -------------------------------- | ------------------------------------------------------------ |
| `default4` 主組 | 預設值 4           | 1024 / 512                       | hot、cycle × workers 1/4/10/20 × stats off/on：16 組         |
| `default4` 補充 | 預設值 4           | 1024 / 1；16384 / 8192           | sparse hot、大 cache cycle，各 workers 1/10、stats off：4 組 |
| `single1` 補充  | 明確設定 1，非預設 | 1024 / 1024，另 1 個 sparse 案例 | 原先六個 focused cases：6 組                                 |

`concurrencyLevel=1` 並未把讀取 worker 限成一個；它改變 Guava 的 segment 配置。
主組是半滿 cache，會包含各實作的 under-capacity fast path；不能把主組數字和先前 full-cache
報告混成一次實驗，也不能只用 single-segment 結果代表 Guava 預設效能。

## 測量協議

- 同一台 M1 Pro、10 cores、ARM64、16 GiB、macOS 26.6.2；使用預先建立的 binaries。
- 每 case/runtime 新 process；persistent platform threads、barrier 同步、1024 lookup chunks，
  預先建立整數 keys/values，hot 是同 key，cycle 以固定 offset 走訪全部 resident keys。
- 每 process 3 次 warmup + 5 次 measured，每次 500 ms；兩輪同時反轉 case/runtime 順序。
  26 cases × 4 runtimes × 2 rounds = 208 processes。
- 本任務的 timed processes 串行執行，沒有並行 builds、tests 或 profilers。
- 每 sample 驗證零 misses、checksum、每個 worker 有進展、operation totals、stats delta、
  quiescent resident count 與 unit weight。Cleanup 在樣本後單獨計時。
- `ns/op = Σ wall time / Σ aggregate operations`，越小越好；這是 throughput 的倒數，
  **不是單次 request latency，也不能推算 p99**。另保存包含 cleanup 的 cost 和各輪 ratio。
- .NET 保持 default tiering/PGO、workstation GC；Java 使用 default JVM/JIT/GC。
  不為任一方專門調整 GC、關閉維護或變更 hit 語義。
- Java allocation 僅涵蓋 reader threads，.NET 為 process-wide managed allocation；
  Java GC delta 包含 cleanup、.NET 不包含。原始欄位保存，但不以不同 scope 的數字宣稱 allocation 勝負。
- 這是本機 closed-loop harness，沒有 JMH/BDN 統計顯著性保證、CPU isolation 或 overload arrival queue；
  兩輪反轉只能降低部分順序偏差。這次未測 write、policy hit ratio、loading、refresh、TTL 或長 stress。

## 結果

**結果依場景不同：1,024 容量 / 512 residents 的單 reader 案例，我們仍慢於 Guava；多 readers 案例則明顯快於 Guava。Caffeine 在本輪所有案例都快於我們。**

以下均為 `ns/op`（aggregate throughput 倒數，越小越好），合併兩輪各五次 measured samples；不混用先前 Caffeine 報告數值。

### 預設 concurrencyLevel=4：完整 20 cases

| 容量 / resident | 模式  | readers | stats | .NET 8 | .NET 10 | Caffeine |  Guava | .NET10 / Guava cost |
| --------------- | ----- | ------: | ----- | -----: | ------: | -------: | -----: | ------------------: |
| 1024 / 512      | hot   |       1 | off   |  39.84 |   40.41 |    16.16 |  33.74 |               1.198 |
| 1024 / 512      | hot   |       1 | on    |  51.43 |   52.76 |    20.65 |  35.71 |               1.477 |
| 1024 / 512      | hot   |       4 | off   |   9.22 |    8.97 |     4.79 | 155.31 |               0.058 |
| 1024 / 512      | hot   |       4 | on    |  15.59 |   15.52 |     6.78 | 151.84 |               0.102 |
| 1024 / 512      | hot   |      10 | off   |   3.82 |    4.88 |     1.53 | 233.37 |               0.021 |
| 1024 / 512      | hot   |      10 | on    |   7.54 |   10.61 |     2.18 | 252.52 |               0.042 |
| 1024 / 512      | hot   |      20 | off   |   3.05 |    3.22 |     1.35 | 253.91 |               0.013 |
| 1024 / 512      | hot   |      20 | on    |   6.23 |    6.54 |     1.96 | 249.10 |               0.026 |
| 1024 / 512      | cycle |       1 | off   |  37.20 |   37.54 |    17.21 |  35.33 |               1.063 |
| 1024 / 512      | cycle |       1 | on    |  56.06 |   54.65 |    22.28 |  37.02 |               1.476 |
| 1024 / 512      | cycle |       4 | off   |   7.11 |    8.69 |     4.10 |  63.76 |               0.136 |
| 1024 / 512      | cycle |       4 | on    |  10.50 |   12.34 |     6.13 |  64.74 |               0.191 |
| 1024 / 512      | cycle |      10 | off   |   3.38 |    3.30 |     2.11 |  89.73 |               0.037 |
| 1024 / 512      | cycle |      10 | on    |   7.56 |    9.59 |     3.37 |  88.25 |               0.109 |
| 1024 / 512      | cycle |      20 | off   |   3.21 |    2.90 |     1.69 |  86.73 |               0.033 |
| 1024 / 512      | cycle |      20 | on    |   6.52 |    6.74 |     2.61 |  85.14 |               0.079 |
| 1024 / 1        | hot   |       1 | off   |  10.25 |   10.01 |     5.69 |  31.61 |               0.317 |
| 16384 / 8192    | cycle |       1 | off   |  31.26 |   34.79 |    16.44 |  41.56 |               0.837 |
| 1024 / 1        | hot   |      10 | off   |   1.33 |    1.28 |     1.00 | 245.31 |               0.005 |
| 16384 / 8192    | cycle |      10 | off   |   4.31 |    3.32 |     2.10 |  89.59 |               0.037 |

主組 20 cases：.NET 8 與 .NET 10 均為 16 組 cost 較低、4 組較高。4 組較高都在
1024 / 512 的單 reader hot/cycle、stats off/on；.NET 8 cost 高 5.3–51.4%，.NET 10 高 6.3–47.7%。
多 readers 的 14 組全部方向相反；sparse-one-key 有 under-capacity fast path，必須保留配置，不拿最大倍數當一般 workload 宣傳。

### 非預設 concurrencyLevel=1：滿容量補充

| residents（容量1024） | 模式  | readers | stats | .NET 8 | .NET 10 | Caffeine |  Guava | .NET10 / Guava cost |
| --------------------: | ----- | ------: | ----- | -----: | ------: | -------: | -----: | ------------------: |
|                     1 | hot   |      10 | off   |   1.33 |    1.28 |     1.00 | 247.57 |               0.005 |
|                  1024 | hot   |       1 | off   |  40.85 |   42.23 |    15.42 |  34.29 |               1.232 |
|                  1024 | hot   |      10 | off   |   4.09 |    4.91 |     1.42 | 244.69 |               0.020 |
|                  1024 | cycle |      10 | off   |   4.50 |    4.18 |     2.13 | 246.72 |               0.017 |
|                  1024 | hot   |      10 | on    |   7.54 |    9.49 |     2.01 | 245.06 |               0.039 |
|                  1024 | cycle |      10 | on    |   9.24 |   10.07 |     3.36 | 245.94 |               0.041 |

這組滿容量結果保留相同方向：single reader 我們 cost 高約 19–23%；10 readers 的 hot/cycle 則較快。
從 source 結構推論，一個 Guava segment 會使 cycle readers 集中到同一組共享狀態；
兩表的 residents 也不同，本輪未隔離這兩項變因，不能直接把性能差幅歸因於 segment 數量。
這組不能代替 default4 結論。

### 證據邊界與原因線索

- 兩輪各自的 ratio min/max、每個 sample、含 cleanup cost 已保存在 [comparison.csv](raw/comparison.csv)
  與 [summary.json](raw/summary.json)；所有 raw JSON/commands/log hashes 均可重播驗證。
- 同一 `thin-offer` source 的 full/hot/1reader/stats-off，在上一輪 net10 為 29.48 ns/op，本輪為
  42.23 ns/op；source 與 binaries 未改。這個跨批次變化的原因**尚未定位**，不能直接當成 code regression，
  也不能靠猜測 JIT/warmup/host noise 便宣稱已解釋。精確絕對成本仍需更穩定環境及 profiling 驗證。
- [Guava LocalCache 的 pinned source](https://github.com/google/guava/blob/c5b5a383a1f7f4a84c17de910f61181011c95908/guava/src/com/google/common/cache/LocalCache.java#L2539)
  顯示 hit 會加入 recency queue，並更新 segment read counter、週期性嘗試 cleanup；同 key readers 集中在
  同一 segment。這與本輪同 key contention 現象一致，**只是 source-based 線索，未用 profiler 量化各成本占比**。
- Guava 的版本、配置和容量特性與 Caffeine 不同；本輪沒有證明 policy hit rate、功能完整度或 loading 效能高低。
- 沒有重跑未變 runtime 的 NUnit/AOT/package suite；本輪只新增 benchmark adapter/runner 與報告。

## 來源、驗證與重跑

- [Guava adapter](../../../tools/LoadingCache.HitProbe.Guava/README.md) 沿用原 Caffeine harness；
  diff 只涉及 cache API/config、unit-weight 報告及 artifact provenance。
- [downloads.json](downloads.json)：官方 Maven artifacts、source/授權 URLs、SHA-256、存取時間。
  Guava 與 failureaccess 均保留上游 Apache-2.0 license；新 harness 未移植 Guava runtime source。
  `error_prone_annotations` 2.50.0 僅用於 javac 的 compile classpath，版本由 pinned Guava POM 確定。
- [probe-validation-final/manifest.json](probe-validation-final/manifest.json)：javac
  `--release 25 -Xlint:all -Werror`，exit 0 / 0 warnings，source/JAR/class hashes 與最終 smoke。
  初次 compile 的 4 個 missing-annotation warnings 與初始 6 個成功 smoke、2 個預期拒絕保留在
  `probe-validation/`，沒有 suppress warning。
- [runner-smoke/summary.json](runner-smoke/summary.json)：2 cases × 4 runtimes × 2 rounds，
  16 processes / 32 samples 通過；只驗證 harness，不作性能結論。
- [parent-verification.json](parent-verification.json)：獨立 Astra reviewer 重算全部 aggregates，
  驗證 208 processes、1,664 samples、72 source、36 binaries、35 inputs、7 downloads、14 Guava build
  artifacts，以及 serial / reverse ordering；exit 0，Python assertions 已啟用。
- [原 .NET snapshot](../read-followthrough-20260913/thin-offer/source-manifest.json)：
  72 source / 36 binary hashes、build commands/logs；相鄰 `source.tar.gz` 保留 source。
- `raw/commands.json` 保存每個命令、UTC、cwd、exit code、runtime environment、input/raw/log hashes；
  `raw/comparison.csv`、`raw/summary.json` 由完整驗證器重算。

```sh
uv run --no-project python docs/benchmarks/guava-read-20260913/run.py \
  --output docs/benchmarks/guava-read-20260913/raw

uv run --no-project python docs/benchmarks/guava-read-20260913/run.py \
  --output docs/benchmarks/guava-read-20260913/raw --verify-only
```

執行新的測量請指定另一個尚不存在的 output directory；保留舊 raw evidence。
`run.py --help` 可改 snapshot/JDK/JAR/classes 路徑；重建 Guava 的完整命令與 compile dependency
在 `probe-validation-final/manifest.json`。更換 source/runtime/version 必須另建報告並更新固定版本驗證。

本輪比較不解除上一輪的 write regression 或 intermittent weak-key allocation-test blocker，
也不構成 1.0 production readiness。
