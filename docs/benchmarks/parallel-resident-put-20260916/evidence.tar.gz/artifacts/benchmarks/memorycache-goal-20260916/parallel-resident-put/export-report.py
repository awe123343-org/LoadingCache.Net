"""Verify completed evidence and export it; never build or run a cache workload."""

import argparse
import csv
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
OUT = ROOT / "docs/benchmarks/parallel-resident-put-20260916"
BASE = ROOT / "artifacts/benchmarks/memorycache-goal-20260915/retained-maintenance-memorycache"
FINAL = ROOT / "artifacts/validation/memorycache-goal-20260916/parallel-resident-put-final-01"
SOAK = FINAL.parent / "parallel-resident-put-soak"
MATRIX = HERE / "memorycache-full-01"
ANALYZER = ROOT / "docs/benchmarks/memorycache-20260914/analyze.py"
PAIRED = ROOT / "artifacts/benchmarks/memorycache-goal-20260915/contended-controls/fixed-path.py"
HELPERS = [ANALYZER, PAIRED, ROOT / "docs/benchmarks/memorycache-20260914/run.py", ROOT / "tools/validate.py"]


def read(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def relative(path):
    return str(path.relative_to(ROOT))


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    loaded = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded


def verify_manifest(root, manifest):
    for name, expected in manifest.items():
        path = root / name
        assert path.resolve().is_relative_to(root.resolve()), name
        assert sha(path) == expected, path


def counts(path):
    tree = ET.parse(path)
    counter = tree.find(".//{*}ResultSummary/{*}Counters")
    assert counter is not None, path
    result = {key: int(counter.get(key, "0")) for key in ("total", "executed", "passed", "failed", "notExecuted")}
    tests = tree.findall(".//{*}Results/{*}UnitTestResult")
    assert result["total"] == result["executed"] == result["passed"] == len(tests) > 0
    assert result["failed"] == result["notExecuted"] == 0
    assert all(test.get("outcome") == "Passed" for test in tests)
    return result


def source_snapshot(folder):
    sources = read(folder / "source-manifest.json")
    verify_manifest(folder / "executed-source", sources)
    return sources


def core_hash(binaries):
    cores = {digest for name, digest in binaries.items() if Path(name).name == "LoadingCache.dll"}
    assert len(cores) == 1, cores
    return cores.pop()


def verify_validation(core, matrix_sources, runtime):
    result = read(FINAL / "results.json")
    assert result["source_unchanged"] and result["unrun_commands"] == []
    assert len(result["commands"]) == 14
    sources = source_snapshot(FINAL)
    # The matrix executor is frozen, but tools/validate.py deliberately excludes docs.
    assert matrix_sources.keys() - sources.keys() == {"docs/benchmarks/memorycache-20260914/run.py"}
    assert all(sources[name] == digest for name, digest in matrix_sources.items() if name in sources)
    binaries = read(FINAL / "binary-manifest.json")
    verify_manifest(ROOT, binaries)
    assert core_hash(binaries) == core
    assert read(FINAL / "runtime-manifest.json") == runtime
    binding = read(FINAL / "binding.json")
    test_counts, consumers = {}, []
    for command in result["commands"]:
        assert command["exit_code"] == 0, command
        assert (FINAL / command["log"]).is_file()
        argv = command["command"]
        if command["test_counts"] is not None:
            actual = counts(FINAL / (command["name"] + ".trx"))
            assert actual == command["test_counts"]
            version = command["name"].split("-net")[1].split(".")[0]
            assert f"RunConfiguration.DotNetHostPath={ROOT}/artifacts/runtime{version}/dotnet" in argv
            project = command["name"].split("-net")[0]
            assert binaries[f"tests/{project}/bin/Release/net{version}.0/LoadingCache.dll"] == core
            assert f"tests/{project}/bin/Release/net{version}.0/{project}.dll" in binaries
            test_counts[command["name"]] = actual["passed"]
        elif command["name"].startswith("consumer-"):
            version = command["name"].split("net")[1]
            assert argv[0] == str(ROOT / f"artifacts/runtime{version}/dotnet")
            assert binaries[f"tests/LoadingCache.ConsumerSmoke/bin/Release/net{version}.0/LoadingCache.dll"] == core
            assert str(Path(argv[1]).relative_to(ROOT)) in binaries
            consumers.append(command["name"])
    assert len(test_counts) == 6 and set(consumers) == {"consumer-net8", "consumer-net10"}
    return {"path": relative(FINAL), "tests": test_counts, "totalTests": sum(test_counts.values()), "consumers": 2,
            "commands": result["commands"], "binding": binding,
            "bindingLimit": "Surviving build outputs checked after validation; not per-test-process emitted assembly hashes."}, sources, binaries


def verify_soak(core, sources, binaries):
    completed = read(SOAK / "completed.json")
    assert completed["allPassed"] and completed["tests"] == 12 and completed["secondsPerCase"] == 300
    assert completed["runtimesSerial"] and completed["casesParallelWithinRuntime"]
    assert source_snapshot(SOAK) == sources
    records = read(SOAK / "results.json")
    assert len(records) == 2
    names = []
    for version, record in zip(("8", "10"), records, strict=True):
        folder = SOAK / f"net{version}"
        assert record["exitCode"] == 0 and record["runtime"] == {"8": "8.0.31", "10": "10.0.12"}[version]
        assert counts(folder / "soak.trx") == record["testCounts"]
        assert record["testCounts"]["passed"] == 6
        command = read(folder / "command.json")
        assert f"RunConfiguration.DotNetHostPath={ROOT}/artifacts/runtime{version}/dotnet" in command["argv"]
        assert command["environmentOverrides"]["LOADINGCACHE_SOAK_SECONDS"] == "300"
        assert command["environmentOverrides"]["LOADINGCACHE_FEATURE_SOAK_SECONDS"] == "300"
        soak_binaries = read(folder / "binary-manifest.json")
        verify_manifest(ROOT, soak_binaries)
        assert core_hash(soak_binaries) == core
        test_dll = f"tests/LoadingCache.StressTests/bin/Release/net{version}.0/LoadingCache.StressTests.dll"
        assert soak_binaries[test_dll] == binaries[test_dll]
        logs = sorted((folder / "soak").glob("*.jsonl"))
        assert len(logs) == len(record["jsonlHashes"]) == 6
        for path in logs:
            assert sha(path) == record["jsonlHashes"][path.name]
            events = [json.loads(line) for line in path.read_text().splitlines()]
            assert events[0]["Event"] == "start" and events[0]["seconds"] == 300
            assert events[0]["Runtime"] == ".NET " + record["runtime"]
            assert events[-1]["Event"] == "passed" and all(e["Event"] != "failed" for e in events)
        names.append(sorted(test.get("testName") for test in ET.parse(folder / "soak.trx").findall(".//{*}UnitTestResult")))
    assert names[0] == names[1]
    return {"path": relative(SOAK), "completed": completed, "results": records, "testNamesPerRuntime": names[0],
            "limit": "Six cases run concurrently within each runtime; twelve passing cases are bounded soak evidence."}


def verify_paired(folder, paired, core):
    completed, records = read(folder / "completed.json"), read(folder / "results.json")
    assert completed["allValidated"] and completed["frozenInputsUnchanged"] and completed["pairedExecutionPathsAndArgvIdentical"]
    assert completed["processes"] == len(records)
    inputs = read(folder / "inputs.json")
    roots = {"before": BASE, "after": HERE / "after"}
    for label, entry in inputs.items():
        verify_manifest(folder / "inputs" / label, entry["files"])
        expected = read(roots[label] / "source-manifest.json") | read(roots[label] / "binary-manifest.json")
        assert all(expected[name] == digest for name, digest in entry["files"].items())
    assert core_hash(inputs["after"]["files"]) == core
    for name, digest in inputs["before"]["files"].items():
        if name.startswith("tools/") or Path(name).name in ("LoadingCache.HitProbe.dll", "LoadingCache.MemoryCacheProbe.dll"):
            assert inputs["after"]["files"][name] == digest, name
    runtime = read(folder / "runtime-manifest.json")
    verify_manifest(ROOT, runtime)
    cases = {case["id"]: case for case in read(folder / "cases.json")}
    groups, measured, warmups = {}, 0, 0
    for row in records:
        capture = folder / row["id"]
        assert row["exitCode"] == 0 and row["validated"] and sha(capture / "raw.json") == row["rawSha256"]
        raw, argv = read(capture / "raw.json"), read(capture / "command.json")["argv"]
        case, files = cases[row["case"]], inputs[row["label"]]["files"]
        assert argv[:4] == [str(ROOT / f"artifacts/runtime{row['runtime']}/dotnet"), "exec", "--fx-version", paired.probe.RUNTIMES[row["runtime"]]]
        paired.probe.validate(raw, case, row["runtime"], "loadingcache", None)
        check_options(raw, case, argv, "loadingcache")
        probe = "HitProbe" if case["kind"] == "read" else "MemoryCacheProbe"
        prefix = f"frozen/net{row['runtime']}/{probe}/"
        assert argv[4] == str(folder / "execution" / prefix / f"LoadingCache.{probe}.dll")
        if case["kind"] == "read":
            paired.validate_read_report(raw, case, argv)
            assert raw["cacheAssemblySha256"].lower() == files[prefix + "LoadingCache.dll"]
            assert raw["harnessAssemblySha256"].lower() == files[prefix + "LoadingCache.HitProbe.dll"]
        else:
            assert raw["metadata"]["processSha256"] == runtime[relative(Path(argv[0]))]
            for assembly in raw["metadata"]["assemblies"]:
                path = Path(assembly["path"])
                expected = files[str(path.relative_to(folder / "execution"))] if path.is_relative_to(folder / "execution") else runtime[str(path.relative_to(ROOT))]
                assert assembly["sha256"] == expected
            assert all(files[s["path"]] == s["sha256"] for s in raw["metadata"]["sourceManifest"])
        samples = [s for s in raw["samples"] if not s["warmup"]]
        values = [s["wallSeconds"] * 1e9 / s["operations"] if case["kind"] == "read" else s["result"]["seconds"] * 1e9 / s["result"]["operations"] for s in samples]
        assert values == row["samplesNs"] and statistics.median(values) == row["medianNs"]
        measured += len(values)
        warmups += len(raw["samples"]) - len(values)
        pair = groups.setdefault((row["runtime"], row["case"], row["round"]), {})
        assert row["label"] not in pair
        pair[row["label"]] = (row["medianNs"], argv, files[prefix + f"LoadingCache.{probe}.dll"])
    for pair in groups.values():
        assert set(pair) == {"before", "after"} and pair["before"][1:] == pair["after"][1:]
    rows = []
    for version, case in sorted({(v, c) for v, c, _ in groups}):
        rounds = sorted(r for v, c, r in groups if (v, c) == (version, case))
        ratios = [groups[version, case, r]["after"][0] / groups[version, case, r]["before"][0] for r in rounds]
        rows.append({"runtime": version, "case": case, "ratios": ratios, "direction": direction(ratios)})
    report = {"processes": len(records), "measuredSamples": measured, "warmupSamples": warmups, "summary": rows,
              "counts": {d: sum(row["direction"] == d for row in rows) for d in ("lower", "higher", "mixed")}}
    assert report == read(folder / "verified.json")
    return {"path": relative(folder), "verifiedSha256": sha(folder / "verified.json"), **report}


def option(argv, name):
    assert argv.count(name) == 1, (name, argv)
    return argv[argv.index(name) + 1]


def check_options(raw, case, argv, backend):
    assert option(argv, "--backend") == backend
    assert "--diagnostics" not in argv
    metadata = raw if case["kind"] == "read" else raw["metadata"]
    environment = metadata["runtimeEnvironment"] if case["kind"] == "read" else metadata["environment"]
    assert not any(environment.values()) and not metadata["serverGc"]
    assert metadata["architecture"] == "Arm64"
    for name, value in case["config"].items():
        assert option(argv, "--" + name.replace("_", "-")) == str(value)
        key = name.split("_")[0] + "".join(part.title() for part in name.split("_")[1:])
        observed = raw if case["kind"] == "read" else raw["options"]
        assert observed[key] == (value == "on" if name == "statistics" else value), key
    measured = [s for s in raw["samples"] if not s["warmup"]]
    assert len(measured) == int(option(argv, "--runs"))
    assert sum(s["warmup"] for s in raw["samples"]) >= int(option(argv, "--warmups"))


def direction(ratios):
    return "lower" if all(r < 1 for r in ratios) else "higher" if all(r > 1 for r in ratios) else "mixed"


def archive(output):
    excluded = {"bin", "obj", "frozen", "execution", "__pycache__", ".git"}
    roots = [HERE, FINAL, SOAK, FINAL.parent / "parallel-resident-put", BASE, output]
    files = set(HELPERS)
    for folder in roots:
        for directory, dirs, names in os.walk(folder):
            dirs[:] = [name for name in dirs if name not in excluded]
            for name in names:
                path = Path(directory) / name
                if path.suffix.lower() in {".dll", ".pdb", ".pyc", ".gz", ".zip", ".nupkg", ".exe", ".dylib", ".so"} or name.startswith("evidence-members") or name == "archive.json":
                    continue
                assert not path.is_symlink(), path
                files.add(path)
    manifest = {relative(path): sha(path) for path in sorted(files)}
    save(output / "evidence-members.json", manifest)
    destination = output / "evidence.tar.gz"
    with tarfile.open(destination, "w:gz", compresslevel=6) as tar:
        for name in manifest:
            tar.add(ROOT / name, arcname=name, recursive=False)
    with tarfile.open(destination, "r:gz") as tar:
        members = tar.getmembers()
        assert len(members) == len(manifest) and all(member.isfile() for member in members)
        assert {member.name for member in members} == manifest.keys()
        for member in members:
            with tar.extractfile(member) as stream:
                assert hashlib.file_digest(stream, "sha256").hexdigest() == manifest[member.name]
    save(output / "archive.json", {"file": destination.name, "sha256": sha(destination), "members": len(manifest),
                                  "manifestSha256": sha(output / "evidence-members.json"), "allMembersReadBackVerified": True})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true", help="Authorize offline verification/report writes; no cache workloads.")
    parser.add_argument("--archive", action="store_true", help="Also preserve source/raw evidence and verify every archive member.")
    parser.add_argument("--output", type=Path, default=OUT)
    args = parser.parse_args()
    if not args.execute:
        parser.error("Prepared only. Run with --execute after all inputs and CPU handoff are ready.")
    output = args.output.resolve()
    assert output.is_relative_to(ROOT) and not output.exists(), "Use a fresh report directory; existing evidence is never replaced."
    paired = module("paired_export", PAIRED)
    sources = source_snapshot(MATRIX)
    binaries, runtime = read(MATRIX / "binary-manifest.json"), read(MATRIX / "runtime-manifest.json")
    verify_manifest(MATRIX, binaries)
    verify_manifest(ROOT, runtime)
    core = core_hash(binaries)
    assert core == read(HERE / "frozen.json")["candidateCoreSha256"]
    frozen_sources = source_snapshot(HERE / "after")
    assert all(sources[name] == digest for name, digest in frozen_sources.items() if name.startswith("src/"))
    validation, final_sources, final_binaries = verify_validation(core, sources, runtime)
    soak = verify_soak(core, final_sources, final_binaries)
    paired_reports = {name: verify_paired(HERE / name, paired, core) for name in ("write-normal-01", "controls-normal-01")}
    if (HERE / "read-confirmation-01").exists():
        paired_reports["read-confirmation-01"] = verify_paired(HERE / "read-confirmation-01", paired, core)
    cases = {c["id"]: c for c in read(MATRIX / "cases.json")}
    assert cases == {c["id"]: c for c in paired.probe.cases(False)}
    records, schedule = read(MATRIX / "results.json"), read(MATRIX / "schedule.json")
    assert len(records) == len(schedule) == 584
    assert len({row["id"] for row in records}) == 584
    assert len({(row["case"], row["round"], row["runtime"], row["backend"]) for row in records}) == 584
    for row, scheduled in zip(records, schedule, strict=True):
        assert all(row[key] == scheduled[key] for key in ("case", "round", "runtime", "backend"))
        folder, case = MATRIX / row["id"], cases[row["case"]]
        argv, raw = read(folder / "command.json")["argv"], read(folder / "raw.json")
        probe = "HitProbe" if case["kind"] == "read" else "MemoryCacheProbe"
        trace = MATRIX / (case["id"] + ".trace") if case["kind"] == "trace" else None
        expected = [str(ROOT / f"artifacts/runtime{row['runtime']}/dotnet"), "exec", "--fx-version", paired.probe.RUNTIMES[row["runtime"]],
                    str(MATRIX / f"frozen/net{row['runtime']}/{probe}/LoadingCache.{probe}.dll"), "--backend", row["backend"],
                    "--warmups", "3", "--runs", "5", "--output", str(folder / "raw.json")]
        expected += ["--duration-ms", "250"] if case["kind"] == "read" else ["--scenario", case["kind"]]
        if case["kind"] == "replacement":
            expected += ["--minimum-warmup-ms", "1000"]
        for name, value in case["config"].items():
            expected += ["--" + name.replace("_", "-"), str(value)]
        if trace:
            expected += ["--trace-file", str(trace)]
        assert argv == expected
        if case["kind"] != "read":
            assert raw["metadata"]["processSha256"] == runtime[relative(Path(argv[0]))]
        check_options(raw, case, argv, row["backend"])
        paired.probe.validate(raw, case, row["runtime"], row["backend"], trace)
    output.mkdir(parents=True)
    command = [sys.executable, str(ANALYZER), str(MATRIX), "--output", str(output)]
    with (output / "analyzer.log").open("w") as log:
        completed = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=False)
    save(output / "analyzer-command.json", {"argv": command, "exitCode": completed.returncode, "analyzerSha256": sha(ANALYZER)})
    assert completed.returncode == 0
    rows = read(output / "comparison.json")
    main_rows = [r for r in rows if r["kind"] == "replacement" or (r["kind"] == "read" and r["key_mode"] == "preboxed")]
    assert len(main_rows) == 100 and all(len(r["roundCostRatios"]) == 2 for r in main_rows)
    directions = {d: sum(direction(r["roundCostRatios"]) == d for r in main_rows) for d in ("lower", "higher", "mixed")}
    grouped_directions = {
        column: {
            value: {d: sum(r[column] == value and direction(r["roundCostRatios"]) == d for r in main_rows)
                    for d in ("lower", "higher", "mixed")}
            for value in sorted({r[column] for r in main_rows})
        }
        for column in ("kind", "statistics")
    }
    gate = directions["lower"] == 100
    with (output / "comparison.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=["case", "runtime", "kind", "statistics", "workers", "round0CostRatio", "round1CostRatio", "direction"], lineterminator="\n")
        writer.writeheader()
        for row in main_rows:
            writer.writerow({**{key: row[key] for key in ("case", "runtime", "kind", "statistics", "workers")},
                             "round0CostRatio": row["roundCostRatios"][0], "round1CostRatio": row["roundCostRatios"][1], "direction": direction(row["roundCostRatios"])})
    summary = {"mainGatePassed": gate, "criterion": "All 100 preboxed-read/replacement runtime/configurations cost less than MemoryCache in both rounds.",
               "mainDirections": directions, "groupedDirections": grouped_directions,
               "matrix": read(output / "verified-summary.json"), "coreSha256": core,
               "validation": validation, "soak": soak, "paired": paired_reports,
               "pairedNegatives": [{"run": name, **row} for name, report in paired_reports.items() for row in report["summary"] if any(r >= 1 for r in row["ratios"])],
               "helperHashes": {relative(p): sha(p) for p in HELPERS + [Path(__file__)]},
               "limits": ["Native-key reads, trace hit ratios/occupancy and fan-in backend suppression are separate outcomes.",
                          "Paired controls use unchanged historical drivers; the fresh matrix has its own exact source/binary binding.",
                          "No causal or significance claim follows from two-round signs; all negative rounds are retained.",
                          "Soak and correctness are bounded evidence, not all-platform release certification."]}
    save(output / "evidence.json", summary)
    link = lambda path: os.path.relpath(path, output)
    status = "PASSED the measured 100-configuration gate" if gate else "DID NOT PASS the 100-configuration gate"
    paired_lines = "\n".join(f"- `{name}`: {report['processes']} processes / {report['measuredSamples']} samples; {report['counts']}." for name, report in paired_reports.items())
    group_lines = "\n".join(
        f"| {column}: {value} | {totals['lower']} | {totals['higher']} | {totals['mixed']} |"
        for column, groups in grouped_directions.items() for value, totals in groups.items()
    )
    (output / "README.md").write_text(f"""# Parallel resident replacement evidence

The fresh matched statistics OFF/OFF and ON/ON comparison **{status}**. Default statistics remain OFF.
Of 100 preboxed-read/replacement runtime/configurations, {directions['lower']} were lower in both rounds,
{directions['higher']} higher in both, and {directions['mixed']} mixed or tied. This records a measured gate, not an adoption or release decision.

| Group | Lower cost in both rounds | Higher cost in both | Mixed / tied |
| --- | ---: | ---: | ---: |
{group_lines}

The kind rows partition the same 100 configurations as the statistics rows; do not add them together.

[Full comparison](comparison.json), [main-case round ratios](comparison.csv), and [verified evidence](evidence.json)
retain all outcomes. Native-key reads, trace hit rate/end occupancy and fan-in backend calls are reported separately
in the analyzer's category CSVs; they are not substituted for the cost gate. Medians are not tail percentiles.

The [fresh matrix]({link(MATRIX)}) contains 584 processes and 2,920 measured samples with exact commands/raw hashes.
The original-driver paired results remain separate:
{paired_lines}
Every non-improving paired round is listed in `evidence.json`; confirmations do not overwrite the original controls.

[Final validation]({link(FINAL)}) passed {validation['totalTests']} tests and two consumers;
[soak]({link(SOAK)}) passed twelve five-minute cases, six per actual runtime.
The final source snapshot includes the updated lifecycle fixture. The initial validation is retained as separate evidence.
Validation binary bindings use surviving outputs checked after validation, not per-test-process emitted hashes.
Core SHA256: `{core}`. Runtime/source/harness identities and exact argv are preserved in the linked manifests.

Reproduce offline export with `uv run --offline --no-project python {relative(Path(__file__))} --execute --archive`.
The script refuses existing output directories. It runs only verification and the existing analyzer, never a cache workload.
When present, `evidence.tar.gz` preserves source/raw/log/TRX evidence without DLL/PDB/build trees;
`evidence-members.json` lists every member and SHA256, and `archive.json` records archive identity/read-back verification.
Extract the archive at the repository root to restore artifact-relative links. Binaries are deliberately excluded;
live binary re-verification requires the original local frozen/build outputs.
""")
    if args.archive:
        archive(output)
    print(json.dumps({"output": str(output), "mainGatePassed": gate, "mainDirections": directions, "archive": args.archive}))


if __name__ == "__main__":
    main()
