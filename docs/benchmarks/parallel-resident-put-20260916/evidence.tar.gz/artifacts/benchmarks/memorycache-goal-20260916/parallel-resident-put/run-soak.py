"""Run five-minute lifecycle and feature-combination cases on the parallel resident writer, serially by runtime."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
OUT = ROOT / "artifacts/validation/memorycache-goal-20260916/parallel-resident-put-soak"
spec = importlib.util.spec_from_file_location("validation", ROOT / "tools/validate.py")
validation = importlib.util.module_from_spec(spec)
spec.loader.exec_module(validation)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


OUT.mkdir(parents=True, exist_ok=False)
source = validation.source_manifest(ROOT)
save(OUT / "source-manifest.json", source)
for name in source:
    path = OUT / "executed-source" / name
    path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ROOT / name, path)
shutil.copy2(__file__, OUT / "run-soak.py")
results = []
for version, patch in ((8, "8.0.31"), (10, "10.0.12")):
    folder = OUT / f"net{version}"
    folder.mkdir()
    env = {key: value for key, value in os.environ.items() if not key.startswith(("DOTNET_", "COMPlus_", "CORECLR_", "COR_"))}
    changes = {"LOADINGCACHE_SOAK_SECONDS": "300", "LOADINGCACHE_FEATURE_SOAK_SECONDS": "300", "LOADINGCACHE_SOAK_OUTPUT": str(folder / "soak")}
    env.update(changes)
    project = ROOT / "tests/LoadingCache.StressTests"
    binaries = {str(path.relative_to(ROOT)): sha(path) for path in (project / f"bin/Release/net{version}.0").iterdir() if path.is_file()}
    save(folder / "binary-manifest.json", binaries)
    command = ["dotnet", "test", str(project / "LoadingCache.StressTests.csproj"), "-c", "Release", "--no-build", "--no-restore", "-f", f"net{version}.0",
               "--filter", "FullyQualifiedName~LongRunningStabilityTests|FullyQualifiedName~FeatureCombinationStabilityTests",
               "--logger", "trx;LogFileName=soak.trx", "--results-directory", str(folder), "--", f"RunConfiguration.DotNetHostPath={ROOT}/artifacts/runtime{version}/dotnet"]
    save(folder / "command.json", {"argv": command, "cwd": str(ROOT), "environmentOverrides": changes, "environmentPolicy": "No JIT/GC/profiler overrides; process-only soak settings"})
    print(f"net{version}: starting six 300-second cases", flush=True)
    with (folder / "process.log").open("w") as log:
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=1500, check=False)
    assert result.returncode == 0
    counts = validation.inspect_test_results(folder / "soak.trx")
    assert counts["passed"] == 6
    logs = sorted((folder / "soak").glob("*.jsonl"))
    assert len(logs) == 6
    for path in logs:
        events = [json.loads(line) for line in path.read_text().splitlines()]
        assert events[0]["Event"] == "start" and events[0]["Runtime"] == f".NET {patch}" and events[0]["seconds"] == 300
        assert events[-1]["Event"] == "passed" and all(event["Event"] != "failed" for event in events)
    assert all(sha(ROOT / name) == digest for name, digest in binaries.items())
    assert validation.source_manifest(ROOT) == source
    results.append({"runtime": patch, "exitCode": result.returncode, "testCounts": counts, "jsonlHashes": {path.name: sha(path) for path in logs}})
    save(OUT / "results.json", results)
    print(f"net{version}: passed all six cases", flush=True)
save(OUT / "completed.json", {"tests": 12, "secondsPerCase": 300, "runtimesSerial": True, "casesParallelWithinRuntime": True, "allPassed": True})
