# Remaining fixed-expiration read cost

Read-only review at HEAD `1032db6`, 2026-09-16. No build, test, formatter,
profiler, or workload was run. Only this report was written. The new writer's
full MemoryCache matrix was still running; no partial result replaces the retained
baseline below. Source hashes: CacheEngine.cs
`7ac116408b3a2233c21ba3112c5a63a33d7f00754346e3a01d9ad7d3734bdd18`,
EngineExpiration.cs
`4baafb2fe1dfbb217101efcee42d994292cdc6c6b114f816868262aab71a5143`.

**Next priority: isolate the fixed-access coordinated reader's foreground cost
from policy transport/replay per completed read. There is no evidence-backed new
expiry patch ready to apply.** In particular, entry-monitor removal, specialized
IsExpired inlining/outlining, and another packed-access layout are not justified
by the existing negative controls.

## What the retained comparison establishes

The authoritative input is
`docs/benchmarks/memorycache-maintenance-20260915/comparison.json`.
These are pooled wall ns/op for one reader, 1,024 preboxed resident keys, cycle
access. They are not request latency or isolated component costs.

| Runtime / stats | None LC / MC | TTL LC / MC | TTI LC / MC | Both LC / MC |
| --- | ---: | ---: | ---: | ---: |
| 8 OFF | 32.65 / 23.53 | 53.41 / 23.69 | 63.30 / 23.80 | 63.33 / 23.57 |
| 10 OFF | 26.25 / 22.63 | 44.64 / 22.72 | 60.22 / 23.18 | 62.01 / 23.38 |
| 8 ON | 44.87 / 31.72 | 58.79 / 25.52 | 74.66 / 25.63 | 74.28 / 25.61 |
| 10 ON | 35.62 / 23.56 | 49.86 / 23.73 | 69.46 / 24.43 | 70.88 / 24.13 |

Source row starts: OFF none `:251/:282`, TTL `:685/:716`, TTI `:809/:840`,
both `:933/:964`; ON none `:2159/:2190`, TTL `:2593/:2624`,
TTI `:2717/:2748`, both `:2841/:2872`.
All twelve one-reader expiry cases lose: pooled TTL ratios 1.96–2.30,
TTI/both 2.60–2.94. The corresponding ten-reader expiry rows are all below MC.
This prioritizes one-reader cost; it does not establish lock contention.
TTI adds approximately 9.9–19.6 ns/op over TTL, while adding TTL to TTI changes
these pooled medians by only -0.4 to +1.8 ns/op. Those cross-case differences
motivate investigation; they cannot be assigned wholesale to a monitor or conversion.

## Ranked investigation candidates

1. **TTI/both acceptance and rich locked-reader work, with transport controlled.**
   Current chain: `CacheEngine.TryGet:427` → `TryReadReady:2452` →
   `TryReadReadyLocked:2531` → entry monitor `:2569` → timestamp `:2574` →
   `EngineExpiration.IsExpired:245` → signed touch `:792` → value/task/refresh
   metadata → unlock → `RecordHit` / `OnAccess` (`CacheEngine:2685–2688`).
   The fixed-write snapshot route at `:2485–2519` avoids both locks on a fresh hit;
   ordinary TTI does not take E. Do not call this an engine-gate contention problem.

   Evidence: all four access-only configurations improved in both rounds in each
   of five packed-access trials (`docs/benchmarks/packed-access-20260916/README.md:35`).
   That is repeated evidence that changing the acceptance/read path can matter,
   not proof of the monitor's exclusive cost. The final packed candidate still
   loses to MC by 1.92–2.40 in access rows (`:45–56`), and controls regress.

   **Prediction to test next:** with the current binary, equal completed-read
   windows for cases 011/013/015 and 043/045/047 should retain a material extra
   foreground CPU/read in the coordinated acceptance/reader region after clock
   calls and accepted/full transport mix are accounted for. Capture those counts
   in the same window; keep ThreadPool CPU/read separate. If the excess instead
   follows accepted events/read and replay CPU/read, prioritize transport rather
   than rewriting expiry. This is the next diagnostic gate, not a proposed code edit.

2. **TTL's clock/elapsed/publication chain is a real floor, but no redundant
   operation has been demonstrated.** `CacheEngine:2487–2505` captures publication
   and live duration, reads value/timestamp, samples the clock once, converts
   elapsed time (`EngineExpiration:803`), then revalidates publication/retirement.
   The existing matched NET10 ON TTL profile observed 3,550 ms of reader samples
   in `mach_absolute_time`, versus 7,037 ms for MC, plus 1,546 ms exclusive in
   `OfferAvailable` (`docs/benchmarks/memorycache-read-cpu-20260915/README.md:43–53`).
   Different completed-operation counts prevent converting these to per-hit
   costs or claiming the clock explains LC's deficit.

   **Prediction to test:** a same-work clock/native attribution should show one
   timestamp call/read and separately bound clock CPU/read versus conversion,
   fences and transport. Discovery of an extra call or actual spill cost would
   be a new causal reason; current source/history supplies neither. Do not repeat
   clock dispatch merging, scalar freshness guards, or delayed value loads merely
   because TTL still loses.

3. **Signed touch branch → conditional selection is the only small outstanding
   source hypothesis found, but low priority and not a demonstrated bottleneck.**
   It was already proposed at
   `docs/benchmarks/ttl-value-lifetime-20260915/expiry-source-review.md:57–65`;
   current `EngineExpiration:792–800` still has the same signed-delta branch.
   Historical native evidence preserves its subtract/sign-check/conditional-store
   (`docs/benchmarks/memorycache-expiry-inline-20260915/native-review.md:32`).
   No executed conditional-selection candidate was located in the scoped reports.

   **Native-only prediction:** a local old timestamp plus conditional expression
   must become selection without a new helper, larger frame, or extra hot-path
   reload; otherwise stop. Preserve `unchecked(now - old) >= 0`, including signed
   wrap and backward/subtick custom clocks. An unconditional store can itself cost
   more; the current branch is normally predictable. This cannot plausibly be
   presented as closing the 2–3x gap, and does not justify skipping priority 1.

## Rejected work that must not be rediscovered

- `tti-access-specialization-20260916/README.md:11–44`: IsExpired call removal and
  outlined caller-frame restoration already occurred. Normal controls still had
  negative/mixed rows; a settled 1,000 ms targeted check reversed direction.
- `memorycache-expiry-inline-20260915/README.md:15–38`: aggressive IsExpired
  inlining improved some OFF cases but worsened ON TTI/both and TTL controls.
- `tti-presence-20260915/README.md:3–9,43–53`: second duration-acquire removal
  worked natively; 5 lower / 1 higher / 6 mixed, rejected.
- `ttl-clock-dispatch-20260915/README.md:3–10,41–53`: merged System guard worked,
  yet NET10 TTL OFF/ON both rounds were higher. `memorycache-scalar-guard-20260915/README.md:3–13`
  likewise distinguishes an isolated predicate win from rejected engine results.
- `ttl-value-lifetime-20260915/README.md:3–8,51–70`: late value loading retained
  ordinary caller frames/callee saves and added a null branch; native rejection.
- `packed-access-20260916/README.md:27–39,71`: five variants all rejected. Shared
  metadata effects mean fallback outlining alone cannot explain every regression.

The CPU profile also documents that a larger read buffer reduced maintenance
requests while increasing accepted events/read and slowing controls
(`memorycache-read-cpu-20260915/README.md:94–100`). Keep policy work volume visible
in any expiry experiment; neither fewer submissions nor smaller native code is
an acceptance criterion. Current `OnAccess:156–193` → `StripedReadBuffer.TryOffer:129`
is common to TTL/TTI and occurs after the entry lock. The new resident writer's
eligibility explicitly excludes all read-time features (`CacheEngine:219–244`),
and the read bodies/EngineExpiration have no diff since `a319bab`; its write gain
is not evidence that these expiry costs have improved.
