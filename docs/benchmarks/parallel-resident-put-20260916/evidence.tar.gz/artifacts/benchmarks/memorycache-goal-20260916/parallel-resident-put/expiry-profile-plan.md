# Fixed-work expiry attribution preparation

Source-only preparation for ROOT; no build/test/formatter/profile/workload was
executed here. The fresh matrix at `matrix-analysis-01/comparison.json` remains
the normal performance evidence. These proposed profiler captures are diagnostic
only and must wait until ROOT's full matrix and twelve-case soak release its CPU lane.

## Smallest next run

Run **only three captures** initially: actual NET10.0.12, stats OFF, none / TTL /
TTI. All use the exact `1032db6` frozen core SHA256
`d6b99727eb98e3c8a8396e00723ca6473f6e682074a0b9d9bf0070d622fba275`, one reader,
1,024 resident preboxed keys, cycle access, default JIT/tiering/PGO. Statistics ON,
combined expiry and reverse/repeat captures are deferred pending these results.

The new `prepare-expiry-profile.py` is IO-only. It pins and adapts the existing
HitProbe, `capture-read-profile.py`, and `analyze-read-profile.py`; it launches no
child process. It emits the adapted sources, patches, commands and manifests into
a fresh artifact directory. Its `--stage-built` mode checks/copies an already-built
driver and insists its LoadingCache.dll is the pinned core. No production or
tracked tool/test/document source is edited or rebuilt.

The artifact driver changes only measurement machinery:

- Exactly `2^24 = 16,777,216` reads per sample, replacing the time-based stop test
  once per existing 1,024-read chunk. The cache lookup/checksum loop is otherwise
  unchanged. It explicitly reports `workloadMode=fixed-reads-duration-option-unused`;
  the inherited duration argument remains schema context and does not stop samples.
- Five fixed-work warmups and 59 measured samples keep the target alive across
  the existing collector attach protocol. This is not 64 separate profile captures.
- Each sample records UTC and monotonic operation boundaries, diagnostic snapshot
  envelopes, and the process-CPU envelope. Timestamp collection is outside the
  per-lookup loop; cleanup remains separate.
- Reuse the existing 5-second attach delay, 12-second EventPipe method-map capture
  and 10-second xctrace Time Profiler. EventPipe samples/contention are **never CPU**.
- Offline analysis selects the **first four complete measured samples** enclosed
  in both the trace and observed Running envelope. Each case therefore has exactly
  `2^26 = 67,108,864` completed reads. No partial windows, extrapolation, sample
  interpolation or result-based sample choice. Fewer than four is a failed
  capture; retain it and revise the common protocol before rerunning any case.

## ROOT commands

Run from `/Users/awe123343/Dev/LoadingCache.NET`, only after the CPU lane is free.
The output path must not exist. The commands are prepared, **not execution evidence**.

```sh
uv run --offline --no-project python artifacts/benchmarks/memorycache-goal-20260916/parallel-resident-put/prepare-expiry-profile.py \
  --output artifacts/benchmarks/memorycache-goal-20260916/parallel-resident-put/expiry-profile-inputs-01

dotnet build artifacts/benchmarks/memorycache-goal-20260916/parallel-resident-put/expiry-profile-inputs-01/source/tools/LoadingCache.HitProbe/LoadingCache.HitProbe.csproj \
  -c Release -f net10.0 -p:TargetFrameworks=net10.0 \
  -p:FrozenLoadingCache=/Users/awe123343/Dev/LoadingCache.NET/artifacts/benchmarks/memorycache-goal-20260916/parallel-resident-put/after/frozen/net10/HitProbe/LoadingCache.dll

uv run --offline --no-project python artifacts/benchmarks/memorycache-goal-20260916/parallel-resident-put/prepare-expiry-profile.py \
  --output artifacts/benchmarks/memorycache-goal-20260916/parallel-resident-put/expiry-profile-inputs-01 --stage-built
```

Before collectors, one short harness smoke (still ROOT's CPU lane) exercises its
own checksum/miss/stats/bounds checks. Its output is not performance evidence:

```sh
artifacts/runtime10/dotnet exec --fx-version 10.0.12 \
  artifacts/benchmarks/memorycache-goal-20260916/parallel-resident-put/expiry-profile-inputs-01/inputs/frozen/net10/HitProbe/LoadingCache.HitProbe.dll \
  --backend loadingcache --capacity 1024 --residents 1024 --pattern cycle \
  --workers 1 --statistics off --key-mode preboxed --expiration access \
  --warmups 1 --runs 1 --duration-ms 5000 --diagnostics on \
  --output artifacts/benchmarks/memorycache-goal-20260916/parallel-resident-put/expiry-profile-inputs-01/smoke.json
```

Check two samples each report 16,777,216 reads, zero misses, expected checksum,
stats OFF, and ordered UTC/monotonic/snapshot envelopes. Build warnings or manifest
mismatches stop the run; do not weaken analyzers or reuse stale binaries. Then the
generated command manifest runs exactly three captures, each followed by its
offline map and window analysis, serially:

```sh
uv run --offline --no-project python - <<'PY'
import json
import subprocess
from pathlib import Path
base = Path('artifacts/benchmarks/memorycache-goal-20260916/parallel-resident-put/expiry-profile-inputs-01')
jobs = json.loads((base / 'commands.json').read_text())['captures']
assert len(jobs) == 3
for job in jobs:
    for phase in ('capture', 'map', 'windows'):
        print(phase, job[phase], flush=True)
        subprocess.run(job[phase], check=True)
PY
```

Each command also appears as a structured argv array in `commands.json`, so ROOT
can run captures individually with progress between them. A capture records all
child argv/exit status, pinned source/core/harness/runtime and diagnostic-tool
hashes, full raw samples and private collector paths. Capture/export failures
retain their evidence; do not overwrite those directories.

## Metric scope and limits

`profile-off-{none,write,access}/read-profile-analysis/windows.json` records:

| Requested measure | Smallest defensible result |
| --- | --- |
| Completed operations | Exactly 67,108,864 successful reads per selected group; checksum, bounds and zero misses validated by the harness and reused validators. |
| Foreground CPU/read | xctrace **Running sample-weight ns/read**, role `reader`, within those four operation windows. It is a sampling estimate, not a per-thread CPU counter or latency. |
| Clock/native share | Same-window clock exclusive-leaf and inclusive-stack weights/read and fraction of reader weight; full leaf rankings/unknown frames retained. Native clock work is distinguishable where symbols exist. Inlined elapsed arithmetic is not recovered from a containing TryGet frame. |
| Expiry reader region | Same-window `TryReadReadyLocked` / `IsExpired` / `TouchWithoutLock` stack attribution. Missing/inlined frames are unresolved cost, not zero cost; these overlapping groups do not partition CPU. |
| Accepted events | Exact producer-work reservation delta in both stats modes. The sole reader is stopped during snapshots and no other producer/refresh/write workload exists, so later consumer draining does not change the reserved delta. |
| Full events | Direct Full/Failed counter deltas only with stats ON. **Stats OFF returns null for these counters.** `completed - accepted` is nonaccepted, not claimed to be Full; do not enable stats to fill an OFF row. |
| Replay CPU/read | Same-window xctrace Running weight/read in ThreadPool stacks containing `ConsumeAccess`, `RecordAccess`, `FrequencySketch`, `MoveLast` or `DrainAvailable`. It is named-stack sampled attribution and may omit inlined/unwound work. Separate total ThreadPool and native-spin weights remain visible. |
| Replayed event count | Consumed-cursor delta belongs to the wider before/after snapshot envelope. Consumer work can proceed after the CPU cutoff. It is explicitly **not an exact operation-window replay count** and is not used to derive CPU/event. |
| Aggregate process CPU | Existing `TotalProcessorTime` delta retained with its own enclosing UTC timestamps. It includes boundary overhead and has a different envelope; never subtract it from reader/replay sample weights to manufacture residual CPU. |

Only xctrace Running rows are normalized. EventPipe supplies PID/time/native
method ranges for symbolization; do not divide sample-profiler events or contention
wait duration by reads as CPU, and do not subtract its 12-second window from the
10-second xctrace window. Likewise, do not divide full-trace weights by whole-probe
operations. The selected group excludes explicit cleanup, while separate raw
cleanup fields remain available.

Selection uses one observed sampling quantum plus observed UTC/monotonic duration
error plus a declared 1 ms margin. A duration discrepancy above 2 ms aborts the
join. These are consistency/sensitivity checks, **not a proved absolute clock
synchronization bound**. An inner-strip sensitivity drops boundary rows while
retaining the same read denominator; report its changed weight as sensitivity,
not as a second unbiased CPU estimate. Preserve stackless/ambiguous/unresolved
rows, and compare clock share using the same reader-role denominator.

## Decision gate

The initial three captures can answer whether fixed-access excess is visible in
the coordinated foreground reader, native clock calls, or policy work/ThreadPool
weights **for equal completed reads**. They cannot establish exact monitor CPU,
exact per-window dequeues, statistical significance or normal-mode improvement.
Do not compute the cost of a component by subtracting independently run totals.

If TTI's extra reader weight appears in mapped acceptance/expiry methods and is
large relative to boundary/unknown weights while accepted/read does not explain
it, inspect that concrete path/native body next. If accepted/read and replay
weights change together, retain that association and investigate transport before
another expiry rewrite; it still is not proof of causality. If mapping, clock
alignment or variability dominates, stop without an implementation proposal.
Only then decide whether matched ON or combined-expiry profiles resolve a specific
remaining question. No automatic sixteen-capture matrix is prepared.

## Preparation status

The preparer and embedded offline analyzer were read as source. A Python AST-only
check was attempted but did not run: uv first encountered an inaccessible shared
cache, then panicked in macOS system-configuration with a temporary scoped cache.
No profile/build/test workload was started and no global configuration changed.
The temporary cache option was per-command only. Script generation, isolated
driver compilation, smoke, collectors and window analysis are **Not run**; ROOT
must review/build the generated adaptation before trusting any output. Required
existing NET10 host, ReadTrace and MethodMap binary paths were observed present.
