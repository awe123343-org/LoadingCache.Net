"""Preserve final tested sources and surviving build outputs without overstating binding."""
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
OUT = ROOT / "artifacts/validation/memorycache-goal-20260916/parallel-resident-put-final-01"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


result = read(OUT / "results.json")
assert result["source_unchanged"] and not result["unrun_commands"]
assert len(result["commands"]) == 14
assert all(item["exit_code"] == 0 for item in result["commands"])
for name, digest in read(OUT / "source-manifest.json").items():
    source = ROOT / name
    assert sha(source) == digest, name
    target = OUT / "executed-source" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    assert sha(target) == digest, name
core = read(HERE / "frozen.json")["candidateCoreSha256"]
binaries = {}
for version in (8, 10):
    for project in ("LoadingCache.Tests", "LoadingCache.DependencyInjection.Tests", "LoadingCache.StressTests", "LoadingCache.ConsumerSmoke"):
        folder = ROOT / f"tests/{project}/bin/Release/net{version}.0"
        assert sha(folder / "LoadingCache.dll") == core
        for path in folder.iterdir():
            if path.is_file():
                binaries[str(path.relative_to(ROOT))] = sha(path)
save(OUT / "binary-manifest.json", binaries)
runtime = read(HERE / "after/runtime-manifest.json")
assert all(sha(ROOT / name) == digest for name, digest in runtime.items())
save(OUT / "runtime-manifest.json", runtime)
save(OUT / "binding.json", {
    "coreSha256": core,
    "sourceUnchanged": True,
    "commands": 14,
    "tests": sum(item["test_counts"]["passed"] for item in result["commands"] if item["test_counts"]),
    "consumers": sum(item["name"].startswith("consumer-") for item in result["commands"]),
    "binaryBindingLimit": "Surviving outputs inspected after validation with no intervening build; test processes do not emit these hashes.",
    "runtimeBindingLimit": "Exact hosts selected by recorded test argv; native runtime files rehashed after validation.",
})
shutil.copy2(__file__, OUT / "preserve-validation.py")
print(json.dumps(read(OUT / "binding.json"), indent=2))
