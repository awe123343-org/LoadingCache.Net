"""Freeze only the validated coordination candidate with the retained drivers."""

import hashlib
import json
from pathlib import Path
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
BASE = ROOT / "artifacts/benchmarks/memorycache-goal-20260915/retained-maintenance-memorycache"
VALIDATION = ROOT / "artifacts/validation/memorycache-goal-20260916/parallel-resident-put"
OUT = HERE / "after"
ALLOWED = {
    "src/LoadingCache/CacheEngine.cs",
    "src/LoadingCache/CacheBuilder.cs",
    "src/LoadingCache/CacheEngineOptions.cs",
    "src/LoadingCache/LoadingCacheImpl.cs",
    "src/LoadingCache/CacheDictionary.cs",
    "src/LoadingCache/EngineDictionary.cs",
    "src/LoadingCache/EngineDictionaryCompute.cs",
    "src/LoadingCache/EngineMemoryPressure.cs",
    "src/LoadingCache/EngineBulk.cs",
    "src/LoadingCache/EngineRefresh.cs",
    "src/LoadingCache/EngineReferences.cs",
    "src/LoadingCache/EngineState.cs",
    "src/LoadingCache/TestHooks.cs",
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


results = read(VALIDATION / "results.json")
assert results["source_unchanged"] and not results["unrun_commands"]
assert all(command["exit_code"] == 0 for command in results["commands"])
for name, digest in read(VALIDATION / "source-manifest.json").items():
    assert sha(ROOT / name) == digest, name
baseline = read(BASE / "source-manifest.json")
source_paths = {}
for name, digest in baseline.items():
    assert sha(BASE / "executed-source" / name) == digest, name
    source_paths[name] = BASE / "executed-source" / name if name.startswith("tools/") else ROOT / name
current = {name: sha(path) for name, path in source_paths.items()}
changed = sorted(name for name in baseline if baseline[name] != current[name])
assert set(changed) <= ALLOWED and len(changed) >= 3, changed
core = ROOT / "src/LoadingCache/bin/Release/net8.0/LoadingCache.dll"
for runtime in (8, 10):
    assert sha(core) == sha(ROOT / f"tests/LoadingCache.Tests/bin/Release/net{runtime}.0/LoadingCache.dll")
OUT.mkdir(parents=True, exist_ok=False)
for name, source in source_paths.items():
    target = OUT / "executed-source" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
save(OUT / "source-manifest.json", current)
runtime_manifest = read(BASE / "runtime-manifest.json")
for name, digest in runtime_manifest.items():
    assert sha(ROOT / name) == digest, name
save(OUT / "runtime-manifest.json", runtime_manifest)
old_binaries = read(BASE / "binary-manifest.json")
for runtime in (8, 10):
    for probe in ("HitProbe", "MemoryCacheProbe"):
        folder = Path(f"frozen/net{runtime}/{probe}")
        for path in (BASE / folder).rglob("*"):
            if path.is_file():
                assert sha(path) == old_binaries[str(path.relative_to(BASE))]
        shutil.copytree(BASE / folder, OUT / folder)
        for name in ("LoadingCache.dll", "LoadingCache.pdb", "LoadingCache.xml"):
            shutil.copy2(core.parent / name, OUT / folder / name)
        assert sha(OUT / folder / f"LoadingCache.{probe}.dll") == sha(BASE / folder / f"LoadingCache.{probe}.dll")
save(OUT / "binary-manifest.json", {str(path.relative_to(OUT)): sha(path) for path in sorted((OUT / "frozen").rglob("*")) if path.is_file()})
import difflib
patch = "".join("".join(difflib.unified_diff(
    (BASE / "executed-source" / name).read_text().splitlines(keepends=True),
    (ROOT / name).read_text().splitlines(keepends=True),
    fromfile="before/" + name, tofile="after/" + name,
)) for name in changed)
(HERE / "candidate.patch").write_text(patch)
save(HERE / "frozen.json", {"sourceFiles": len(current), "changedFiles": changed, "candidateCoreSha256": sha(core), "validation": str(VALIDATION.relative_to(ROOT)), "validationResultsSha256": sha(VALIDATION / "results.json"), "probeUnchanged": True, "driverSource": "Original frozen drivers; no workload change."})
print("Frozen validated coordination candidate with unchanged paired drivers.")
