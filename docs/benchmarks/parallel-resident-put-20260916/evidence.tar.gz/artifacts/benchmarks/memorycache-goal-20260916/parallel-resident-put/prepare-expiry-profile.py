#!/usr/bin/env python3
"""Prepare artifact-only fixed-read diagnostics; never launch build/profile/workload.

ROOT runs emitted commands after its CPU lane is free. --stage-built only checks
and copies an already-built driver. Production and tracked harness files are read-only.
"""

import argparse
import difflib
import hashlib
import json
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[3]
SNAPSHOT = HERE / "after"
CORE = "d6b99727eb98e3c8a8396e00723ca6473f6e682074a0b9d9bf0070d622fba275"
OPS = 16_777_216
PINNED = {
    "tools/LoadingCache.HitProbe/Program.cs": "f15c86c94a4fcb3eb8222547aa3c69d2f488b176b8f0eddca5141a23befb2f58",
    "tools/LoadingCache.HitProbe/LoadingCache.HitProbe.csproj": "fdaac5f5df8a5fc259426bd58eb6c355ae848bf79ef2de17844e8aa50bab592a",
    "artifacts/benchmarks/memorycache-goal-20260915/capture-read-profile.py": "1e26ad58087002cc7a794831c214b76e65329fd669bd605cb47a5ac72537b321",
    "artifacts/benchmarks/memorycache-goal-20260915/analyze-read-profile.py": "914e63ba26ee669b99052d4d2ea7c0dfd4bfbbadb51aa16a8134d711c9257e11",
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def replace_once(code, old, new):
    if code.count(old) != 1:
        raise RuntimeError(f"Expected exactly one source anchor: {old!r}")
    return code.replace(old, new)


def verify(base, manifest):
    for name, expected in manifest.items():
        path = base / name
        if not path.resolve().is_relative_to(base.resolve()) or sha(path) != expected:
            raise RuntimeError(f"Input identity mismatch: {path}")


def write_adaptation(output, name, original, changed):
    (output / name).write_text(changed)
    (output / (name + ".patch")).write_text("".join(difflib.unified_diff(
        original.splitlines(keepends=True), changed.splitlines(keepends=True),
        fromfile="retained/" + name, tofile="artifact/" + name)))


WINDOW_ANALYZER = r'''"""Offline complete-window analysis; xctrace estimates, never EventPipe CPU."""
import datetime
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
out = root / "read-profile-analysis"
read = lambda path: json.loads(path.read_text())
utc = lambda value: datetime.datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
raw, rows, summary = (read(path) for path in (root / "raw.json", out / "rows.json", out / "summary.json"))
assert raw["workloadMode"] == "fixed-reads-duration-option-unused"
assert raw["fixedReadsPerWorker"] == 16777216 and raw["workers"] == 1
assert raw["runtime"] == ".NET 10.0.12" and raw["backend"] == "loadingcache"
assert raw["cacheAssemblySha256"].lower() == "d6b99727eb98e3c8a8396e00723ca6473f6e682074a0b9d9bf0070d622fba275"
spec = importlib.util.spec_from_file_location("expiry_map", Path(__file__).with_name("analyze-read-profile.py"))
mapper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mapper)
frequency = raw["stopwatchFrequency"]
quantum = max(row["weightNs"] for row in rows) / 1e9
drift = max(abs(utc(s["utcEnded"]) - utc(s["utcStarted"]) -
                (s["endedTimestamp"] - s["startedTimestamp"]) / frequency) for s in raw["samples"])
assert drift < 0.002, ("UTC/monotonic duration mismatch exceeds 2 ms", drift)
# 1 ms is a declared sensitivity margin, not a certified clock-synchronization bound.
guard = quantum + drift + 0.001
lo = max(summary["captureStartUnix"], min(row["unix"] for row in rows)) + guard
hi = min(summary["captureStartUnix"] + summary["captureDurationSeconds"], max(row["unix"] for row in rows)) - guard
eligible = [s for s in raw["samples"] if not s["warmup"] and utc(s["utcStarted"]) >= lo and utc(s["utcEnded"]) <= hi]
assert len(eligible) >= 4, "Need four fully enclosed measured windows; do not use partial windows or fewer operations."
selected = eligible[:4]  # Prespecified first four, never choose by timing/result.
per_sample, chosen, interiors = [], [], []
for sample in selected:
    n = sample["operations"]
    assert n == 16777216 and sample["workersOperations"] == [n]
    assert sample["misses"] == 0 and sample["boundsPassed"]
    a, b = utc(sample["utcStarted"]), utc(sample["utcEnded"])
    before, after = sample["diagnostics"]["before"], sample["diagnostics"]["after"]
    accepted = after["reserved"] - before["reserved"]
    assert 0 <= accepted <= n and sample["diagnostics"]["unrecordedReads"] == n - accepted
    selected_rows = [row for row in rows if a <= row["unix"] < b]
    assert selected_rows
    inner = [row for row in selected_rows if min(row["unix"] - a, b - row["unix"]) > guard]
    chosen.extend(selected_rows)
    interiors.extend(inner)
    per_sample.append({
        "sampleIndex": sample["sampleIndex"], "operations": n, "operationUtc": [sample["utcStarted"], sample["utcEnded"]],
        "acceptedOffers": accepted, "nonacceptedOffers": n - accepted,
        "fullOffers": None if not raw["statistics"] else after["droppedFull"] - before["droppedFull"],
        "failedOffers": None if not raw["statistics"] else after["droppedFailed"] - before["droppedFailed"],
        "sampledRunning": mapper.summarize(selected_rows),
        "processCpuTicksSeparateBoundaryScope": sample["processCpuTicks"],
        "processCpuEnvelopeUtc": [sample["cpuEnvelopeStartedUtc"], sample["cpuEnvelopeEndedUtc"]],
        "cursorEnvelopeUtc": [sample["diagnosticBeforeStartedUtc"], sample["diagnosticAfterEndedUtc"]],
        "cursorEnvelopeConsumedDeltaNotExactOperationWindow": after["consumed"] - before["consumed"],
        "diagnosticBeforeUtc": [sample["diagnosticBeforeStartedUtc"], sample["diagnosticBeforeEndedUtc"]],
        "diagnosticAfterUtc": [sample["diagnosticAfterStartedUtc"], sample["diagnosticAfterEndedUtc"]],
    })
n = sum(s["operations"] for s in selected)
assert n == 67108864
def metrics(items):
    detail = mapper.summarize(items)
    return {"completedReads": n, "sampledRunningNsPerRead": sum(r["weightNs"] for r in items) / n,
            "byRoleSampledRunningNsPerRead": {role: value["cpuSampleWeightMs"] * 1e6 / n for role, value in detail["roles"].items()},
            "byRoleFocus": {role: {name: {
                "inclusiveStackSampledNsPerRead": values["inclusiveStackWeightMs"] * 1e6 / n,
                "exclusiveLeafSampledNsPerRead": values["exclusiveLeafWeightMs"] * 1e6 / n,
                "inclusiveFractionOfRole": values["inclusiveStackWeightMs"] / value["cpuSampleWeightMs"] if value["cpuSampleWeightMs"] else None,
            } for name, values in value["focus"].items()} for role, value in detail["roles"].items()},
            "detail": detail}
result = {"selectedSampleIndices": [s["sampleIndex"] for s in selected], "completedReads": n,
          "config": summary["config"], "coreSha256": raw["cacheAssemblySha256"],
          "guardSeconds": guard, "maximumUtcMonotonicDurationErrorSeconds": drift,
          "operationWindows": metrics(chosen), "innerBoundarySensitivitySameDenominator": metrics(interiors),
          "perSample": per_sample,
          "limits": ["Only xctrace Running state weights estimate CPU; EventPipe supplies managed method ranges, not CPU.",
                     "Clock/expiry/replay focus groups are overlapping stack attribution; inlined work is not separately resolved.",
                     "Accepted and ON drop counters bind the completed producer work; OFF nonaccepted is not labeled Full.",
                     "Consumed cursor and process CPU counters have separately reported envelopes; never subtract them from sampled operation-window CPU.",
                     "Inner strips remove sampled weight but retain the same completed-read denominator as sensitivity, not an alternative unbiased CPU estimate."]}
result["inputSha256"] = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in
                        (root / "raw.json", out / "rows.json", out / "summary.json", Path(__file__))}
with (out / "windows.json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps({"output": str(out / "windows.json"), "completedReads": n, "selected": result["selectedSampleIndices"]}))
'''


def prepare(output):
    verify(REPO, PINNED)
    source = read(SNAPSHOT / "source-manifest.json")
    binary = read(SNAPSHOT / "binary-manifest.json")
    verify(SNAPSHOT / "executed-source", source)
    verify(SNAPSHOT, binary)
    core = SNAPSHOT / "frozen/net10/HitProbe/LoadingCache.dll"
    if sha(core) != CORE:
        raise RuntimeError("Expected the exact 1032db6 candidate core")
    output.mkdir(parents=True, exist_ok=False)
    prepared_source = output / "source"
    shutil.copytree(SNAPSHOT / "executed-source", prepared_source)
    original = (REPO / "tools/LoadingCache.HitProbe/Program.cs").read_text()
    code = original
    edits = [
        ("    private const int LookupChunkSize = 1_024;", "    private const int LookupChunkSize = 1_024;\n    private const long FixedReadsPerWorker = 16_777_216;"),
        ("            SchemaVersion: 2,", "            SchemaVersion: 2,\n            WorkloadMode: \"fixed-reads-duration-option-unused\",\n            FixedReadsPerWorker: FixedReadsPerWorker,"),
        ("        int SchemaVersion,", "        int SchemaVersion,\n        string WorkloadMode,\n        long FixedReadsPerWorker,"),
        ("        private readonly long _durationTicks;\n", ""),
        ("        private long _deadline;\n", ""),
        ("            _durationTicks = checked(options.DurationMilliseconds * Stopwatch.Frequency / 1_000);\n", ""),
        ("            Volatile.Write(ref _deadline, checked(wallStarted + _durationTicks));\n", ""),
        ("                    long deadline = Volatile.Read(ref _deadline);\n", ""),
        ("                        if (Stopwatch.GetTimestamp() >= deadline)", "                        if (operations >= FixedReadsPerWorker)"),
        ("            ProbeDiagnosticSnapshot? diagnosticBefore = diagnostics?.Capture();", "            DateTime diagnosticBeforeStartedUtc = DateTime.UtcNow;\n            ProbeDiagnosticSnapshot? diagnosticBefore = diagnostics?.Capture();\n            DateTime diagnosticBeforeEndedUtc = DateTime.UtcNow;"),
        ("            long? cpuStarted = process?.TotalProcessorTime.Ticks;", "            DateTime cpuEnvelopeStartedUtc = DateTime.UtcNow;\n            long? cpuStarted = process?.TotalProcessorTime.Ticks;\n            DateTime utcStarted = DateTime.UtcNow;"),
        ("            long wallFinished = Stopwatch.GetTimestamp();", "            long wallFinished = Stopwatch.GetTimestamp();\n            DateTime utcEnded = DateTime.UtcNow;"),
        ("            long? processCpuTicks = process?.TotalProcessorTime.Ticks - cpuStarted;", "            long? processCpuTicks = process?.TotalProcessorTime.Ticks - cpuStarted;\n            DateTime cpuEnvelopeEndedUtc = DateTime.UtcNow;"),
        ("            ProbeDiagnosticSnapshot? diagnosticAfter = diagnostics?.Capture();", "            DateTime diagnosticAfterStartedUtc = DateTime.UtcNow;\n            ProbeDiagnosticSnapshot? diagnosticAfter = diagnostics?.Capture();\n            DateTime diagnosticAfterEndedUtc = DateTime.UtcNow;"),
        ("                WallSeconds: wallSeconds,", "                UtcStarted: utcStarted,\n                UtcEnded: utcEnded,\n                StartedTimestamp: wallStarted,\n                EndedTimestamp: wallFinished,\n                DiagnosticBeforeStartedUtc: diagnosticBeforeStartedUtc,\n                DiagnosticBeforeEndedUtc: diagnosticBeforeEndedUtc,\n                DiagnosticAfterStartedUtc: diagnosticAfterStartedUtc,\n                DiagnosticAfterEndedUtc: diagnosticAfterEndedUtc,\n                CpuEnvelopeStartedUtc: cpuEnvelopeStartedUtc,\n                CpuEnvelopeEndedUtc: cpuEnvelopeEndedUtc,\n                WallSeconds: wallSeconds,"),
        ("        double WallSeconds,", "        DateTime UtcStarted,\n        DateTime UtcEnded,\n        long StartedTimestamp,\n        long EndedTimestamp,\n        DateTime DiagnosticBeforeStartedUtc,\n        DateTime DiagnosticBeforeEndedUtc,\n        DateTime DiagnosticAfterStartedUtc,\n        DateTime DiagnosticAfterEndedUtc,\n        DateTime CpuEnvelopeStartedUtc,\n        DateTime CpuEnvelopeEndedUtc,\n        double WallSeconds,"),
    ]
    for old, new in edits:
        code = replace_once(code, old, new)
    program = prepared_source / "tools/LoadingCache.HitProbe/Program.cs"
    program.write_text(code)
    write_adaptation(output, "Program.cs", original, code)
    project = program.with_name("LoadingCache.HitProbe.csproj")
    project.write_text(replace_once(project.read_text(),
        '<ProjectReference Include="../../src/LoadingCache/LoadingCache.csproj" />',
        '<Reference Include="LoadingCache"><HintPath>$(FrozenLoadingCache)</HintPath><Private>true</Private></Reference>'))
    source["tools/LoadingCache.HitProbe/Program.cs"] = sha(program)
    source["tools/LoadingCache.HitProbe/LoadingCache.HitProbe.csproj"] = sha(project)
    save(output / "source-manifest.json", source)
    capture_original = (REPO / "artifacts/benchmarks/memorycache-goal-20260915/capture-read-profile.py").read_text()
    capture = capture_original
    for old, new in [
        ("REPO = ROOT.parents[2]", f"REPO = Path({str(REPO)!r})"),
        ('"--warmups", "3", "--runs", "5", "--duration-ms", "5000"', '"--warmups", "5", "--runs", "59", "--duration-ms", "5000"'),
        ('"probeProtocol": {"warmups": 3, "runs": 5, "durationMilliseconds": 5000, "nominalSampleSeconds": 40}', '"probeProtocol": {"warmups": 5, "runs": 59, "durationMilliseconds": 5000, "fixedReadsPerWorker": 16777216}'),
        ('"sampleAlignment": "HitProbe has no sample UTC timestamps; no sample-to-trace alignment is asserted"', '"sampleAlignment": "Artifact driver records sample UTC/monotonic bounds; windows.py selects complete windows"'),
        ("def finish(child, record, timeout=60):", "def finish(child, record, timeout=180):"),
        ("output.mkdir(parents=True, exist_ok=False)", "output.mkdir(parents=True, exist_ok=False)\nshutil.copy2(Path(__file__), output / 'capture-executed.py')"),
        ('    raw = json.loads((output / "raw.json").read_text())', '    raw = json.loads((output / "raw.json").read_text())\n    assert args.backend == "loadingcache"\n    assert raw["workloadMode"] == "fixed-reads-duration-option-unused" and raw["fixedReadsPerWorker"] == 16777216\n    assert all(s["operations"] == 16777216 and s["workersOperations"] == [16777216] for s in raw["samples"])'),
    ]:
        capture = replace_once(capture, old, new)
    write_adaptation(output, "capture-read-profile.py", capture_original, capture)
    original_analysis = (REPO / "artifacts/benchmarks/memorycache-goal-20260915/analyze-read-profile.py").read_text()
    analysis = original_analysis
    for old, new in [
        ("REPO = Path(__file__).resolve().parents[3]", f"REPO = Path({str(REPO)!r})"),
        ('{"warmups": 3, "runs": 5, "durationMilliseconds": 5000, "nominalSampleSeconds": 40}', '{"warmups": 5, "runs": 59, "durationMilliseconds": 5000, "fixedReadsPerWorker": 16777216}'),
        ('["--warmups", "3", "--runs", "5", "--duration-ms", "5000"]', '["--warmups", "5", "--runs", "59", "--duration-ms", "5000"]'),
        ('    "clock": (', '    "expiryReader": ("TryReadReadyLocked", "IsExpired", "TouchWithoutLock"),\n    "replay": ("ConsumeAccess", "RecordAccess", "FrequencySketch", "MoveLast", "DrainAvailable"),\n    "clock": ('),
        ('HitProbe has no sample UTC timestamps. Trace seconds are relative to xctrace start; no warmup/measured/sample alignment is inferred.', 'Artifact samples contain UTC/monotonic bounds; this report retains the whole trace. windows.py performs the complete-window join.'),
    ]:
        analysis = replace_once(analysis, old, new)
    write_adaptation(output, "analyze-read-profile.py", original_analysis, analysis)
    (output / "windows.py").write_text(WINDOW_ANALYZER)
    build = ["dotnet", "build", str(project), "-c", "Release", "-f", "net10.0", "-p:TargetFrameworks=net10.0", f"-p:FrozenLoadingCache={core}"]
    commands = {"build": build, "stage": ["uv", "run", "--offline", "--no-project", "python", str(Path(__file__)), "--output", str(output), "--stage-built"],
                "captures": [], "deferred": "Statistics ON, combined expiry, repeat/reverse captures require findings from these three OFF captures first."}
    for expiry in ("none", "write", "access"):
        target = output / f"profile-off-{expiry}"
        commands["captures"].append({"capture": ["uv", "run", "--offline", "--no-project", "python", str(output / "capture-read-profile.py"), "--snapshot", str(output / "inputs"), "--backend", "loadingcache", "--statistics", "off", "--expiration", expiry, "--output", str(target)],
            "map": ["uv", "run", "--offline", "--no-project", "python", str(output / "analyze-read-profile.py"), "--input", str(target)],
            "windows": ["uv", "run", "--offline", "--no-project", "python", str(output / "windows.py"), str(target)]})
    save(output / "commands.json", commands)
    save(output / "prepared.json", {"coreSha256": CORE, "fixedReadsPerWorker": OPS,
         "buildRun": False, "workloadRun": False, "inputHashes": PINNED,
         "preparedSourceManifestSha256": sha(output / "source-manifest.json"),
         "generatedHashes": {p.name: sha(p) for p in output.iterdir() if p.is_file()}})
    print(f"Prepared source only: {output}. ROOT must build, stage, smoke, then capture serially.")


def stage_built(output):
    prepared = read(output / "prepared.json")
    for name, expected in prepared["generatedHashes"].items():
        if sha(output / name) != expected:
            raise RuntimeError(f"Generated preparation changed: {name}")
    source = read(output / "source-manifest.json")
    verify(output / "source", source)
    built = output / "source/tools/LoadingCache.HitProbe/bin/Release/net10.0"
    if sha(built / "LoadingCache.dll") != CORE:
        raise RuntimeError("Build did not retain the pinned core")
    inputs = output / "inputs"
    inputs.mkdir(exist_ok=False)
    for name in source:
        destination = inputs / "executed-source" / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(output / "source" / name, destination)
    target = inputs / "frozen/net10/HitProbe"
    shutil.copytree(built, target)
    save(inputs / "source-manifest.json", source)
    save(inputs / "binary-manifest.json", {str(p.relative_to(inputs)): sha(p) for p in target.rglob("*") if p.is_file()})
    runtime = read(SNAPSHOT / "runtime-manifest.json")
    verify(REPO, runtime)
    save(inputs / "runtime-manifest.json", runtime)
    save(output / "staged.json", {"coreSha256": CORE, "harnessSha256": sha(target / "LoadingCache.HitProbe.dll"),
         "note": "Copies/hashes only; this script never invokes dotnet or a profiler. Build validation remains ROOT responsibility."})
    print(f"Staged existing build: {inputs}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--stage-built", action="store_true")
    args = parser.parse_args()
    output = args.output.resolve()
    if not output.is_relative_to(HERE):
        parser.error("Output must remain under this artifact directory")
    if args.stage_built:
        stage_built(output)
    else:
        prepare(output)


if __name__ == "__main__":
    main()
