"""Serial frozen-image comparison with identical execution paths and paired argv."""

import argparse
import importlib.util
import json
import os
import shutil
import statistics
import subprocess
from pathlib import Path

REPO = Path(__file__).resolve().parents[4]
spec = importlib.util.spec_from_file_location(
    "probe", REPO / "docs/benchmarks/memorycache-20260914/run.py"
)
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)


def hashes(root):
    return {
        str(path.relative_to(root)): probe.sha(path)
        for path in sorted(root.rglob("*"))
        if path.is_file()
    }


def validate_read_report(raw, case, command):
    """Bind read configuration, sample protocol and optional diagnostics to the argv."""
    assert case["kind"] == "read" and raw["schemaVersion"] == 2

    def argument(name, default=None):
        if name not in command:
            assert default is not None, name
            return default
        assert command.count(name) == 1, name
        return command[command.index(name) + 1]

    assert raw["backend"] == argument("--backend") == "loadingcache"
    config = case["config"]
    for field, key in (
        ("capacity", "capacity"),
        ("residents", "residents"),
        ("pattern", "pattern"),
        ("workers", "workers"),
        ("keyMode", "key_mode"),
        ("expiration", "expiration"),
    ):
        assert raw[field] == config[key], field
        assert argument("--" + key.replace("_", "-")) == str(config[key]), key
    assert config["statistics"] in ("on", "off")
    assert argument("--statistics") == config["statistics"]
    assert raw["statistics"] is (config["statistics"] == "on")
    for field, option in (
        ("warmups", "--warmups"),
        ("runs", "--runs"),
        ("durationMilliseconds", "--duration-ms"),
    ):
        assert raw[field] == int(argument(option)), field
    assert raw["warmups"] >= 0 and raw["runs"] > 0 and raw["durationMilliseconds"] > 0
    diagnostic_option = argument("--diagnostics", "off")
    assert diagnostic_option in ("on", "off")
    assert len(raw["samples"]) == raw["warmups"] + raw["runs"]
    for index, sample in enumerate(raw["samples"]):
        assert sample["sampleIndex"] == index
        assert sample["warmup"] is (index < raw["warmups"])
        assert len(sample["workersOperations"]) == config["workers"]
        diagnostics = sample.get("diagnostics")
        if diagnostic_option == "off":
            # Historical raw reports omit this optional field entirely.
            assert diagnostics is None
            continue
        assert isinstance(diagnostics, dict)
        before, after = diagnostics["before"], diagnostics["after"]
        for field in ("reserved", "consumed", "maintenanceRequests", "maintenanceDrainPasses"):
            assert 0 <= before[field] <= after[field], field
        for snapshot in (before, after):
            assert snapshot["consumed"] <= snapshot["reserved"]
            # Old frozen reports coupled transport totals to public stats. New reports
            # identify internal success recording separately; disabled totals are null.
            totals = snapshot.get("readTotalsRecorded", raw["statistics"])
            drops = snapshot.get("readDropsRecorded", raw["statistics"])
            assert isinstance(totals, bool) and isinstance(drops, bool)
            assert drops == raw["statistics"]  # This harness does not enable Metrics.
            for field in ("enqueued", "dequeued", "droppedFull", "droppedFailed"):
                recorded = totals if field in ("enqueued", "dequeued") else drops
                if recorded:
                    assert isinstance(snapshot[field], int) and snapshot[field] >= 0, field
                else:
                    assert snapshot[field] is None, field
        for flag in ("readTotalsRecorded", "readDropsRecorded"):
            assert before.get(flag, raw["statistics"]) == after.get(flag, raw["statistics"])
        accepted = after["reserved"] - before["reserved"]
        assert 0 <= accepted <= sample["operations"]
        assert diagnostics["unrecordedReads"] == sample["operations"] - accepted


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cases", nargs="+", required=True)
    parser.add_argument("--runtimes", nargs="+", choices=("8", "10"), default=["8", "10"])
    parser.add_argument("--warmups", type=int, default=5)
    parser.add_argument("--runs", type=int, default=7)
    parser.add_argument("--duration-ms", type=int, default=500)
    parser.add_argument("--rounds", type=int, default=2)
    parser.add_argument("--diagnostics", action="store_true")
    args = parser.parse_args()
    assert args.warmups >= 0 and args.runs > 0 and args.duration_ms > 0
    assert args.rounds > 0
    assert len(set(args.cases)) == len(args.cases)
    assert len(set(args.runtimes)) == len(args.runtimes)
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    roots = {"before": args.baseline.resolve(), "after": args.candidate.resolve()}
    original = REPO / "artifacts/benchmarks/latest-20260914-final/memorycache"
    cases = {case["id"]: case for case in json.loads((original / "cases.json").read_text())}
    assert all(case_id in cases for case_id in args.cases)
    assert all(cases[case_id]["kind"] in ("read", "replacement") for case_id in args.cases)
    assert not args.diagnostics or all(cases[case_id]["kind"] == "read" for case_id in args.cases)
    jobs = json.loads((original / "results.json").read_text())
    probe_names = {
        "HitProbe" if cases[case_id]["kind"] == "read" else "MemoryCacheProbe"
        for case_id in args.cases
    }
    frozen, inputs = {}, {}
    for label, root in roots.items():
        destination = output / "inputs" / label
        source_manifest = json.loads((root / "source-manifest.json").read_text())
        binary_manifest = json.loads((root / "binary-manifest.json").read_text())
        # Replacement metadata walks upward to this source root. Stage the matching
        # source snapshot too, rather than reporting the current checkout's source.
        for name, digest in source_manifest.items():
            source = root / "executed-source" / name
            target = destination / name
            assert source.resolve().is_relative_to(root)
            assert target.resolve().is_relative_to(destination)
            assert probe.sha(source) == digest, (label, name)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
        for version in args.runtimes:
            for probe_name in sorted(probe_names):
                relative = Path(f"frozen/net{version}/{probe_name}")
                source = root / relative
                for name, digest in hashes(source).items():
                    assert digest == binary_manifest[str(relative / name)], (label, name)
                shutil.copytree(source, destination / relative)
        frozen[label] = destination
        inputs[label] = {"sourceRoot": str(root), "files": hashes(destination)}
    probe.save(output / "inputs.json", inputs)
    shutil.copy2(Path(__file__), output / "fixed-path.py")
    shutil.copy2(REPO / "docs/benchmarks/memorycache-20260914/run.py", output / "probe-runner.py")
    probe.save(output / "cases.json", [cases[name] for name in args.cases])

    runtime_files = []
    for version in args.runtimes:
        host = REPO / f"artifacts/runtime{version}/dotnet"
        runtime_files.append(host)
        runtime_files.extend(
            path
            for path in (
                host.parent / "shared/Microsoft.NETCore.App" / probe.RUNTIMES[version]
            ).iterdir()
            if path.is_file()
        )
        runtime_files.extend(path for path in (host.parent / "host").rglob("*") if path.is_file())
    runtime_hashes = {
        str(path.relative_to(REPO)): probe.sha(path) for path in sorted(runtime_files)
    }
    probe.save(output / "runtime-manifest.json", runtime_hashes)
    environment = {
        key: value
        for key, value in os.environ.items()
        if not key.startswith(("DOTNET_", "COMPlus_", "CORECLR_", "COR_"))
    }
    execution = output / "execution"
    current_raw = output / "current.json"
    commands = {}
    for version in args.runtimes:
        for case_id in args.cases:
            job = next(
                row
                for row in jobs
                if row["round"] == 0
                and row["runtime"] == version
                and row["case"] == case_id
                and row["backend"] == "loadingcache"
            )
            command = json.loads((original / job["id"] / "command.json").read_text())["argv"]
            command[4] = str(execution / Path(command[4]).relative_to(original))
            command[command.index("--output") + 1] = str(current_raw)
            command[command.index("--warmups") + 1] = str(args.warmups)
            command[command.index("--runs") + 1] = str(args.runs)
            if cases[case_id]["kind"] == "read":
                command[command.index("--duration-ms") + 1] = str(args.duration_ms)
                if args.diagnostics:
                    command.extend(["--diagnostics", "on"])
            commands[version, case_id] = command

    results = []
    for round_id in range(args.rounds):
        versions = args.runtimes if round_id % 2 == 0 else list(reversed(args.runtimes))
        selected = args.cases if round_id % 2 == 0 else list(reversed(args.cases))
        labels = ("before", "after") if round_id % 2 == 0 else ("after", "before")
        for version in versions:
            for case_id in selected:
                command = commands[version, case_id]
                for label in labels:
                    name = f"r{round_id}-net{version}-{case_id}-{label}"
                    folder = output / name
                    folder.mkdir()
                    assert not current_raw.exists(), "Previous raw output was not moved"
                    if execution.exists():
                        shutil.rmtree(execution)
                    shutil.copytree(frozen[label], execution)
                    expected = inputs[label]["files"]
                    assert hashes(execution) == expected, name
                    probe.save(
                        folder / "command.json",
                        {
                            "argv": command,
                            "cwd": str(REPO),
                            "label": label,
                            "sourceRoot": str(roots[label]),
                            "stagedInputsVerified": True,
                            "startNewSession": False,
                            "environmentPolicy": "parent environment minus DOTNET_/COMPlus_/CORECLR_/COR_",
                        },
                    )
                    result = {
                        "id": name,
                        "round": round_id,
                        "runtime": version,
                        "case": case_id,
                        "label": label,
                        "validated": False,
                    }
                    results.append(result)
                    probe.save(output / "results.json", results)
                    with (folder / "process.log").open("w") as log:
                        process = subprocess.run(
                            command,
                            cwd=REPO,
                            env=environment,
                            stdout=log,
                            stderr=subprocess.STDOUT,
                            timeout=180,
                            check=False,
                        )
                    result["exitCode"] = process.returncode
                    if current_raw.exists():
                        current_raw.replace(folder / "raw.json")
                    probe.save(output / "results.json", results)
                    assert process.returncode == 0, name
                    assert hashes(execution) == expected, (name, "staged inputs changed")
                    raw = json.loads((folder / "raw.json").read_text())
                    case = cases[case_id]
                    probe.validate(raw, case, version, "loadingcache", None)
                    probe_name = "HitProbe" if case["kind"] == "read" else "MemoryCacheProbe"
                    assembly_root = f"frozen/net{version}/{probe_name}"
                    if case["kind"] == "read":
                        validate_read_report(raw, case, command)
                        assert (
                            raw["cacheAssemblySha256"].lower()
                            == expected[f"{assembly_root}/LoadingCache.dll"]
                        )
                        assert (
                            raw["harnessAssemblySha256"].lower()
                            == expected[f"{assembly_root}/LoadingCache.HitProbe.dll"]
                        )
                    else:
                        for assembly in raw["metadata"]["assemblies"]:
                            path = Path(assembly["path"])
                            digest = (
                                expected[str(path.relative_to(execution))]
                                if path.is_relative_to(execution)
                                else runtime_hashes[str(path.relative_to(REPO))]
                            )
                            assert assembly["sha256"].lower() == digest, (name, path)
                        for source in raw["metadata"]["sourceManifest"]:
                            assert source["sha256"] == expected[source["path"]], (name, source)
                    samples = [sample for sample in raw["samples"] if not sample["warmup"]]
                    assert len(samples) == args.runs, name
                    assert sum(sample["warmup"] for sample in raw["samples"]) >= args.warmups
                    values = [
                        sample["wallSeconds"] * 1e9 / sample["operations"]
                        if case["kind"] == "read"
                        else sample["result"]["seconds"] * 1e9 / sample["result"]["operations"]
                        for sample in samples
                    ]
                    result.update(
                        medianNs=statistics.median(values),
                        samplesNs=values,
                        rawSha256=probe.sha(folder / "raw.json"),
                        validated=True,
                    )
                    probe.save(output / "results.json", results)
                    print(f"{name} {result['medianNs']:.3f} ns/op", flush=True)
    for label, root in frozen.items():
        assert hashes(root) == inputs[label]["files"], label
    for name, digest in runtime_hashes.items():
        assert probe.sha(REPO / name) == digest, name
    summary = []
    for version in args.runtimes:
        for case_id in args.cases:
            costs = {
                label: statistics.median(
                    value
                    for row in results
                    if row["runtime"] == version
                    and row["case"] == case_id
                    and row["label"] == label
                    for value in row["samplesNs"]
                )
                for label in roots
            }
            summary.append(
                {
                    "runtime": version,
                    "case": case_id,
                    **costs,
                    "afterOverBefore": costs["after"] / costs["before"],
                }
            )
    probe.save(output / "summary.json", summary)
    probe.save(
        output / "completed.json",
        {
            "processes": len(results),
            "allValidated": True,
            "frozenInputsUnchanged": True,
            "pairedExecutionPathsAndArgvIdentical": True,
        },
    )


if __name__ == "__main__":
    main()
