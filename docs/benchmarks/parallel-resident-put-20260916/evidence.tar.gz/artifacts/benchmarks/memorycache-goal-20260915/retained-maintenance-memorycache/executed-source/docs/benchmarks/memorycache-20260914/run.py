"""Serial paired probes; preserve every command, raw sample and frozen input."""

import argparse
import bisect
import hashlib
import json
import math
import os
import platform
import random
import shutil
import signal
import subprocess
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[3]
RUNTIMES = {"8": "8.0.31", "10": "10.0.12"}
BACKENDS = ("loadingcache", "memorycache")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def cases(smoke):
    result = []

    def add(kind, **config):
        result.append({"kind": kind, "config": config})

    for stats in ("off", "on"):
        for pattern in ("hot", "cycle"):
            for workers in (1, 10) if smoke else (1, 4, 10, 20):
                add(
                    "read",
                    capacity=1024,
                    residents=1024,
                    pattern=pattern,
                    workers=workers,
                    statistics=stats,
                    key_mode="preboxed",
                    expiration="none",
                )
        if not smoke:
            for workers in (1, 10):
                add(
                    "read",
                    capacity=16384,
                    residents=16384,
                    pattern="cycle",
                    workers=workers,
                    statistics=stats,
                    key_mode="preboxed",
                    expiration="none",
                )
            add(
                "read",
                capacity=16384,
                residents=1024,
                pattern="cycle",
                workers=10,
                statistics=stats,
                key_mode="preboxed",
                expiration="none",
            )
        for expiry in ("write", "access", "both"):
            for workers in (1,) if smoke else (1, 10):
                add(
                    "read",
                    capacity=1024,
                    residents=1024,
                    pattern="cycle",
                    workers=workers,
                    statistics=stats,
                    key_mode="preboxed",
                    expiration=expiry,
                )
        for pattern in ("cycle",) if smoke else ("hot", "cycle"):
            for workers in (1,) if smoke else (1, 10):
                add(
                    "read",
                    capacity=1024,
                    residents=1024,
                    pattern=pattern,
                    workers=workers,
                    statistics=stats,
                    key_mode="native",
                    expiration="none",
                )
        for mode in ("same", "changed"):
            for workers in (1, 10) if smoke else (1, 4, 10, 20):
                add(
                    "replacement",
                    capacity=1024,
                    workers=workers,
                    statistics=stats,
                    value_mode=mode,
                    operations=1024 if smoke else 32768,
                    batches=4,
                )
        for workers in (1, 100) if smoke else (1, 10, 100):
            add("fanin", capacity=256, workers=workers, statistics=stats)
    for capacity in (256,) if smoke else (256, 4096):
        for kind in ("scan", "uniform", "zipf", "hotset-scan", "phase", "cycle"):
            add(
                "trace",
                capacity=capacity,
                workers=1,
                statistics="off",
                trace_kind=kind,
                operations=8192 if smoke else 262144,
                seed=419,
            )
    for index, case in enumerate(result):
        case["id"] = f"{index:03d}-{case['kind']}"
    return result


def trace(config):
    rng = random.Random(config["seed"])
    capacity, count = config["capacity"], config["operations"]
    cdf, total = [], 0.0
    for rank in range(capacity * 4):
        total += 1 / math.pow(rank + 1, 1.1)
        cdf.append(total)
    result = []
    for i in range(count):
        kind = config["trace_kind"]
        if kind == "scan":
            value = i
        elif kind == "uniform":
            value = rng.randrange(capacity * 4)
        elif kind == "zipf":
            value = bisect.bisect_left(cdf, rng.random() * total)
        elif kind == "hotset-scan":
            value = (
                rng.randrange(capacity // 2) if i % (capacity * 8) < capacity * 6 else capacity + i
            )
        elif kind == "phase":
            value = rng.randrange(capacity // 2) + (0 if i < count // 2 else capacity * 2)
        else:
            value = i % (capacity + capacity // 8)
        result.append(value)
    return result


def freeze(output):
    paths = []
    for folder in (
        "src/LoadingCache",
        "tools/LoadingCache.HitProbe",
        "tools/LoadingCache.MemoryCacheProbe",
    ):
        paths += [
            p
            for p in (REPO / folder).rglob("*")
            if p.is_file()
            and not {"bin", "obj"}.intersection(p.relative_to(REPO / folder).parts)
            and p.suffix in (".cs", ".csproj")
        ]
    paths += [
        REPO / p
        for p in (
            "global.json",
            "Directory.Build.props",
            "Directory.Packages.props",
            "LoadingCache.slnx",
        )
    ]
    paths += [Path(__file__).resolve()]
    sources = {str(p.relative_to(REPO)): sha(p) for p in sorted(paths)}
    save(output / "source-manifest.json", sources)
    for path in sources:
        destination = output / "executed-source" / path
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(REPO / path, destination)
    for version in RUNTIMES:
        for probe in ("HitProbe", "MemoryCacheProbe"):
            source = REPO / f"tools/LoadingCache.{probe}/bin/Release/net{version}.0"
            shutil.copytree(source, output / f"frozen/net{version}/{probe}")
    binaries = {
        str(p.relative_to(output)): sha(p)
        for p in sorted((output / "frozen").rglob("*"))
        if p.is_file()
    }
    save(output / "binary-manifest.json", binaries)
    runtime_files = []
    for version, patch in RUNTIMES.items():
        host = REPO / f"artifacts/runtime{version}/dotnet"
        runtime_files += [host]
        runtime_files += [
            p
            for p in (host.parent / f"shared/Microsoft.NETCore.App/{patch}").iterdir()
            if p.is_file()
        ]
    hosts = {str(p.relative_to(REPO)): sha(p) for p in sorted(runtime_files)}
    save(output / "runtime-manifest.json", hosts)
    return sources, binaries, hosts


def checksum(worker, operations, residents, pattern):
    if pattern == "hot":
        return operations
    cycles, remainder = divmod(operations, residents)
    first = worker * 17 % residents
    segment = min(remainder, residents - first)
    rest = remainder - segment
    return (
        cycles * residents * (residents + 1) // 2
        + segment * (2 * first + segment + 1) // 2
        + rest * (rest + 1) // 2
    )


def validate(raw, case, version, backend, trace_file):
    config = case["config"]
    if case["kind"] == "read":
        assert raw["runtime"] == f".NET {RUNTIMES[version]}"
        assert raw["backend"] == backend and raw["memoryCacheVersion"] == "10.0.0.0"
        assert (
            raw["memoryCacheInformationalVersion"]
            == "10.0.12+95017c711e6afc1085133d440e42b4bd78155701"
        )
        for key in raw["runtimeEnvironment"].values():
            assert key is None
        for sample in raw["samples"]:
            operations = sample["operations"]
            assert sum(sample["workersOperations"]) == operations and operations > 0
            expected = sum(
                checksum(w, n, config["residents"], config["pattern"])
                for w, n in enumerate(sample["workersOperations"])
            )
            assert sample["checksum"] == expected and sample["misses"] == 0
            assert sample["missesDelta"] == 0 and sample["boundsPassed"]
            assert sample["hitsDelta"] == (operations if config["statistics"] == "on" else 0)
            assert sample["residentCount"] == config["residents"]
            assert sample["wallSeconds"] > 0
    else:
        assert raw["metadata"]["runtime"] == f".NET {RUNTIMES[version]}"
        assert raw["options"]["backend"] == backend
        for sample in raw["samples"]:
            value = sample["result"]
            assert value["validated"]
            if case["kind"] == "replacement":
                assert (
                    value["operations"]
                    == config["workers"] * config["operations"] * config["batches"]
                )
                assert value["finalCount"] == config["capacity"] // 2
            elif case["kind"] == "fanin":
                assert value["backendCalls"] == (
                    1 if backend == "loadingcache" else config["workers"]
                )
                assert (
                    value["pendingBeforeRelease"] == value["successfulCallers"] == config["workers"]
                )
            else:
                assert value["requests"] == value["hits"] + value["misses"] == config["operations"]
                assert value["canonicalTraceSha256"] == sha(trace_file)
                numbers = [int(line) for line in trace_file.read_text().splitlines()]
                mapping, expected = {}, 0
                for n in numbers:
                    if n not in mapping:
                        mapping[n] = len(mapping)
                    expected += mapping[n]
                assert value["checksum"] == expected and value["distinctKeys"] == len(mapping)
                assert 0 <= value["finalCount"] <= config["capacity"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    selected = cases(args.smoke)
    save(output / "cases.json", selected)
    sources, binaries, hosts = freeze(output)
    save(
        output / "machine.json",
        {
            "platform": platform.platform(),
            "python": platform.python_version(),
            "gitHead": subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=REPO, text=True
            ).strip(),
            "gitStatus": subprocess.check_output(["git", "status", "--short"], cwd=REPO, text=True),
            "cpu": subprocess.check_output(
                ["sysctl", "-n", "machdep.cpu.brand_string", "hw.physicalcpu", "hw.logicalcpu"],
                text=True,
            ),
            "clock": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        },
    )
    traces = {}
    for case in selected:
        if case["kind"] == "trace":
            path = output / f"{case['id']}.trace"
            path.write_text("".join(f"{n}\n" for n in trace(case["config"])))
            traces[case["id"]] = path
    env = {
        k: v
        for k, v in os.environ.items()
        if not k.startswith(("DOTNET_", "COMPlus_", "CORECLR_", "COR_"))
    }
    warmups, runs, duration = (1, 2, 50) if args.smoke else (3, 5, 250)
    jobs = []
    for round_id in range(1 if args.smoke else 2):
        for case in selected if round_id == 0 else list(reversed(selected)):
            if round_id and case["kind"] == "fanin":
                continue
            for version in list(RUNTIMES) if round_id == 0 else list(reversed(RUNTIMES)):
                order = (
                    BACKENDS
                    if (round_id + (version == "10")) % 2 == 0
                    else tuple(reversed(BACKENDS))
                )
                for backend in order:
                    jobs.append((round_id, case, version, backend))
    save(
        output / "schedule.json",
        [{"round": r, "case": c["id"], "runtime": v, "backend": b} for r, c, v, b in jobs],
    )
    results = []
    for index, (round_id, case, version, backend) in enumerate(jobs):
        name = f"{index:04d}-r{round_id}-net{version}-{backend}-{case['id']}"
        folder = output / name
        folder.mkdir()
        probe = "HitProbe" if case["kind"] == "read" else "MemoryCacheProbe"
        host = REPO / f"artifacts/runtime{version}/dotnet"
        command = [
            str(host),
            "exec",
            "--fx-version",
            RUNTIMES[version],
            str(output / f"frozen/net{version}/{probe}/LoadingCache.{probe}.dll"),
            "--backend",
            backend,
            "--warmups",
            str(warmups),
            "--runs",
            str(runs),
            "--output",
            str(folder / "raw.json"),
        ]
        if case["kind"] == "read":
            command += ["--duration-ms", str(duration)]
        else:
            command += ["--scenario", case["kind"]]
            if case["kind"] == "replacement":
                command += ["--minimum-warmup-ms", "100" if args.smoke else "1000"]
        for key, value in case["config"].items():
            command += ["--" + key.replace("_", "-"), str(value)]
        trace_file = traces.get(case["id"])
        if trace_file:
            command += ["--trace-file", str(trace_file)]
        started = time.monotonic()
        save(
            folder / "command.json",
            {
                "argv": command,
                "startedUtc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "environmentPolicy": "parent environment minus DOTNET_/COMPlus_/CORECLR_/COR_; no JIT/GC/profiler overrides",
            },
        )
        with (folder / "process.log").open("w") as log:
            child = subprocess.Popen(
                command,
                cwd=REPO,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            try:
                code = child.wait(timeout=180)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
                code = 124
        result = {
            "id": name,
            "case": case["id"],
            "round": round_id,
            "runtime": version,
            "backend": backend,
            "exitCode": code,
            "seconds": time.monotonic() - started,
        }
        results.append(result)
        save(output / "results.json", results)
        assert code == 0, result
        raw = json.loads((folder / "raw.json").read_text())
        validate(raw, case, version, backend, trace_file)
        assert sum(not sample["warmup"] for sample in raw["samples"]) == runs
        assert sum(sample["warmup"] for sample in raw["samples"]) >= warmups
        result["validated"] = True
        result["rawSha256"] = sha(folder / "raw.json")
        save(output / "results.json", results)
        print(f"{index + 1}/{len(jobs)} {name} passed {result['seconds']:.2f}s", flush=True)
    for path, digest in sources.items():
        assert sha(REPO / path) == digest, path
    for path, digest in binaries.items():
        assert sha(output / path) == digest, path
    for path, digest in hosts.items():
        assert sha(REPO / path) == digest, path
    save(
        output / "completed.json",
        {
            "processes": len(results),
            "allValidated": True,
            "frozenInputsUnchanged": True,
            "finishedUtc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        },
    )


if __name__ == "__main__":
    main()
